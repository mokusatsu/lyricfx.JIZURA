import pathlib,json,gzip,base64,hashlib
root=pathlib.Path(__file__).parent
def read(blob):
 p=root/blob
 if p.name.endswith('.gz'):return gzip.decompress(p.read_bytes())
 d=json.loads(p.read_text());base=read(d['baseBlob']);b=d['suffixBytes'];raw=base[:d['prefixBytes']]+gzip.decompress(base64.b64decode(d['middleGzipBase64']))+(base[len(base)-b:] if b else b'');assert hashlib.sha256(raw).hexdigest()==d['targetSHA256'];return raw
if __name__=='__main__':
 for p in (root/'inputs').glob('*.json'):
  m=json.loads(p.read_text());m=m if isinstance(m,list) else [m]
  for q in m:
   if q.get('blob'):assert hashlib.sha256(read(q['blob'])).hexdigest()==q['sha256']
 print('All available exact input blobs/deltas verified; explicitly missing historical focused01 runner remains absent.')
