'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),crypto=require('node:crypto'),zlib=require('node:zlib');
const root=path.resolve(__dirname,'../..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const target=process.env.JIZURA_D_ORIGAMI_REPORT||'/tmp/avoid009-gate-diag02.json.gz';assert(!fs.existsSync(target));
 const files=['src/09a_placement.js','src/09g_layoutsC_placement.js','src/09k_layoutsD_placement.js','src/09n_layoutsD_origami.js','src/11p_layoutsD.js','src/11za_layoutsD_transport.js','index.html','en/index.html','dev/avoidance/layouts-a-fixture.js',path.relative(root,__filename)],pins=files.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(root,p)))}));
 const snap=target+'.inputs';fs.mkdirSync(snap);for(const file of files)fs.writeFileSync(path.join(snap,file.replaceAll('/','__')+'.gz'),zlib.gzipSync(fs.readFileSync(path.join(root,file)),{mtime:0}));
 const font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',server=http.createServer((q,r)=>{try{const b=fs.readFileSync(q.url==='/font.otf'?font:path.join(root,q.url==='/'?'index.html':q.url));r.end(q.url==='/'?b.toString().replace('const recipes=[null','const recipes=window.origamiRecipes||[null'):b);}catch{r.writeHead(404).end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;let browser;
 try{
 browser=await require('../browser.cjs').launch();const page=await browser.newPage(),warnings=[];page.on('console',m=>{if(m.type()==='warning')warnings.push(m.text());});await page.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());await page.goto(base);await page.waitForFunction(()=>window.J?.ui?.plan);await page.addScriptTag({content:fs.readFileSync(path.join(__dirname,'layouts-a-fixture.js'),'utf8')});
 const result=await page.evaluate(async()=>{
  const spec={layout:'origami',W:960,H:540,cx:.5,cy:.42,radius:.2,text:'ひらく紙に言葉を残して',params:{mode:'gate',order:2}},r=await runLayoutsAFixture(J,spec,{newPath:false,fontURL:location.origin+'/font.otf'});r.plan.fps=60;
  const baseline=J.finalizePlacementPlan(r.plan,{layoutsD:true}),base=baseline.cuts[0].placementTrajectory,rows=[];
  const cut=r.plan.cuts[0],A=J.placement,baseSize=base.sourceProof.coverage.fontSize;
  for(const fontScale of [1,.95,.9,.85,.8,.75,.7])for(const columns of [undefined,2,3,4,5,7,9,12,14]){
   const recipe={strategy:'diagnostic',sheetWriting:true,baseSize,fontScale,...(columns?{columns}:{})};window.origamiRecipes=[recipe];
   const fresh=await runLayoutsAFixture(J,spec,{newPath:false,fontURL:location.origin+'/font.otf'});fresh.plan.fps=60;const final=J.finalizePlacementPlan(fresh.plan,{layoutsD:true}),tr=final.cuts[0].placementTrajectory,seg=tr?.units[0].segments[0];
   const c={...cut,placementLayoutsD:true,layoutDRecipe:recipe},ctx=A.measurementContext();ctx.reset();const env=r.renderer.makeEnv(ctx,r.plan,c,c.palette||r.plan.style.schemes[c.scheme%r.plan.style.schemes.length],{pass:'main',t:1.5,realTime:1.5,lt:1.5,ltb:1.5,step:0,scale:1,allowFilter:false,placementEnvelope:true}),prog=A.record(r.renderer,env);
   rows.push({recipe,g:prog.nativeDGeometry,status:seg?.status,offset:seg?.from,attempts:seg?.attempts,diagnostics:final.placementFinalization.diagnostics});
  }
  return {spec,baseline:base,rows};
 });
 for(const pin of pins)assert.equal(sha(fs.readFileSync(path.join(root,pin.path))),pin.sha256);const receipt={...result,pins,browser:browser.version(),warnings,font:{path:font,sha256:sha(fs.readFileSync(font)),scope:'Pinned single-face functional render only; full font repertoire/cmap not certified'}};fs.writeFileSync(target,zlib.gzipSync(JSON.stringify(receipt),{mtime:0}));console.log(JSON.stringify({report:target,baseline:result.baseline.units[0].segments[0],rows:result.rows.filter(r=>r.status==='safe').map(({recipe,g,offset})=>({recipe,g,offset}))}));
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{const target=process.env.JIZURA_D_ORIGAMI_REPORT||'/tmp/avoid009-gate-diag02.json.gz';fs.writeFileSync(target+'.failure.json',JSON.stringify({name:e.name,message:e.message,stack:e.stack},null,2)+'\n');console.error(e);process.exitCode=1;});
