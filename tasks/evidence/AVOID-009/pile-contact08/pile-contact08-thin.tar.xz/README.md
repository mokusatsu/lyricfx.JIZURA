Physical08 proof-only correlatedcontact diagnostic. NOphysical/quality/SAFE/adapter acceptance, no geometry/font/groupY change.

Actualparent32823exit0:2cases48observations2440polygons0FAIL/errors,1210actualpostpinsunchanged. RawSHA dd57c6ac7cee050bcff85cec34f032fbab2576a16ddf59d27cbb8bb075e6136b. FINALparent independentanalyzer/results/review/actualterminalreceipt embedded (receipt is not shelllog).8trialpairs alloldtrialJSONexact07,56owners1792cells25088nominalclippedvertices,48paintframes120actualsettledowners1780actualclearanceextrema;86016slabs1505280pairchecks0actualfallbacks, full1210inputrehash. Nearzeroendpointboxfallback source-reviewed, no extra fuzz.97oldJS+build.py byte-identical07; new09wonly, no renderhook.

Bothnative/candidate retightened with complete fullguard overhang independent; old07strict+allowedreports exactretained. rho1.1allowedonly2/4Japanese and2/3gap: residualgap failures remain, not widened away. Newmodule continuousordinarynumericmodel is not formal libm/Canvas or filledfontcontact/readability/quality proof. nR1/2..8nongaps and numeric loweredge sign margin domain only; nominalvertical/nearzero directions typed-inconclusive, no n1/multirow/layer capability. No groupY derivation/paint.

08B0fullpaint parity only; no newstage/circle/fullvisible acceptance. Prior07translated72frames/exactpixels/stageguards/proposedcirclewitnesses remain in thin07 f5248d90... with original07run01FAIL/emptyset semantics andrun02PASS, not duplicated as08claims. Earliercapsules6de061.../32c6f.../66d877.../f0a754... preserve oldnativeFAIL/PASS/diagnoses/04/05/06fullraw. All remain required for earlierhistory.

Includes actual08raw/source/runner/cases/prepins/endpins/invocation/terminalreceipt/math/currentidentitypins/finalparentchecks. All1210inputs mapped; nativefonts/fixtures via individuallyverifiedGitbc39ce2 references. Reconstruct native02/04/05/06/07/08 consumedJAEN all12HTMLexact. Runtime567CAS EXTERNAL, not downloaded or embedded: NOTstandalone browserruntime.

Extract into freshdirectory and run python verify-artifacts.py first. Offline/read-onlyGit/no browser/network:
python restore-inputs.py --repo /path/to/repo --out /tmp/pile-contact08-restored-fresh
python recompute-parent-checks.py --evidence-base /tmp/pile-contact08-restored-fresh/consumed/physical08 --out /tmp/pile-contact08-parent-math-fresh

Restores andhashes every nonruntimeconsumedinput including fontmanifest/OTF/TTF; capturedraw outputs copied separately asEVIDENCE, notconsumedinputs. Originalparentanalyzer/results unchanged. Recompute creates path-only derivedparentcopy redirecting outputtofresh/tmp, --skip-input-rehash honestlyleaves runtimeexternal; restore hascheckedallnonruntimebytes. No JS/browserexecution implied. No images/media/publicchecks.
