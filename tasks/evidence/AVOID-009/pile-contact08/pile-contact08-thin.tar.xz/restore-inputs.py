"""Restore exact consumed project/font/HTML inputs. RuntimeCAS deliberately external.
Read-onlygitshow; fresh/tmpdestination. No browser/network/Gitmutation.
"""
from pathlib import Path
import argparse,json,subprocess,hashlib,shutil,os
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args();base=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False)
subprocess.run(['python',str(base/'reconstruct-html.py'),'--repo',a.repo,'--out',str(out/'rebuilt')],check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
rows=[];external=[]
for x in json.loads((base/'portable-reference-map.json').read_text())['files']:
 ref=x['portableReference'];k=ref['kind']
 if k=='external-runtime-CAS':external.append(x);continue
 if k=='verified-Git-reference':data=subprocess.check_output(['git','show',ref['commit']+':'+ref['path']],cwd=a.repo)
 elif k=='embedded':data=(base/ref['path']).read_bytes()
 elif k in ['exact-source-reconstruction','exact-HTML-reconstruction']:data=(out/'rebuilt'/ref['variant']/ref['path']).read_bytes()
 else:raise ValueError(k)
 actual=hashlib.sha256(data).hexdigest();assert actual==x['sha256'],x['path'];original=Path(x['path']);rel=original.relative_to('/tmp/avoid009-pile01');f=out/'consumed'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);rows.append({'originalPath':x['path'],'restoredPath':str(f),'sha256':actual,'matched':True,'kind':k})
evidence=[]
for run in ['run01']:
 for p in (base/'evidence'/run).glob('*'):
  f=out/'consumed/physical08'/run/p.name;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,f);evidence.append({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'kind':'captured-output-not-consumed-input'})
(out/'restore-result.json').write_text(json.dumps({'allRestoredExact':True,'files':rows,'restoredEvidence':evidence,'externalRuntimeCAS':external,'standaloneRuntime':False},indent=2)+'\n');print(json.dumps({'restoredExact':len(rows),'capturedEvidenceFiles':len(evidence),'externalRuntimeCAS':len(external),'nativeFontTargets':sum('editorial-fonts/'in x['originalPath']for x in rows),'standaloneRuntime':False}))
