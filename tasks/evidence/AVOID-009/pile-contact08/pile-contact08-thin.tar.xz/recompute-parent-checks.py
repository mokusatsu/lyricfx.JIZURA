"""Portable parentmath only; original actualparent source/results unchanged.
Derivedcopy redirects onlyoutputpath; positionalbase and skip-runtime CLI are native.
"""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--evidence-base',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);name='parent-pile-contact08';text=(b/'parent'/(name+'.py')).read_text();target='/tmp/'+name+'.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(name+'.json'))),1);script=out/(name+'.py');script.write_text(text);r=subprocess.run(['python',str(script),a.evidence_base,'--skip-input-rehash'],check=True,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);q=json.loads((out/(name+'.json')).read_text());(out/'recompute-result.json').write_text(json.dumps({'mathPassed':q['status']=='PASS','runtimeRehashed':False,'pathOnlyDerivedParentCopy':True,'result':q},indent=2)+'\n');print(json.dumps({'mathPassed':q['status']=='PASS','runtimeRehashed':False}))
