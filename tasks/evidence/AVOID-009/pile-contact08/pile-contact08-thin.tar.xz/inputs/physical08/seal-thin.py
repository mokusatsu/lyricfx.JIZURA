from pathlib import Path
import json,hashlib,shutil,re
b=Path('/tmp/avoid009-pile01');r=b/'physical08';d=b/'thin-physical08';d.mkdir(exist_ok=False);old=b/'thin-physical07'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json']:put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical08.patch')
for p in (r/'run01').glob('*'):put(p,'evidence/run01/'+p.name)
put(r/'parent-terminal-receipt08.json','evidence/parent-terminal-receipt08.json')
for n in ['parent-pile-contact08.py','parent-pile-contact08.json']:put(Path('/tmp')/n,'parent/'+n)
put(Path('/workspace/lyricfx.JIZURA/tasks/evidence/AVOID-009/pile-contact08/parent-source-raw-review08.json'),'parent/parent-source-raw-review08.json')
for p in r.iterdir():
 if p.is_file():put(p,'inputs/physical08/'+p.name)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical08:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text();variants=['native02','diagnostic04','physical05','physical06','physical07','physical08'];s=re.sub(r"for variant in \[[^\n]+\]:",'variants='+repr(variants)+'\nfor variant in variants:',s)
line=" for patch in ['source.patch','root-fix.patch']+(['diagnostic04.patch'] if variant in variants[1:] else [])+(['physical05.patch'] if variant in variants[2:] else [])+(['physical06.patch'] if variant in variants[3:] else [])+(['physical07.patch'] if variant in variants[4:] else [])+(['physical08.patch'] if variant in variants[5:] else []):"
s=re.sub(r'^ for patch in [^\n]+:',line,s,flags=re.M);(d/'reconstruct-html.py').write_text(s)
oldrows=json.loads((old/'portable-reference-map.json').read_text())['files'];oldmap={x['path']:x['portableReference']for x in oldrows};gitbysha={x['sha256']:x['portableReference']for x in oldrows if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p))
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction'if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical08','path':rel}
 elif p.is_relative_to(r):
  rel='inputs/physical08/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'1210actual08inputs; exactsource/HTML reconstruction and verifiedGitrefs;567runtimebinaryCAS explicitlyEXTERNAL, notstandalone runtime; all1082old07inputsunchanged','files':files})
put(old/'verify-artifacts.py','verify-artifacts.py')
s=(old/'restore-inputs.py').read_text().replace("for run in ['run01','run02']:","for run in ['run01']:").replace("out/'consumed/physical07'","out/'consumed/physical08'");(d/'restore-inputs.py').write_text(s)
(d/'README.md').write_text('''Physical08 proof-only correlatedcontact diagnostic. NOphysical/quality/SAFE/adapter acceptance, no geometry/font/groupY change.

Actualparent32823exit0:2cases48observations2440polygons0FAIL/errors,1210actualpostpinsunchanged. RawSHA dd57c6ac7cee050bcff85cec34f032fbab2576a16ddf59d27cbb8bb075e6136b. FINALparent independentanalyzer/results/review/actualterminalreceipt embedded (receipt is not shelllog).8trialpairs alloldtrialJSONexact07,56owners1792cells25088nominalclippedvertices,48paintframes120actualsettledowners1780actualclearanceextrema;86016slabs1505280pairchecks0actualfallbacks, full1210inputrehash. Nearzeroendpointboxfallback source-reviewed, no extra fuzz.97oldJS+build.py byte-identical07; new09wonly, no renderhook.

Bothnative/candidate retightened with complete fullguard overhang independent; old07strict+allowedreports exactretained. rho1.1allowedonly2/4Japanese and2/3gap: residualgap failures remain, not widened away. Newmodule continuousordinarynumericmodel is not formal libm/Canvas or filledfontcontact/readability/quality proof. nR1/2..8nongaps and numeric loweredge sign margin domain only; nominalvertical/nearzero directions typed-inconclusive, no n1/multirow/layer capability. No groupY derivation/paint.

08B0fullpaint parity only; no newstage/circle/fullvisible acceptance. Prior07translated72frames/exactpixels/stageguards/proposedcirclewitnesses remain in thin07 f5248d90... with original07run01FAIL/emptyset semantics andrun02PASS, not duplicated as08claims. Earliercapsules6de061.../32c6f.../66d877.../f0a754... preserve oldnativeFAIL/PASS/diagnoses/04/05/06fullraw. All remain required for earlierhistory.

Includes actual08raw/source/runner/cases/prepins/endpins/invocation/terminalreceipt/math/currentidentitypins/finalparentchecks. All1210inputs mapped; nativefonts/fixtures via individuallyverifiedGitbc39ce2 references. Reconstruct native02/04/05/06/07/08 consumedJAEN all12HTMLexact. Runtime567CAS EXTERNAL, not downloaded or embedded: NOTstandalone browserruntime.

Extract into freshdirectory and run python verify-artifacts.py first. Offline/read-onlyGit/no browser/network:
python restore-inputs.py --repo /path/to/repo --out /tmp/pile-contact08-restored-fresh
python recompute-parent-checks.py --evidence-base /tmp/pile-contact08-restored-fresh/consumed/physical08 --out /tmp/pile-contact08-parent-math-fresh

Restores andhashes every nonruntimeconsumedinput including fontmanifest/OTF/TTF; capturedraw outputs copied separately asEVIDENCE, notconsumedinputs. Originalparentanalyzer/results unchanged. Recompute creates path-only derivedparentcopy redirecting outputtofresh/tmp, --skip-input-rehash honestlyleaves runtimeexternal; restore hascheckedallnonruntimebytes. No JS/browserexecution implied. No images/media/publicchecks.
''')
