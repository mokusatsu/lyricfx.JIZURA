# Paused flipCards WIP — NOT REVIEWED

NOT parent reviewed. NOT integrated. NOT family complete. This is the exact unvalidated work paused for origami corrections.

The capsule preserves new09p, the complete current09a finite-forward draft plus its exact separate patch/base, the exact flipCards registration before/after/diff, and start pins. No flipCards tests had been authored; only syntax checks ran. No browser build or functional/pixel/performance result is claimed.

The draft proposes native card/hinge intervals and font attachment, original main+corner ranks as primary, literal table/peek units as independent decor with original clocks/geometry, structural reflow before local font reductions, and typed unsupported until the narrow projection capability exists. Draft API is layoutsDProjectionCapability('flipCards-face') version1 finite-forward-text and recorder.withDProjectedText(kind,fn). The draft bridge scopes finite forward item measurement, keeps public affine strict and root invertible, forbids effect/clip/shape privileges, and restores scope in finally. These claims still require parent source review and actual exact-half ±epsilon/ghost/camera/scale/pixel tests.

The paused source tree is /tmp/avoid009-origami-worktree-01. Base09a is2c2767719f26a93f8aeaa1685ee008af10499c272b42825f7a9f9b1c9be3ca80. Start receipts contain exact other source pins. Its full11p includes historical origami source04; never transplant full files/builds over current main. Current accepted origami source06 lives separately in /tmp/avoid009-origami-square-fix01. Preserve both frozen origami archives and this WIP independently. No main changes or commits were made.
