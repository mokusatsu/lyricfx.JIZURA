Narrow pile native replay fix; not an avoidance adapter.

Parent executed and independently reviewed run01:20OFF and40native direct pairs passed;2of40replay pairs failed. Controlled diagnosis02 changed only each replay event's nativeTransform.root, retained every other event argument/state/owner/order/matrix/operation and original source, and removed exactly the3single-channel differences at t=.7699999 for both offsets. The t=.77 controls remained exactly equal. All4corrected native/replay RGBA hashes matched.

09a's measurement canvas setTransform roundtrips the source root through Float32. Its existing original-root capability covers selected native D sources; pile previously retained the rounded measurement root. New dPileCut permits original-live-root capture only for explicit native D, noA/B/C flags, exact unchanged pile source, cut/cut/still/none, no drawing/effectsOnly/decor, main/A/B and exact known transport. It uses the existing clipless live-root replay path. No affine/callback/projection API, geometry metric, owner/count/order/timing, non-pile source gate, adapter registration or circle/stage certification changes.

Original run01 source/HTML preserved in checkpoint01 and frozen byte CAS; original raw/log/prepins/runner and both diagnostic outputs retained. root-fix.patch contains only09a's guarded capability addition. Earlier9b3a52source.patch remains unchanged. New runner preserves the same11cases20samples and additionally compares3bounded accepted non-pile source paths (ribbon main, accordion A, pendulum B) against pre-fix09a at zero/nonzero offsets with exact recorded roots/events/polygons/geometry/pixels. This is a functional regression check; no broad matrix or performance/visual claim.

Static syntax checks and build succeeded. Parent must review patch/runner/pre-run02 before executing:

    cd /tmp/avoid009-pile01 && node dev/avoidance/layouts-d-pile-native-test-run02.cjs

Runner binds ephemeral127.0.0.1 only and aborts every browser request outside that exact origin. No public checks, media or source images are produced. Gate status remains FAILED from actualrun01 until actualrun02 is executed and independently reviewed.
