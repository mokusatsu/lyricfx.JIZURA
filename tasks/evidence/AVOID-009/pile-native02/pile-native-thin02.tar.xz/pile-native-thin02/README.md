Native-only pile checkpoint; no physical avoidance adapter/certificate, visual, performance or whole009completion claim.

Actual history: run01 failed2of40replay pixel comparisons, while20OFF+40direct pairs passed. diagnosis01 preserved numeric failure and showed prefix readback masking it. diagnosis02 changed only saved replay roots and confirmed exact causality for4rows. Narrow guarded09a root fix followed parent review. Actualrun02 passes20OFF+40direct+40replay pairs plus6nonpile exact comparisons;715postpins unchanged. Parent independent math/root reviews are embedded. Preserve failure history.

The archive embeds actual raw/logs/commands/runners/prepins/source patches and parent checks, without duplicate5MBJA/EN HTML, canonical project/fonts or729MBruntime bytes. portable-reference-map.json identifies exact Git references, reconstructed consumed HTML and external snapshots. Exact tracked baseline commit bc39ce2b7893a514e6ddd7e053312dde469f8640 is REQUIRED. reconstruct-html.py rebuilt all consumed historical HTML and all5expected hashes matched; reconstruction-result.json records this. Fonts and common project inputs remain individually SHA-pinned verified Git references. Runtime/Chromium/Playwright/shared-library byte snapshots remain at explicitly external original absolute frozen-inputs CAS locations; this is NOT a standalone runtime capsule.

Reconstruct using read-only Git and a fresh/tmp output:

    python reconstruct-html.py --repo /path/to/repo --out /tmp/pile-native-html-fresh

No Git mutation, remote requests, browser execution, image inspection, media or publication is performed by reconstruction. Browsers were executed by parent only, under exactlocalhost origin restrictions. All source and current gate inputs remain frozen afterrun02. DESIGN02.md is an offline proposal only, including a possible named genuine falling-entry circle exception under the user's global permission, with NOstage waiver or heap/body/dust exemption.
