from pathlib import Path
import hashlib,json,gzip,difflib,datetime,subprocess
r=Path(__file__).resolve().parent
patch=''.join(difflib.unified_diff((r/'before/src/11p_layoutsD.js').read_text().splitlines(True),(r/'src/11p_layoutsD.js').read_text().splitlines(True),fromfile='a/src/11p_layoutsD.js',tofile='b/src/11p_layoutsD.js'))
(r/'source.patch').write_text(patch)
files=[p for p in r.rglob('*') if p.is_file() and 'frozen-inputs' not in p.parts and p.name not in ['pre-run01.json'] and 'run01' not in p.parts]
nodebase=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')
for d in ['playwright','playwright-core']:files.extend(p for p in (nodebase/d).rglob('*') if p.is_file())
files.append(Path('/usr/bin/chromium'));files.extend(p for p in Path('/usr/lib/chromium').rglob('*') if p.is_file())
files.append(Path(subprocess.check_output(['which','node'],text=True).strip()))
ldd=subprocess.check_output(['ldd','/usr/lib/chromium/chromium'],text=True)
for line in ldd.splitlines():
 for word in line.split():
  if word.startswith('/') and Path(word).is_file():files.append(Path(word))
cas=r/'frozen-inputs';cas.mkdir(exist_ok=True);rows=[]
for p in dict.fromkeys(files):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();q=cas/(h+'.gz')
 if not q.exists():
  with gzip.open(q,'wb',compresslevel=1) as f:f.write(b)
 rows.append(dict(path=str(p),bytes=len(b),sha256=h,snapshot=str(q)))
(r/'pre-run01.json').write_text(json.dumps(dict(baselineCommit='bc39ce2b7893a514e6ddd7e053312dde469f8640',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),beforeBrowserExecution=True,command='cd /tmp/avoid009-pile01 && node dev/avoidance/layouts-d-pile-native-test.cjs',scope='Offline native checkpoint; no browser executed yet; all source/input/runner/runtime bytes frozen',ldd=ldd,files=rows),indent=2)+'\n')
print(json.dumps(dict(files=len(rows),bytes=sum(q['bytes'] for q in rows),receipt=str(r/'pre-run01.json'),sourcePatchSHA256=hashlib.sha256(patch.encode()).hexdigest())))
