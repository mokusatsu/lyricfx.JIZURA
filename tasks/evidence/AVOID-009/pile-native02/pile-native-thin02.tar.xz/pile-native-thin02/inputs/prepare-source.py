from pathlib import Path
import subprocess
r=Path('/tmp/avoid009-pile01'); p=r/'src/11p_layoutsD.js'; t=p.read_text(); a=t.index("reg('pile', {"); b=t.index('/* ================================================================== 9 blocks',a);s=t[a:b]
s=s.replace('    const port = isPort(env);','''    // Native-only ownership/catalog checkpoint. This declares no safe adapter.
    const nativeD = cut.placementLayoutsD === true;
    const owned = (owner, fn) => nativeD ? env.withDrawRole('primary', 'pile.' + owner, fn) : fn();
    const freeze = v => {if(v && typeof v === 'object' && !Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
    const catalog = nativeD ? {kind:'pile',version:1,ownership:'all-primary-none-exempted',W,H,seed:s,lt,pOut:env.pOut,pass:env.pass,params:{...Pm},slots:[],heap:[],heapDecisions:[],dust:[]} : null;
    try {
    const port = isPort(env);''',1)
s=s.replace('    env.poly(mound, J.mix(sc.bg, sc.sub, 0.14), out, false);',"    if(nativeD)Object.assign(catalog,{port,t0,n,nR,rows:rowsT.slice(),size,maxTot,cx,sig,yBase,Hm,rise,out,cell,pool:pool.slice(),mound});\n    owned('mound',()=>env.poly(mound, J.mix(sc.bg, sc.sub, 0.14), out, false));")
s=s.replace('    for (let gx = -1;',"    if(nativeD)Object.assign(catalog,{colsN,depth,cap:200,heapFont:Pm.hf,heapSize:cell*.8});\n    for (let gx = -1;",1)
s=s.replace('        if (y > H + cell) break;',"        if(nativeD)catalog.heapDecisions.push({gx,gy,x,top,y,limit:H+cell,accepted:y<=H+cell,ordinal:heap.length});\n        if (y > H + cell) break;",1)
s=s.replace('      }\n    }\n    if (env.pass',"        if(nativeD){const q=heap[j];catalog.heap.push({id:'pile.heap.'+gx+'.'+gy,owner:'pile.heap',role:'primary',gx,gy,ordinal:j,...q});}\n      }\n    }\n    if(nativeD)freeze(heap); // Saved charFn closes over this immutable frame snapshot.\n    if (env.pass",1)
s=s.replace('      env.draw(it);',"      if(nativeD)it.placementDSource={kind:'pile-heap',glyphs:catalog.heap};\n      owned('heap',()=>env.draw(it));",1)
s=s.replace('    rowsT.forEach((row, ri) => {',"    if(nativeD)Object.assign(catalog,{fd,gap,stagger:cut.stagger||.04,order:order.map(([row,slot],ordinal)=>({row,slot,ordinal,when:when.get(row*100+slot)}))});\n    let sourceOrdinal=0;\n    rowsT.forEach((row, ri) => {",1)
s=s.replace("        if (ch === ' ') return;", """        const source = nativeD ? {id:'pile.glyph.'+ri+'.'+i,owner:'pile.glyph.'+ri+'.'+i,role:'primary',row:ri,slot:i,sourceOrdinal:sourceOrdinal++,layer,ch,gap:ch===' ',advance:ads[i],gxp,when:when.get(ri*100+i),mi:miAt(env,when.get(ri*100+i)),f:(lt-when.get(ri*100+i))/fd} : null;
        if(nativeD)catalog.slots.push(source);
        if (ch === ' ') return;""",1)
s=s.replace('        if (f < 0) return;',"        if(nativeD)Object.assign(source,{ys,slope,tilt,restY,t1,f,tau:f>=1?(f-1)*fd:null,phase:f<0?'not-started':f<1?'falling':'settled'});\n        if (f < 0) return;",1)
s=s.replace('              env.circle(gxp + dir',"              const paintDust=()=>env.circle(gxp + dir",1)
s=s.replace('(1 - tau / 0.35) * out, false);',"(1 - tau / 0.35) * out, false);\n              if(nativeD)catalog.dust.push({id:source.id+'.dust.'+q,owner:source.id+'.dust.'+q,role:'primary',row:ri,slot:i,q,dir,sp,tau,gxp,restY,size});\n              owned('glyph.'+ri+'.'+i+'.dust.'+q,paintDust);",1)
s=s.replace('        bb = UB(bb, J.mainDraw(env, { text: ch, font: Pm.font, size, x: gxp, y: y + size * 0.47 * (1 - sy), sy, rot, color: J.r(s, ri, i, 12) < 0.12 ? sc.accent : sc.fg, mi: miAt(env, t1) }));',"""        const item = { text: ch, font: Pm.font, size, x: gxp, y: y + size * 0.47 * (1 - sy), sy, rot, color: J.r(s, ri, i, 12) < 0.12 ? sc.accent : sc.fg, mi: miAt(env, t1) };
        if(nativeD){Object.assign(source,{y,rot,sy,itemY:item.y,color:item.color});item.placementDSource=source;}
        bb = UB(bb, owned('glyph.'+ri+'.'+i,()=>J.mainDraw(env,item)));""")
s=s.replace('    return bb;\n  },',"    return bb;\n    } finally {if(nativeD)env.placementDGeometry=freeze(catalog);}\n  },",1)
p.write_text(t[:a]+s+t[b:])
# Tracked build/runtime/fixture inputs only; main and pendulum remain read-only.
repo='/workspace/lyricfx.JIZURA';commit='bc39ce2b7893a514e6ddd7e053312dde469f8640'
paths=['build.py','app/english.py','app/english.js','app/body.html','app/style.css','assets/effect-preview.png','vendor/mp4-muxer.min.js','dev/browser.cjs','dev/package.json','dev/package-lock.json','dev/avoidance/layouts-b-fixture.js']
paths+=subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'dev/avoidance/layouts-c-editorial-fonts'],cwd=repo,text=True).splitlines()
for path in paths:
 f=r/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','show',commit+':'+path],cwd=repo))
