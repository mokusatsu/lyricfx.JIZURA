/* AVOID-009: D source inventory and custom drawing boundary. All capabilities
   are explicit opt-in. A declaration is never a geometry certificate. */
(() => {
'use strict';
const A=J.placement;
const rows=[
 ['cube','face-solid','face-local lyric, face labels, alternate copy and numeral','face yaw/pitch and pop intervals; chunk/face schedule'],
 ['cylinder','drum','front lyric rows, deliberate secondary text rings and optional band/glass','front arc pitch/row spacing; bounded spin, ring text and shear'],
 ['flipCards','card','each card face, corner rank and lyric glyph','card pitch/row arrangement; flip intervals'],
 ['accordion','fold','each folded panel and printed glyph','fold pitch/depth; bounded affine panels'],
 ['flag','cloth','cloth strips and printed glyphs','wave amplitude/path and line pitch; strip shear'],
 ['ribbon','ribbon','ribbon path, edge and printed glyphs','path bend, path measure and text spacing'],
 ['pendulum','pendulum','strings, weights/fan papers and printed text','anchor pitch and string length; angular sweep'],
 ['pile','glyph','each falling/settled glyph','settled row/column pitch; entry and exit glyph intervals'],
 ['blocks','block','each block face, edges and printed glyph','block pitch and row arrangement; projected fall'],
 ['balloons','balloon','glyph balloons, highlights and tied strings','balloon pitch and string length; buoyant sweep'],
 ['magnets','magnet','lyric magnets plus decoy magnet bodies','magnet row pitch; source attraction/rotation'],
 ['tiles','tile','letter tile, face glyph and point value','tile pitch and rows; affine entry/exit'],
 ['bulbs','sign','sign body, shadow, rim bulbs, lyric and subtitle','sign writing measure and rim pitch; pop interval'],
 ['ledScroll','display','module housing, main scrolling lyric and information strip','display lane/width; clipped source scroll and dot texture'],
 ['billboard','billboard','board, structure, lamps and lyric/tag','board writing field and post geometry; rise interval'],
 ['crowdBubbles','bubble','hero bubble and lyric; crowd captions retain separate roles','hero writing field and bubble tail; crowd intervals'],
 ['crossword','crossword','grid, clue labels, numbers, crossing entries and lyric cells','grid cell measure and clue arrangement; typed writing clocks'],
 ['wordSearch','search-grid','grid panel, find capsule, path glyphs and metadata','grid cell pitch and find-path direction; decoy capsule separate'],
 ['puzzle','piece','jigsaw pieces, their clipped lyric portions and seams','piece grid measure and arrival paths; clip union'],
 ['shadowPlay','cast-shadow','solid lyric, affine cast lyric and shared floor/lamp','light direction and cast extent; wall blur needs finite support'],
 ['kaleido','hero','central disc/band and complete lyric','hero writing field and disc radius; repeated radial background deferred'],
 ['dominoes','domino','each domino face, pips and printed glyph','domino row pitch and fall angle; per-piece phases'],
 ['burst','burst-plate','burst plate and complete printed lyric','ray proportions and writing field; plate motion'],
 ['fisheye','glyph','every lens-scaled primary glyph and lens markers','lens position/strength and glyph pitch; interval scale'],
 ['wall','wall-face','projected wall surfaces and complete front lyric','wall depth, face writing measure and perspective'],
 ['origami','folded-sheet','folded sheet faces, creases and printed lyric','sheet aspect and writing measure; fold topology'],
 ['zipper','zipper','teeth, pull tab and revealed primary lyric','zip path and tooth pitch; reveal clip'],
 ['sliceStack','slice','all clipped glyph slices and extrusion copies','slice pitch and extrusion depth; clip/offset intervals'],
 ['glitchGrid','cell','all source glyph fragments and glitch cells','cell displacement and reveal intervals; source coverage'],
 ['mosaicTiles','glyph-tile','lit tiles, bevels and mask cells construct primary lyric','primary glyph tile pitch; offscreen sampler is provenance'],
 ['maskReveal','text-window','primary glyph including pattern/texture and rim','glyph writing measure; repeated texture stays primary fill'],
 ['contour','contour-copy','first lyric glyph rings/fill, complete lyric and meaningful metadata','contour radius/spacing and side writing field; raw stroke bounds'],
 ['halftoneBig','screened-glyph','screened primary glyph and optional offset duo copy','screen pitch and primary glyph measure; alpha sampler provenance'],
 ['stencil','sprayed-glyph','bridged primary glyph, marks, overspray and drips','stencil field and spray path; evenodd clip topology']
];
A.layoutsD34=rows.map(r=>r[0]);
A.layoutsDInventory=()=>rows.map(([layout,unit,primary,strategy])=>({layout,unit,primary,strategy,status:'source-proof-pending',measurementSupported:false,
 tiledAux:layout==='kaleido'?'6..12 clipped sectors each repeat five radial background captions; complete hero lyric is separately protected':layout==='wordSearch'?'seeded off-path kana filler and earlier decoy capsule':null,
 provenance:['mosaicTiles','halftoneBig'].includes(layout)?'Offscreen text raster is a primary construction input; final tiles/screened output are the stage ink.':layout==='maskReveal'?'Repeated texture is an input inside the primary glyph, never auxiliary stage text.':null}));

// Read the portable project-owned definitions, rather than the currently active
// registry. The report therefore agrees for imported, saved and preview plans.
// No program node, component parameter or manual coordinate is changed.
A.customDrawingCapability=(cut,plan)=>{
 const definitions=new Map((plan.customEffects||[]).map(d=>[d.id,d])),programs=[],components=[];
 const add=(program,path,group,params={},event=null)=>{if(!program)return;const nodes=(program.nodes||[]).map((n,index)=>({path:path+'.nodes['+index+']',type:n.type,role:['text','arcText'].includes(n.type)?'primary':'owned-program-shape',...(['text','arcText'].includes(n.type)?{textSource:n.text==='$text'||n.text===undefined?(group==='fx'||group==='trans'?'empty-render-input':'lyric'):n.text==='$note'?(group==='fx'||group==='trans'?'empty-render-input':'note'):'literal'}:{}),frame:n.frame||'area',units:n.units||'frame'}));programs.push({path,group,mode:program.mode,nodes,params,...(event?{event}:{})});};
 add(cut.drawing,'cut.drawing','drawing');
 for(const group of ['layout','enter','hold','exit','treat','cam','bg','trans']){
  const d=definitions.get(cut[group]);if(!d||d.group!==group)continue;
  components.push({id:d.id,group,path:'cut.'+group,base:d.base||null,motion:!!d.motion});
  add(d.program,'components.'+d.id+'.program',group,{...d.params,...cut[group==='layout'?'params':group+'P']});
 }
 for(let i=0;i<(cut.decor||[]).length;i++){
  const entry=cut.decor[i],d=definitions.get(entry.id);if(!d||d.group!=='decor')continue;
  components.push({id:d.id,group:'decor',path:'cut.decor['+i+']',base:d.base||null,motion:false});
  add(d.program,'components.'+d.id+'.program','decor',{...d.params,...entry});
 }
 const owner=cut.line+':'+cut.part;
 for(const [domain,events]of [['cut.effectEvents',cut.effectEvents||[]],['plan.events',plan.events||[]]])for(let i=0;i<events.length;i++){
  const event=events[i],d=definitions.get(event.type);if(!d||d.group!=='fx'||domain==='plan.events'&&event.cutOwner!==owner)continue;
  const path=domain+'['+i+']';components.push({id:d.id,group:'fx',path,base:d.base||null,motion:false,cutOwner:owner});
  add(d.program,path+'.components.'+d.id+'.program','fx',{...d.params,...event.params},{cutOwner:owner,domain,clock:domain==='plan.events'?'absolute t/dur':'offset/dur'});
 }
 if(!programs.length&&!components.length)return null;
 return {version:1,capability:'custom-manual-placement',measurementSupported:false,safety:'unsupported',code:'CUSTOM_PLACEMENT_UNSUPPORTED',coordinatePolicy:'preserve-manual-program-and-component-coordinates',reason:'Custom program nodes and component motion have no certified complete-interval source adapter; original drawing remains unchanged.',programs,components,
  textNodes:programs.flatMap(p=>p.nodes.filter(n=>n.role==='primary')),schemaPreserved:true};
};
A.customGlobalEventCapabilities=plan=>(plan.events||[]).flatMap((event,index)=>{
 if(event.cutOwner!=null)return [];const d=(plan.customEffects||[]).find(d=>d.id===event.type&&d.group==='fx');if(!d)return [];
 const report=A.customDrawingCapability({line:null,part:null,effectEvents:[event]}, {customEffects:plan.customEffects});
 for(const component of report.components){component.cutOwner=null;component.path='plan.events['+index+']';}
 for(const program of report.programs){program.path='plan.events['+index+'].components.'+d.id+'.program';program.event={cutOwner:null,domain:'plan.events',clock:'absolute t/dur',scope:'global-event'};program.nodes.forEach((node,i)=>node.path=program.path+'.nodes['+i+']');}
 return [{code:'CUSTOM_GLOBAL_EVENT_UNSUPPORTED',safety:'unsupported',scope:'global-event',eventIndex:index,cutOwner:null,capability:report}];
});
})();
