from pathlib import Path
import gzip,hashlib,json,subprocess,sys,datetime
root=Path(__file__).resolve().parents[1]; name=sys.argv[1]; cas=Path('/tmp/avoid009-pendulum-input-cas01');cas.mkdir(exist_ok=True)
paths=[]
for f in ['index.html','en/index.html','build.py','parent-baseline5f6e771.json','dev/browser.cjs','dev/package.json','dev/package-lock.json','dev/avoidance/layouts-b-fixture.js','dev/avoidance/layouts-d-pendulum-native-test.cjs','pendulum-native01/before/index.html','pendulum-native01/before/en-index.html','pendulum-native01/before/11p_layoutsD.js','pendulum-native01/snapshot-inputs.py','pendulum-physical01/snapshot-inputs.py','pendulum-physical01/PROOF-NOTES01.md','dev/avoidance/layouts-d-pendulum-physical-gate.cjs','dev/avoidance/layouts-d-pendulum-limited-test.cjs','dev/avoidance/layouts-d-pendulum-native-final-test.cjs','pendulum-physical01/snapshot-limited-inputs.py','pendulum-physical01/failure-policy-readonly01.md','pendulum-physical01/gate05-execution-receipt.json']:
 paths.append(root/f)
for d in ['src','app','assets','vendor','dev/avoidance/layouts-c-editorial-fonts']:
 paths.extend(p for p in (root/d).rglob('*') if p.is_file() and '__pycache__' not in str(p))
nodebase=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')
for d in ['playwright','playwright-core']:
 paths.extend(p for p in (nodebase/d).rglob('*') if p.is_file())
paths.append(Path('/usr/bin/chromium'));paths.extend(p for p in Path('/usr/lib/chromium').rglob('*') if p.is_file())
ldd=subprocess.check_output(['ldd','/usr/lib/chromium/chromium'],text=True)
for line in ldd.splitlines():
 for word in line.split():
  if word.startswith('/') and Path(word).is_file():paths.append(Path(word))
rows=[]
for p in dict.fromkeys(paths):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 sha=h.hexdigest();q=cas/(sha+'.gz')
 if not q.exists():
  with p.open('rb') as f,gzip.open(q,'wb',compresslevel=1) as o:
   while b:=f.read(1048576):o.write(b)
 rows.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha,'snapshot':str(q)})
receipt={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'beforeBrowserRun':True,'nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'browserVersion':subprocess.check_output(['/usr/bin/chromium','--version'],text=True).strip(),'command':['node','dev/avoidance/'+('layouts-d-pendulum-native-final-test.cjs' if name.startswith('native-final') else 'layouts-d-pendulum-limited-test.cjs')],'env':{'PENDULUM_RUN':name},'ldd':ldd,'files':rows,'scope':'Full executed runner, baseline/current HTML/source, fixture, local font files, build inputs, Playwright packages, Chromium payload and ldd dependencies snapshotted before run; no remote checks.'}
(root/('pendulum-native01' if name.startswith('native-final') else 'pendulum-physical01')/('pre-run-'+name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'snapshots':len(rows),'bytes':sum(r['bytes'] for r in rows),'receipt':'pre-run-'+name+'.json'}))
