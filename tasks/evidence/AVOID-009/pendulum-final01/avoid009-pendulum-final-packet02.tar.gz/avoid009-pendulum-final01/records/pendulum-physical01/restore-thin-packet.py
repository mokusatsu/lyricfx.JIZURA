"""Restore an exact chosen project input state from a thin capsule.
No network/browser/public operations. Git is read-only if --repo is used;
--git-cas can satisfy verified Git-content references without any Git call."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,shutil,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--manifest',default='records/pendulum-native01/pre-run-native-final03.json');ap.add_argument('--dest',required=True);ap.add_argument('--repo');ap.add_argument('--git-cas');ap.add_argument('--check-runtime',action='store_true');args=ap.parse_args()
packet=Path(__file__).resolve().parent;meta=json.loads((packet/'manifest.json').read_text());selected=packet/args.manifest;run=json.loads(selected.read_text());dest=Path(args.dest).resolve();assert not dest.exists(), 'Refuse to overwrite an existing destination';dest.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest();old=Path(meta.get('originalProjectRoot','/tmp/avoid009-pendulum01'));lookup={(q['originalPath'],q['sha256']):q for q in meta['inputs']};rows=[];derive=[];runtime=[]
# Preserve readable history, then restore exact selected read-input bytes over it.
shutil.copytree(packet/'records',dest,dirs_exist_ok=True);shutil.copytree(packet/'parent',dest/'parent-independent',dirs_exist_ok=True)
def data_for(row):
 if row['kind']=='embedded-exact-input':return gzip.open(packet/row['member'],'rb').read()
 if row['kind']=='parent-verified-Git':
  if args.git_cas:
   p=Path(args.git_cas)/(row['sha256']+'.gz')
   if p.is_file():return gzip.open(p,'rb').read()
  assert args.repo,'Need --repo or exact --git-cas payload for '+row['gitPath']
  return subprocess.check_output(['git','-C',args.repo,'show',row['commit']+':'+row['gitPath']])
 raise ValueError(row['kind'])
for q in run['files']:
 row=lookup[(q['path'],q['sha256'])];p=Path(q['path'])
 if not p.is_relative_to(old):
  runtime.append({'path':q['path'],'sha256':q['sha256'],'bytes':q['bytes'],'snapshot':row.get('snapshot'),'durableInGit':False})
  if args.check_runtime:assert p.is_file() and sha(p.read_bytes())==q['sha256'],'Runtime byte mismatch: '+str(p)
  continue
 rel=p.relative_to(old);target=dest/rel
 if row['kind']=='derive-old-HTML':derive.append((q,target));continue
 b=data_for(row);assert len(b)==q['bytes'] and sha(b)==q['sha256'],str(rel);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);rows.append({'path':str(rel),'sha256':q['sha256'],'origin':row['kind']})
if derive:
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';command=['python3','build.py'];completed=subprocess.run(command,cwd=dest,env=env,capture_output=True,text=True);assert completed.returncode==0,completed.stderr
 for q,target in derive:
  assert target.is_file() and sha(target.read_bytes())==q['sha256'],'Derived HTML mismatch: '+str(target);rows.append({'path':str(target.relative_to(dest)),'sha256':q['sha256'],'origin':'exact pinned source/build derivation'})
# Verify every selected project file again, including files potentially rebuilt.
for q in run['files']:
 p=Path(q['path'])
 if p.is_relative_to(old):assert sha((dest/p.relative_to(old)).read_bytes())==q['sha256'],q['path']
receipt={'manifest':args.manifest,'dest':str(dest),'projectFiles':rows,'projectAllExact':True,'runtimeFiles':runtime,'runtimeBytesNotEmbeddedOrGitDurable':True,'runtimeCheckedAgainstExistingFiles':args.check_runtime,'browserExecuted':False,'networkUsed':False,'GitOperations':'none when all --git-cas payloads satisfy refs; otherwise read-only git show only','freshRerunExample':['python3 pendulum-physical01/snapshot-limited-inputs.py native-final-replay01','PENDULUM_RUN=native-final-replay01 node dev/avoidance/layouts-d-pendulum-native-final-test.cjs'],'rerunRequires':'Ordinary authorized localhost network permission and matching external runtime; no public-result checks. Parent proof scripts retain original absolute raw paths; on another dest adapt paths with a new invocation record.'};(dest/'RESTORE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'projectAllExact':True,'projectFiles':len(rows),'externalRuntimeFiles':len(runtime),'dest':str(dest),'receipt':str(dest/'RESTORE-RECEIPT.json')}))
