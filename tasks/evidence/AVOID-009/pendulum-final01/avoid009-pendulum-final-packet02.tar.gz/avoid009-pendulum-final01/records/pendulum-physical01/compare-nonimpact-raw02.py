"""Read saved limited03 raw only. No browser, rendering, product changes or rerun."""
from pathlib import Path
import copy,hashlib,json,datetime
root=Path(__file__).resolve().parents[1];source=root/'pendulum-physical01/limited03/raw.json';out=root/'pendulum-physical01/limited03-nonimpact-normalized02.json'
assert not out.exists(), 'Fresh output required'
raw=json.loads(source.read_text());allowed=[['placementFinalization','revision'],['cuts',0,'placementTrajectory','revision']]
def diffs(a,b,path=()):
 if type(a)!=type(b):return [{'path':list(path),'after':a,'before':b}]
 if isinstance(a,dict):
  if a.keys()!=b.keys():return [{'path':list(path),'afterKeys':list(a),'beforeKeys':list(b)}]
  return [d for k in a for d in diffs(a[k],b[k],(*path,k))]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':list(path),'afterLength':len(a),'beforeLength':len(b)}]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in diffs(x,y,(*path,i))]
 return [] if a==b else [{'path':list(path),'after':a,'before':b}]
rows=[]
assert len(raw['nonimpact'])==3
for row in raw['nonimpact']:
 a=json.loads(row['after']['finalJSON']);b=json.loads(row['before']['finalJSON']);actual=diffs(a,b)
 assert len(actual)==2 and {tuple(q['path']) for q in actual}=={tuple(p) for p in allowed}, (row['spec']['id'],actual)
 ar=a['placementFinalization']['revision'];br=b['placementFinalization']['revision'];assert type(ar)==int and type(br)==int
 assert a['cuts'][0]['placementTrajectory']['revision']==ar and b['cuts'][0]['placementTrajectory']['revision']==br
 na=copy.deepcopy(a);nb=copy.deepcopy(b)
 for path in allowed:
  x,y=na,nb
  for k in path[:-1]:x=x[k];y=y[k]
  del x[path[-1]];del y[path[-1]]
 assert na==nb
 rgba_a=[{'t':q['t'],'hash':q['hash']} for q in row['after']['rows']];rgba_b=[{'t':q['t'],'hash':q['hash']} for q in row['before']['rows']]
 assert rgba_a==rgba_b and not row['after']['errors'] and not row['before']['errors']
 direct=None
 if row['spec']['layout']=='ribbon':
  assert len(rgba_a)==0, 'Unexpected new raw schema'
  ea=row['after']['exclusion'];eb=row['before']['exclusion'];assert ea['before']==eb['before'] and ea['after']==eb['after'] and ea['error']==eb['error']==None and len(ea['observations'])==len(eb['observations'])==1
  direct={'time':ea['t'],'beforeBlankEqual':True,'paintedAfterEqual':True,'beforeBlankSHA256':ea['before'],'paintedAfterSHA256':ea['after'],'scope':'Actual direct source-paint exclusion probe only; scheduled full frame rows absent (insufficient composition); not3 ribbon frame comparisons'}
 else:assert len(rgba_a)==3
 rows.append({'id':row['spec']['id'],'originalFullJSONEqual':row['equalFinalJSON'],'originalRGBAEqual':row['equalPixels'],'onlyDifferences':actual,'actualAfterGeneration':ar,'actualBeforeGeneration':br,'remainingWholeJSONEqual':True,'allRGBAEqual':True,'RGBAFrames':rgba_a,'directPaintProbe':direct,'missingScheduledFullFrames':3 if not rgba_a else 0})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'PURE RAW comparator; original limited03 terminal exit1 and original raw/failures preserved','source':str(source),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'removedPathsOnly':allowed,'rationale':'src/02_fonts.js:194 metrics.clear increments per-document generation; src/09a_placement.js:393 reads current J.metrics.revision for final plan and trajectory. Different isolated page histories may have different numbers for identical font bytes. All other plan fields and exact RGBA remain strict. No product fix/counter rewrite.','rows':rows,'status':'PASS_FOR_RECORDED_SCOPE_WITH_RIBBON_FULL_FRAME_GAP','priorRawComparator01':'Failed its meaningful assertion requiring3 full frames per nonimpact case; original script retained, no product/browser rerun','actualBrowserRerun':False,'originalLimited03ExitCode':1}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'pairs':len(rows),'RGBAFrames':sum(len(q['RGBAFrames']) for q in rows),'directPaintProbes':sum(q['directPaintProbe'] is not None for q in rows),'afterBeforeGeneration':[(q['actualAfterGeneration'],q['actualBeforeGeneration']) for q in rows],'output':str(out)}))
