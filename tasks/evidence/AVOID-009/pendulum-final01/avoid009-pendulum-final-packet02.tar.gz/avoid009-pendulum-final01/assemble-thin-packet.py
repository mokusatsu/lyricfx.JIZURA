"""Assemble local review capsule; no Git/network/browser operations.
Requires an independently parent-verified canonical Git restore receipt."""
from pathlib import Path
import argparse,copy,gzip,hashlib,json,shutil,tarfile,datetime
ap=argparse.ArgumentParser();ap.add_argument('--canonical-receipt',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
r=Path(__file__).resolve().parents[1];base=json.loads(Path('/tmp/parent-pendulum-git-restore01.json').read_text());canonical=json.loads(Path(args.canonical_receipt).read_text());assert base['parentVerified'] and canonical['parentVerified'];assert len(base['files'])==133
out=Path(args.output);assert not out.exists();stage=out.with_suffix('').with_suffix('');assert not stage.exists();stage.mkdir();(stage/'records').mkdir();(stage/'inputs').mkdir();(stage/'parent').mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();git={}
for receipt in [base,canonical]:
 for q in receipt['files']:git[q['sha256']]={'kind':'parent-verified-Git','commit':receipt['commit'],'gitPath':q['gitPath'],'bytes':q['bytes'],'sha256':q['sha256']}
canonicalHashes={q['sha256'] for q in canonical['files']};expectedCurrent={sha((r/p).read_bytes()) for p in ['src/09t_layoutsD_pendulum.js','src/11p_layoutsD.js','index.html','en/index.html']};assert expectedCurrent<=canonicalHashes
# All evidence/receipt files remain inspectable at their original project-relative paths.
for directory in ['pendulum-native01','pendulum-physical01']:
 for p in sorted((r/directory).rglob('*')):
  if not p.is_file() or p==Path(__file__) or 'before' in p.relative_to(r/directory).parts or p.name in ['native-gate-11p.js','native-gate-09t.js']:continue
  if p.suffix not in ['.json','.md','.py','.log','.patch']:continue
  target=stage/'records'/p.relative_to(r);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for p in sorted((r/'dev/avoidance').glob('*pendulum*.cjs')):
 target=stage/'records'/p.relative_to(r);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for p in sorted(Path('/tmp').glob('parent-pendulum-*')):
 if p.is_file() and p.suffix in ['.py','.json']:shutil.copyfile(p,stage/'parent'/p.name)
shutil.copyfile(args.canonical_receipt,stage/'parent/canonical-git-restore.json');shutil.copyfile(r/'parent-baseline5f6e771.json',stage/'records/parent-baseline5f6e771.json');shutil.copyfile(__file__,stage/'assemble-thin-packet.py');shutil.copyfile(r/'pendulum-physical01/restore-thin-packet.py',stage/'restore-thin-packet.py')
manifestPaths=sorted([*(r/'pendulum-native01').glob('pre-run-*.json'),*(r/'pendulum-physical01').glob('pre-run-*.json')]);inputs={};runs=[]
for mp in manifestPaths:
 m=json.loads(mp.read_text());runs.append({'manifest':'records/'+str(mp.relative_to(r)),'commandMetadata':m['command'],'env':m['env']})
 for q in m['files']:
  h=q['sha256'];p=Path(q['path']);key=(str(p),h)
  if key in inputs:continue
  row={'originalPath':str(p),'sha256':h,'bytes':q['bytes']}
  if h in git:row.update(git[h])
  elif not p.is_relative_to(r):row.update({'kind':'external-runtime-local-CAS-only','snapshot':q['snapshot'],'durableInGit':False})
  elif p.suffix=='.html' and p.name in ['index.html','en-index.html']:
   row.update({'kind':'derive-old-HTML','recipe':'Restore the exact chosen pre-run source/build/app/assets/vendor inputs, then PYTHONDONTWRITEBYTECODE=1 python3 build.py. Match output SHA strictly. Original before/* HTML resolves to verified baseline Git instead.','audit':'records/pendulum-physical01/html-reconstruction-audit01/receipt.json','snapshotStillLocal':q['snapshot']})
  else:
   member='inputs/'+h+'.gz';dest=stage/member
   if not dest.exists():
    data=gzip.open(q['snapshot'],'rb').read();assert sha(data)==h;shutil.copyfile(q['snapshot'],dest)
   row.update({'kind':'embedded-exact-input','member':member})
  inputs[key]=row
rows=list(inputs.values());runtime={q['sha256']:q for q in rows if q['kind']=='external-runtime-local-CAS-only'}
manifest={'kind':'Thin exact AVOID-009 pendulum review capsule','originalProjectRoot':str(r),'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base['commit'],'canonicalCommit':canonical['commit'],'parentVerifiedBaselineFiles':133,'canonicalFourProductTargets':sorted(expectedCurrent),'runManifests':runs,'inputs':rows,'limits':['Original limited03 terminal exit1 retained; raw comparison normalizes ONLY2 page-local font-generation counters6/4.','Nonimpact6 full-frame pairs plus1 nonblank direct ribbon probe; no9-frame claim.','Paper single original run accepted bounded; multiple-paper Latin/effective chunks insufficient.','Source-relative common-pivot entry radial overlap budget only, not zero entry overlap/identical pixel occlusion.','No new formal performance/media/visual/human approval;009 active/010+unstarted;9/34 bounded.','Full captured external Node/Chromium/shared-library bytes remain in original /tmp CAS only; NOT fully Git durable and not included in this capsule.'],'externalRuntimeUniqueFiles':len(runtime),'externalRuntimeUncompressedBytes':sum(q['bytes'] for q in runtime.values()),'allInputUncompressedBytesPerFinal714Manifest':json.loads((r/'pendulum-native01/pre-run-native-final03.json').read_text())['files'] and sum(q['bytes'] for q in json.loads((r/'pendulum-native01/pre-run-native-final03.json').read_text())['files'])};(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(stage/'README.md').write_text('''# Pendulum bounded source capsule

All raw/logs, old failures/unexecuted pre-snapshots, executed runner versions, parent independent proof scripts/results and honest scope receipts are under records/ and parent/. Product/source/JAEN/font/fixture bytes use parent-verified Git references in manifest.json where possible; exact changed historical inputs are embedded gzip by SHA. No heavyweight runtime bytes are claimed Git durable.

Restore with python3 restore-thin-packet.py --manifest records/pendulum-native01/pre-run-native-final03.json --dest NEW_EMPTY_DIRECTORY --repo REPOSITORY [--git-cas /tmp/avoid009-pendulum-input-cas01] [--check-runtime]. The optional CAS supplies exact verified Git-content bytes without Git calls. The tool refuses an existing destination, preserves all records, restores exact chosen project inputs, derives old HTML when needed and checks every project SHA. It does not run a browser or transfer system binaries. For an actual rerun, first choose one original pre-run manifest. Restore its project-relative files from each exact Git reference or embedded gzip, matching SHA-256. The original project root was /tmp/avoid009-pendulum01. Older consumed HTML is rebuilt using exact chosen source/build/app/assets/vendor and verified against its pinned SHA; four actual outputs were independently rebuilt locally with exact hashes (receipt included). Restore baseline before/index.html etc from the verified Git mapping. The final canonical product JA/EN resolve directly from the verified canonical commit, avoiding a4.7MB duplicate here.

Browser/Node/shared-library inputs listed as external-runtime-local-CAS-only are missing from this capsule by design. Their complete exact bytes remain gzip at the listed shared/tmp CAS paths; on another machine those bytes require separate transfer or exact independently verified runtime setup. The full714 input set totals about608MB uncompressed; do not call this whole environment Git durable. Font/project fixtures listed as Git refs are verified durable.

Parent independent scripts use original absolute raw paths. On a fresh machine the chosen project/evidence can be restored to those exact paths without overwriting existing work. For another directory, any path-only adaptation must be recorded as a new invocation, not passed off as the original executed script. Public-result checks remain permanently banned; local browser reruns require ordinary authorized localhost permission and nonlocal request blocking. Do not execute publication/deploy polling, image/video viewing or new security fuzz from this capsule.
''')
files=[{'path':str(p.relative_to(stage)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(stage.rglob('*')) if p.is_file()];(stage/'file-pins.json').write_text(json.dumps(files,indent=2)+'\n')
with tarfile.open(out,'w:gz',compresslevel=6) as tf:
 for p in sorted(stage.rglob('*')):
  if p.is_file():tf.add(p,arcname='avoid009-pendulum-final01/'+str(p.relative_to(stage)))
receipt={'archive':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':len(files)+1,'canonicalCommit':canonical['commit'],'externalRuntimeNotEmbedded':True,'source':str(r),'staging':str(stage)};(r/'pendulum-physical01/final-packet-receipt02.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
