from pathlib import Path
import json,hashlib,shutil,re
b=Path('/tmp/avoid009-pile01');r=b/'physical09';d=b/'thin-physical09';d.mkdir(exist_ok=False);old=b/'thin-physical08'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json']:put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical09.patch')
for p in (r/'run01').glob('*'):put(p,'evidence/run01/'+p.name)
for name in ['parent-pile-physical09-base','parent-pile-contact09','parent-pile-groupY09']:
 for ext in ['py','json']:put(Path('/tmp')/(name+'.'+ext),'parent/'+name+'.'+ext)
for p in r.iterdir():
 if p.is_file():put(p,'inputs/physical09/'+p.name)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical09:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text().replace("'physical07', 'physical08']","'physical07', 'physical08', 'physical09']")
s=s.replace("+(['physical08.patch'] if variant in variants[5:] else []):","+(['physical08.patch'] if variant in variants[5:] else [])+(['physical09.patch'] if variant in variants[6:] else []):")
(d/'reconstruct-html.py').write_text(s)
oldrows=json.loads((old/'portable-reference-map.json').read_text())['files'];oldmap={x['path']:x['portableReference']for x in oldrows};gitbysha={x['sha256']:x['portableReference']for x in oldrows if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p))
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction'if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical09','path':rel}
 elif p.is_relative_to(r):
  rel='inputs/physical09/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 elif p==b/'physical08/pre-run.json':
  rel='inputs/physical08/pre-run.json';ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'1347actual09inputs; all1210actual08inputs unchanged; exactsource/14HTMLreconstruction and verifiedGitrefs/nativefonts;567runtimebinaryCAS EXTERNAL notstandalone runtime','files':files})
put(old/'verify-artifacts.py','verify-artifacts.py')
s=(old/'restore-inputs.py').read_text().replace("out/'consumed/physical08'","out/'consumed/physical09'");(d/'restore-inputs.py').write_text(s)
(d/'recompute-parent-checks.py').write_text('''"""Portable offline parentmath; originals unchanged, derived paths only. No browser/network."""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--evidence-base',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);results=[]
for name in ['parent-pile-physical09-base','parent-pile-contact09','parent-pile-groupY09']:
 text=(b/'parent'/(name+'.py')).read_text();target='/tmp/'+name+'.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(name+'.json'))),1);args=[a.evidence_base,'--skip-input-rehash']
 if name=='parent-pile-groupY09':
  original="base=pathlib.Path('/tmp/avoid009-pile01/physical09')";assert text.count(original)==1;text=text.replace(original,'base=pathlib.Path('+repr(str(Path(a.evidence_base).resolve()))+')',1);args=[]
 script=out/(name+'.py');script.write_text(text);r=subprocess.run(['python',str(script),*args],check=True,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);q=json.loads((out/(name+'.json')).read_text());assert q['status']=='PASS';results.append({'name':name,'mathPassed':True,'runtimeRehashed':False,'pathOnlyDerivedParentCopy':True})
(out/'recompute-result.json').write_text(json.dumps({'allMathPassed':True,'results':results},indent=2)+'\\n');print(json.dumps({'allMathPassed':True,'runtimeRehashed':False}))
''')
(d/'README.md').write_text('''Physical09 shared-run-Y SOURCE/GEOMETRY diagnostic only, internal AVOID-009. No physical/quality/SAFE/adapter/humanvisual acceptance; AVOID-010 remains unstarted. No font reduction or entry/exit waiver.

Actual parent session62013 exit0:2cases90after/72sealed08reference observations3975polys0FAIL/errors;1347actualpostpins unchanged/rehashed. RawSHA211302dec292e584202946c73529b9074d5766530de051fdc92b0199b37d8959. Three final independent parent analyzer pairs embedded unchanged.4sharedruns7exactFractionconstraints, corrected freshcorrelated budgets Japanese4/4 andgap3/3;3fullystrictallphase witnesses(2+1),18correctedactualtranslatedframes ALLcircleclear/stage. TOTAL54translatedframes23928vertices. Numeric geometry plus fullpaintRGBA parity, not humanvisible contact/readability/quality acceptance.

History note: one PARENT ANALYZER output-path variable shadow raisedTypeError AFTERmath, fixed baselinevar and reranPASS. This was parent verification tooling, NOTproduct/Chromium/run failure. Childoffline preparation Python syntax typo beforebrowser was corrected and disclosed in runnerreview; no module/browser result affected. Initial09review01 oldrunner/prepins retained in inputs and CASmap, not mislabeled actualrun. Actualrun used final d2e7617e... runner/fd2b23bd...1347pins. Original07FAIL/08oldbudget failures remain historical; corrected09 baselineTrial+baselineCorrelated preserves full failed reports and original allowances, no tolerance widening.

Only3JS scopedchanges from08; other95JS+build.py exact. Nativefont/IDs/counts/gaps/when/seeddispersion/painter unchanged. Samebody/lattice/floor. Two sharedrunY values selected from directed INNER per-ALLowner budget intervals under original .03/.01/.04font allowances and .04fontcap; fresh fullcorrelated reproof authoritative. Allstage/fullfallcircle witness diagnostics now strict EVERYowner, no waived entry policy. No newcandidate registration or API/UI activation. Priorlayer vertical PENDING; guardedprojection is not solidfont contact. Ordinary512EPS/trig/interval model, not formal libm/Canvas guarantee.

Includes actual09 raw/summary/endpins/invocation, exactsourcepatches, fullrunner/cases/prepins/currentidentity/math/docs/history and parentreceipts. All1347consumedinputs mapped: nativefonts/fixtures individuallyverifiedGitbc39ce2, all14historic JAENHTML rebuilt from102verifiedbasebuildrefs+sourcepatchchain. Runtime567binaryCAS explicitlyEXTERNAL: NOTstandalone Chromium runtime, no download/network. Prior08 thin10cb9b... and07f5248d... +oldercapsules preserve earlier actualfullraw/FAIL/PASS; not duplicated as new09 executionclaims.

Extract to freshdirectory, python verify-artifacts.py first. Offline/read-onlyGit/no browser/network:
python restore-inputs.py --repo /path/to/repo --out /tmp/pile-physical09-restored-fresh
python recompute-parent-checks.py --evidence-base /tmp/pile-physical09-restored-fresh/consumed/physical09 --out /tmp/pile-physical09-parent-math-fresh

Restore checks every nonruntimeconsumedinput including nativeOTF/TTF/manifest/fonts; actualrawoutputs separatelycopied EVIDENCE. Recompute uses derivedcopies redirecting ONLYbase/outputpaths; first2analyzers native --skip-input-rehash, third has no runtimehashstep. Original parent source/results unchanged; restoration has verified allnonruntimebytes; runtimeexternal honestlynotrehashed. No JS/module/browser execution implied by reconstruction/math. No images/MP4/publicchecks.
''')
print(json.dumps({'prepared':str(d),'inputTargets':len(files),'rawSHA256':sha(r/'run01/raw.json')}))
