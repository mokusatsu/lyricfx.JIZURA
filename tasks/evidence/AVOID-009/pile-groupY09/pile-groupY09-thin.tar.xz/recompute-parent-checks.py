"""Portable offline parentmath; originals unchanged, derived paths only. No browser/network."""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--evidence-base',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);results=[]
for name in ['parent-pile-physical09-base','parent-pile-contact09','parent-pile-groupY09']:
 text=(b/'parent'/(name+'.py')).read_text();target='/tmp/'+name+'.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(name+'.json'))),1);args=[a.evidence_base,'--skip-input-rehash']
 if name=='parent-pile-groupY09':
  original="base=pathlib.Path('/tmp/avoid009-pile01/physical09')";assert text.count(original)==1;text=text.replace(original,'base=pathlib.Path('+repr(str(Path(a.evidence_base).resolve()))+')',1);args=[]
 script=out/(name+'.py');script.write_text(text);r=subprocess.run(['python',str(script),*args],check=True,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);q=json.loads((out/(name+'.json')).read_text());assert q['status']=='PASS';results.append({'name':name,'mathPassed':True,'runtimeRehashed':False,'pathOnlyDerivedParentCopy':True})
(out/'recompute-result.json').write_text(json.dumps({'allMathPassed':True,'results':results},indent=2)+'\n');print(json.dumps({'allMathPassed':True,'runtimeRehashed':False}))
