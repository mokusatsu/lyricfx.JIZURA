from pathlib import Path
import json,hashlib,subprocess,re
r=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();q=Path('/tmp/avoid009-pile-revision12/pre-run.json');rows={x['path']:x for x in json.loads(q.read_text())['files']}
# Original browser/source/font/runtime pins retain their exact identities; do not duplicate bytes.
for x in rows.values():assert sha(Path(x['path']))==x['sha256'],x['path']
paths=[q,Path('/tmp/avoid009-pile-media01/before-bc39.html'),Path('/tmp/avoid009-pile-media01/output02/after-motion.json'),Path('/tmp/avoid009-pile-media01/output02/manifest.json'),Path('/tmp/avoid009-pile-revision12/integration12/integration-receipt.json')]
for exe in ['/usr/bin/ffmpeg','/usr/bin/ffprobe']:
 paths.append(Path(exe));p=subprocess.run(['ldd',exe],check=True,capture_output=True,text=True)
 (r/(Path(exe).name+'-libraries.txt')).write_text(p.stdout)
 for line in p.stdout.splitlines():
  m=re.search(r'=> (/\S+)',line)or re.match(r'\s*(/\S+)',line)
  if m:paths.append(Path(m.group(1)))
check=subprocess.run(['node','--check',str(r/'capture.cjs')],capture_output=True,text=True);assert check.returncode==0;(r/'syntax.json').write_text(json.dumps({'syntaxOnly':True,'browserEncoderExecuted':False,'command':['node','--check',str(r/'capture.cjs')],'exitCode':check.returncode,'stderr':check.stderr},indent=2)+'\n')
paths+=list(r.glob('*'))
for p in paths:
 if p.is_file()and p.name!='pins.json':rows[str(p)]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
receipt={'beforeBrowserMediaExecution':True,'scope':'ONE new pile entrance native60 originalBEFORE/qualified12AFTER; approved064 settled reference only','command':'cd /tmp/avoid009-pile-entry-20261024-01 && node capture.cjs','runtimeExternal':True,'files':sorted(rows.values(),key=lambda q:q['path'])};(r/'pins.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'files':len(rows),'pinsSHA256':sha(r/'pins.json'),'captureSHA256':sha(r/'capture.cjs')}))
