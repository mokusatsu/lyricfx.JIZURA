"""Read-only Git/current-source restoration, no browser/network. Runtime CAS is external.
Default restores current137 additional inputs and exact fixture/font dependencies.
--include-history also runs the pushed prior10 capsule restorer (requires substantially more /tmp space).
"""
from pathlib import Path
import argparse,json,subprocess,hashlib,tarfile,io,os,shutil
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);p.add_argument('--include-history',action='store_true');a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);sha=lambda x:hashlib.sha256(x).hexdigest();prior=json.loads((b/'prior10-Git-capsule.json').read_text());blob=subprocess.check_output(['git','show',prior['blob']],cwd=a.repo);assert len(blob)==prior['bytes']and sha(blob)==prior['sha256'];pd=out/'prior10';pd.mkdir()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as ar:
 for m in ar.getmembers():
  q=Path(m.name);assert not q.is_absolute()and '..'not in q.parts and not m.issym()and not m.islnk()
 ar.extractall(pd,filter='data')
priorrows={q['path']:q for q in json.loads((pd/'portable-reference-map.json').read_text())['files']};refs=json.loads((b/'current-build-Git-references.json').read_text());build=out/'current-build';build.mkdir()
for q in refs['files']:
 data=subprocess.check_output(['git','show',refs['commit']+':'+q['path']],cwd=a.repo);assert len(data)==q['bytes']and sha(data)==q['sha256'];f=build/q['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
for p in (b/'source').glob('*.js'):shutil.copyfile(p,build/'src'/p.name)
subprocess.run(['python','build.py'],cwd=build,check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE)
rows=[];external=[]
for q in json.loads((b/'portable-reference-map.json').read_text())['files']:
 ref=q['portableReference'];kind=ref['kind'];original=Path(q['path']);data=None
 if kind=='prior10-capsule-input':
  old=priorrows[str(original)];assert old['sha256']==q['sha256'];r=old['portableReference'];k=r['kind']
  if k=='external-runtime-CAS':external.append(q);continue
  # Selected runtime project dependencies used by the new runner are exact Git refs.
  if '/physical10/version/dev/avoidance/'not in str(original)and not str(original).endswith('/dev/browser.cjs'):continue
  assert k=='verified-Git-reference';data=subprocess.check_output(['git','show',r['commit']+':'+r['path']],cwd=a.repo)
 elif kind=='embedded':data=(b/ref['path']).read_bytes()
 elif kind=='verified-Git-reference':data=subprocess.check_output(['git','show',ref['commit']+':'+ref['path']],cwd=a.repo)
 elif kind=='current-source-or-HTML-reconstruction':data=(build/ref['path']).read_bytes()
 else:raise ValueError(kind)
 assert len(data)==q['bytes']and sha(data)==q['sha256'],q['path'];target=out/'current-inputs'/str(original).lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);rows.append({'originalPath':str(original),'restoredPath':str(target),'sha256':q['sha256'],'kind':kind})
if a.include_history:subprocess.run(['python',str(pd/'restore-inputs.py'),'--repo',a.repo,'--out',str(out/'full-prior-history')],check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
receipt={'restoredExact':len(rows),'files':rows,'prior1499MappedAndVerifiedManifest':True,'allPrior1499ActuallyRestored':a.include_history,'externalRuntimeCAS':len(external),'standaloneRuntime':False,'historyGitCapsule':prior};(out/'restore-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='files'}))
