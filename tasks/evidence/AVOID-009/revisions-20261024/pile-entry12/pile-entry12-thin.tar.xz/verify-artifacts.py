from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent;rows=json.loads((b/'artifact-pins.json').read_text())['files']
for q in rows:
 p=b/q['path'];assert p.is_file()and p.stat().st_size==q['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==q['sha256'],q['path']
print(json.dumps({'artifactPinsExact':len(rows)}))
