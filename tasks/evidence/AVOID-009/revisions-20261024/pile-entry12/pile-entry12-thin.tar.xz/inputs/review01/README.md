# Pile entrance12 frozen review packet

Internal AVOID-009 only. Approved DESIGN11 is implemented in a fresh isolation from3b95d601; the accepted card patch and96other JS/build dependencies are byte-exact. Only09v/09x and the pile portion of11p change. This is source/math/offline-build/syntax preparation, NOT module/browser execution, local qualification, human acceptance, performance acceptance, main integration, media or publication.

Review source.patch, source-review.json, MATH12.md, RUNNER-REVIEW.md, actual entrance-test.cjs and cases.json. Current-main-source-pins.json records initial copied bytes. audit-source.py compares exact tracked3b95 source/build dependencies and card/non-pile spans. Before HTML is frozen exact3b95, newJAEN are built offline. Native OFF and no-owned-entrance paths remain unchanged. Old actual adapter10 inputs, raw01FAIL/raw02PASS, CAS and all previous accepted/failing records are untouched.

The source policy intentionally changes: original falling main0<=f<1 may enter throughTOP only, with all X/bottom/circle guards strict and individually settled owners/material/dust fully strict. stageContained is factual; stagePolicySatisfied names the exception. Mound/heap use the existing source .5s rise clock as opacity entrance; fade is disclosed as distinct from native geometric rise and requires new human comparison. Settled/font/body/spacing/rest/dust look is preserved. Source/catalog counts remain primary regardless of opacity. Generic unsupported restore is not safe;017 preflight remains required.

No child browser/module execution. Parent proposed command after explicit review:

    cd /tmp/avoid009-pile-revision12 && node entrance-test.cjs

It binds127.0.0.1 and aborts all non-origin routes. Outputrun01 must not already exist. Gzip numeric raw/checkpoints only; no images/video/public result checks. Full input hashes are verified before browser and after; runtime CAS is explicitly external. No main/Git writes or arbitrary cleanup. Existing pycache739041... and22 absent skip archives remain exact.
