from pathlib import Path
import json,hashlib,difflib,subprocess
r=Path(__file__).parent;m=Path('/workspace/lyricfx.JIZURA');base='3b95d6010e60ed965ac576bf953aa95029255cbd';sha=lambda b:hashlib.sha256(b).hexdigest();changed=[];unchanged=[];patch=[]
for p in sorted((r/'version/src').glob('*.js')):
 rel='src/'+p.name;old=subprocess.check_output(['git','show',base+':'+rel],cwd=m);new=p.read_bytes();row={'path':rel,'beforeBytes':len(old),'beforeSHA256':sha(old),'bytes':len(new),'sha256':sha(new)}
 if old!=new:changed.append(row);patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
 else:unchanged.append(row)
assert {q['path'] for q in changed}=={'src/09v_layoutsD_pile_trial.js','src/09x_layoutsD_pile_adapter.js','src/11p_layoutsD.js','src/09k_layoutsD_placement.js'}
kold=subprocess.check_output(['git','show',base+':src/09k_layoutsD_placement.js'],cwd=m).decode();knew=(r/'version/src/09k_layoutsD_placement.js').read_text();assert knew==kold.replace('source-native physical field and contiguous runs; fullphase strict stage/circle bounds','source-native physical field and contiguous runs; allphase strict circle; material/settled stage strict; original falling main TOP entry')
rel='src/11p_layoutsD.js';old=subprocess.check_output(['git','show',base+':'+rel],cwd=m).decode();new=(r/'version'/rel).read_text();start='/* ================================================================== 8 pile';end='/* ================================================================== 9 blocks';a=old.index(start);b=old.index(end,a);aa=new.index(start);bb=new.index(end,aa);assert old[:a]==new[:aa] and old[b:]==new[bb:]
card={'allNonPileBytesExact':True,'beforePrefixSHA256':sha(old[:a].encode()),'afterPrefixSHA256':sha(new[:aa].encode()),'beforeSuffixSHA256':sha(old[b:].encode()),'afterSuffixSHA256':sha(new[bb:].encode())}
files={}
for rel in ['build.py','app/english.py','app/english.js','app/body.html','app/style.css','assets/effect-preview.png','vendor/mp4-muxer.min.js']:
 before=subprocess.check_output(['git','show',base+':'+rel],cwd=m);after=(r/'version'/rel).read_bytes();assert before==after;files[rel]={'bytes':len(after),'sha256':sha(after),'unchanged':True}
for rel,target in [('index.html','before-index.html'),('en/index.html','before-en-index.html')]:
 before=subprocess.check_output(['git','show',base+':'+rel],cwd=m);p=r/target
 if p.exists():assert p.read_bytes()==before
 else:p.write_bytes(before)
 files[target]={'bytes':len(before),'sha256':sha(before),'referenceCommit':base}
for rel in ['index.html','en/index.html']:
 b=(r/'version'/rel).read_bytes();files[rel]={'bytes':len(b),'sha256':sha(b),'offlineBuildOnly':True}
py=m/'app/__pycache__/english.cpython-312.pyc';pysha=sha(py.read_bytes());assert pysha=='7390411f8a74499a4ef117d443f4c04f3814039cbb64343cb50c043cc580f898'
tracked=subprocess.check_output(['git','ls-files','-v'],cwd=m,text=True).splitlines();skip=[q[2:] for q in tracked if q.startswith('S ')];missing=[p for p in skip if not (m/p).exists()];assert len(missing)==22
(r/'source.patch').write_text(''.join(patch));(r/'source-review.json').write_text(json.dumps({'baseCommit':base,'currentMainHEADReadOnly':subprocess.check_output(['git','rev-parse','HEAD'],cwd=m,text=True).strip(),'childMainWrites':False,'childGitMutations':False,'moduleExecuted':False,'changedJS':changed,'unchangedJS':unchanged,'nonPileIncludingCard':card,'files':files,'mainPycacheSHA256BeforeAfter':pysha,'missingSkipArchivesCount':len(missing),'missingSkipArchives':missing,'auditHistory':'An initial offline audit used the wrong literal heading 8) pile and raised ValueError before writing its report; corrected to actual source heading 8 pile. No JS/module/browser ran.'},indent=2)+'\n');print(json.dumps({'changed':len(changed),'unchangedJS':len(unchanged),'cardExact':True,'pycacheSHA256':pysha,'skipArchives':len(missing),'HTML':{k:v for k,v in files.items() if k.endswith('.html')}}))
