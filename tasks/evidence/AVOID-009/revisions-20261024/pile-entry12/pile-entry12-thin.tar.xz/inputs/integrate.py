from pathlib import Path
import hashlib,json,subprocess,shutil,os
r=Path(__file__).parent;m=Path('/workspace/lyricfx.JIZURA');d=r/'integration12';d.mkdir(exist_ok=False);b=r/'integration-build';b.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=m,text=True)
head=git('rev-parse','HEAD').strip();assert head=='f0a6c5c79b2b19d73cbdff47ab9508664d25a25f';status=git('status','--porcelain=v1');skip=[q for q in git('ls-files','-v').splitlines() if q.startswith('S ')];assert len([q for q in skip if not (m/q[2:]).exists()])==22;untracked=git('ls-files','--others','--exclude-standard');py=m/'app/__pycache__/english.cpython-312.pyc';pysha=sha(py);assert pysha=='7390411f8a74499a4ef117d443f4c04f3814039cbb64343cb50c043cc580f898'
prep=json.loads((r/'pre-run.json').read_text());assert len(prep['files'])==1636
for q in prep['files']:assert sha(Path(q['path']))==q['sha256'],q['path']
review=json.loads((r/'source-review.json').read_text());changed=[q['path'] for q in review['changedJS']]
for q in review['changedJS']+review['unchangedJS']:assert sha(m/q['path'])==q['beforeSHA256'],q['path']
for p in (r/'version/src').glob('*.js'):
 (b/'src').mkdir(exist_ok=True);shutil.copyfile(p,b/'src'/p.name)
for rel in ['build.py','app/english.py','app/english.js','app/body.html','app/style.css','assets/effect-preview.png','vendor/mp4-muxer.min.js']:
 p=b/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'version'/rel,p);assert sha(m/rel)==sha(p)
(b/'en').mkdir();env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'};cmd=['python','build.py'];built=subprocess.run(cmd,cwd=b,env=env,capture_output=True,text=True,check=True);(d/'offline-build.log').write_text(built.stdout+built.stderr)
for rel in ['index.html','en/index.html']:assert sha(b/rel)==sha(r/'version'/rel)
affected=[]
for rel in changed+['index.html','en/index.html']:
 target=m/rel;src=b/rel;old=target.read_bytes();new=src.read_bytes();affected.append({'path':rel,'beforeBytes':len(old),'beforeSHA256':hashlib.sha256(old).hexdigest(),'bytes':len(new),'sha256':hashlib.sha256(new).hexdigest()})
 with target.open('wb') as f:f.write(new)
for p in (r/'version/src').glob('*.js'):assert sha(m/'src'/p.name)==sha(p)
assert sha(py)==pysha and git('rev-parse','HEAD').strip()==head and git('ls-files','--others','--exclude-standard')==untracked and [q for q in git('ls-files','-v').splitlines() if q.startswith('S ')]==skip
for q in prep['files']:assert sha(Path(q['path']))==q['sha256'],q['path']
receipt={'sourceRawQualified':True,'qualificationRawSHA256':'40572d6c0bd997eead4a7af36dfe45c24ae73a4a9194f020458b11adb1d0fe28','sourceBaseProduct':'3b95d6010e60ed965ac576bf953aa95029255cbd','beforeHEAD':head,'afterHEAD':head,'childGitMutations':False,'mainBrowserOrMediaExecuted':False,'mainBuildExecuted':False,'offlineBuild':{'cwd':str(b),'argv':cmd,'PYTHONDONTWRITEBYTECODE':'1','exitCode':built.returncode,'stdout':built.stdout,'outputMatchesQualifiedExactly':True},'copyMode':'in-place wb truncate from fresh offline /tmp build; no root backup','affected':affected,'all99JSMatchQualified':True,'unaffectedJSCount':95,'nonPileCardPrefixSuffixExact':review['nonPileIncludingCard'],'pycacheBeforeAfterSHA256':pysha,'all22AbsentSkipArchivesPreserved':True,'skipFlagsBeforeAfter':skip,'untrackedListBeforeAfterExact':True,'beforeStatus':status,'afterStatus':git('status','--porcelain=v1'),'all1636QualifiedInputsRehashedUnchangedBeforeAfter':True};(d/'integration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'integrated':affected,'all99JSMatchQualified':True,'pycachePreserved':True,'skipArchives':22,'childGitMutations':False}))
