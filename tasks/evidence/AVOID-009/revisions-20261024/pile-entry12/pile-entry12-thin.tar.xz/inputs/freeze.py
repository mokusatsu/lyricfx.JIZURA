from pathlib import Path
import json,hashlib,gzip,subprocess,datetime
r=Path(__file__).parent;cas=Path('/tmp/avoid009-pile01/frozen-inputs');sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads(Path('/tmp/avoid009-pile01/physical10/pre-run02.json').read_text());rows={q['path']:q for q in old['files']}
for q in rows.values():assert sha(Path(q['path']).read_bytes())==q['sha256'],q['path']
def pin(p):
 b=p.read_bytes();h=sha(b);q=cas/(h+'.gz')
 if not q.exists():
  with q.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as z:z.write(b)
 return {'path':str(p),'bytes':len(b),'sha256':h,'snapshot':str(q)}
commands=[]
for p in [*sorted((r/'version/src').glob('*.js')),r/'entrance-test.cjs']:
 cmd=['node','--check',str(p)];q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr;commands.append({'command':cmd,'exitCode':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
(r/'syntax.json').write_text(json.dumps({'syntaxOnly':True,'moduleExecuted':False,'commands':commands},indent=2)+'\n')
(r/'build-receipt.json').write_text(json.dumps({'offlineBuildOnly':True,'moduleExecuted':False,'command':'PYTHONDONTWRITEBYTECODE=1 python build.py','cwd':str(r/'version'),'printedBuildSizesAreCharactersNotUTF8Bytes':True,'actualOutputBytes':{k:pin(r/'version'/k) for k in ['index.html','en/index.html']}},indent=2)+'\n')
review=[r/'version/src'/k for k in ['09v_layoutsD_pile_trial.js','09x_layoutsD_pile_adapter.js','11p_layoutsD.js','09k_layoutsD_placement.js']]+[r/k for k in ['source.patch','source-review.json','MATH12.md','RUNNER-REVIEW.md','README.md','cases.json','entrance-test.cjs','syntax.json','build-receipt.json']]
(r/'source-review-pins.json').write_text(json.dumps({'moduleExecuted':False,'sourceVersion':'ENTRANCE12','files':[pin(p) for p in review]},indent=2)+'\n')
for p in sorted(r.rglob('*')):
 if p.is_file() and 'run01' not in p.parts and p.name!='pre-run.json':rows[str(p)]=pin(p)
for p in [Path('/tmp/avoid009-pile-revision11/DESIGN11.md'),Path('/tmp/avoid009-pile-revision11/source-facts.py'),Path('/tmp/avoid009-pile-revision11/source-facts.json')]:rows[str(p)]=pin(p)
receipt={'beforeBrowserExecution':True,'childModuleExecuted':False,'oldAdapter10All1499ActualInputsUnchanged':True,'baseCommit':'3b95d6010e60ed965ac576bf953aa95029255cbd','phase':'AVOID009_PILE_ENTRANCE12','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'cd /tmp/avoid009-pile-revision12 && node entrance-test.cjs','runtimeCASExternal':True,'files':sorted(rows.values(),key=lambda q:q['path'])};(r/'pre-run.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'files':len(rows),'preRunSHA256':sha((r/'pre-run.json').read_bytes()),'runnerSHA256':sha((r/'entrance-test.cjs').read_bytes()),'sourcePatchSHA256':sha((r/'source.patch').read_bytes()),'reviewPinsSHA256':sha((r/'source-review-pins.json').read_bytes())}))
