from pathlib import Path
import json,gzip,math,hashlib,subprocess
out=Path('/tmp/avoid009-pile-revision11');media=Path('/tmp/avoid009-pile-media01/output02');inputs=json.loads(gzip.decompress((media/'after-inputs.json.gz').read_bytes()));plan=inputs['renderPlan'];cut=plan['cuts'][0];segment=cut['placementTrajectory']['units'][0]['segments'][0];r=segment['composition'];W,H=plan['W'],plan['H'];s=cut['seed'];size=144;cell=max(16,min(60,min(W,H)*.045));Hm=r['Hm']/r['beta'];c0=r['c0'];nativeSig=r['sigma']/r['a'];yBase=H*1.04;d=segment['from'];motion=plan['fx']['motion'];cs=cut['contentScale'];assert cs==1 and cut['cam']=='push' and cut['motionScale']==1
bump=lambda x:math.sin(x/W*17+s%7)*H*.006+math.sin(x/W*31+s%5)*H*.004
rise=lambda t,A:A*(1-max(0,min(1,t/.5)))**3
scale=lambda t:1+.03*motion*max(0,min(1,t/max(.3,cut['dur'])))
camera=lambda x,y,t:[W/2+scale(t)*(x-W/2),H/2+scale(t)*(y-H/2)]
def native_body(t):
 p=[[-W*.02+W*1.04*i/48,yBase+rise(t,1.1*Hm)-Hm/(1+((-W*.02+W*1.04*i/48-c0)/nativeSig)**4)+bump(-W*.02+W*1.04*i/48)+cell*1.2]for i in range(49)];return p+[[W*1.02,H+4],[-W*.02,H+4]]
def physical_body(t):
 p=[]
 for i in range(49):
  nx=-W*.02+W*1.04*i/48;x=r['c']+r['a']*(nx-c0);y=r['B']+rise(t,r['Ain'])-r['Hm']/(1+((x-r['c'])/r['sigma'])**4)+r['beta']*bump(nx)+cell*1.2;p.append([x,y])
 return p+[[r['c']+r['a']*(W*1.02-c0),r['floor']],[r['c']+r['a']*(-W*.02-c0),r['floor']]]
lo=lambda ps,t,offset=0:min(camera(x,y,t)[1]+offset for x,y in ps)
a,b=0,.5
for _ in range(80):
 m=(a+b)/2
 if lo(native_body(m),m)>H:a=m
 else:b=m
T=min(.5,min(q['when']+.34 for q in r['rowReflow']['slots']if not q['gap']));Nend=lo(native_body(T),T);rows=[]
for t in [0,1/60,2/60,3/60,4/60,.08,.1,.2,.3,T,.5]:
 N=lo(native_body(t),t);P=lo(physical_body(t),t,d[1]);q=max(0,min(1,(H-N)/(H-Nend)));E=(1-q)*max(0,H+2-P)/scale(t) if t<T else 0;rows.append({'lt':t,'nativeMoundNominalMinStageY':N,'acceptedPhysicalMoundNominalMinStageY':P,'proposedFootprintProgress':q,'proposedMaterialOnlyPreCameraY':E,'proposedMaterialMinStageY':P+scale(t)*E})
D=max(0,max(r['Lcenter']-r['Lreference']+d[1]/scale(q['when']) for q in r['rowReflow']['slots']if not q['gap']));D=math.nextafter(D,math.inf)
pins=[]
for name in ['11p_layoutsD.js','09v_layoutsD_pile_trial.js','09x_layoutsD_pile_adapter.js']:
 p=Path('/workspace/lyricfx.JIZURA/src')/name;pins.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
result={'scope':'READONLY scalar design calculation, main/pass only at acceptedpush, literalgeometry no raster/libm/outwardproof/noJS/browser/images','currentHEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/lyricfx.JIZURA',text=True).strip(),'acceptedProductCommit':'064cd99978bc19e23051352e2bbdca0258d03220','mediaInputSHA256':hashlib.sha256((media/'after-inputs.json.gz').read_bytes()).hexdigest(),'sourcePins':pins,'native':{'W':W,'H':H,'size':size,'cell':cell,'Hm':Hm,'sig':nativeSig,'yBase':yBase,'bodyInitialMinStageY':lo(native_body(0),0),'bodyInitialMinTOPNodeY':lo(native_body(0)[:49],0),'nominalMoundFirstStageBoundaryClockBracket':[a,b],'firstNative60MoundFrameAtOrAfterBoundary':math.ceil(b*60)},'accepted':{'offset':d,'Ain':r['Ain'],'nativeAin':1.1*Hm,'Lcenter':r['Lcenter'],'Lreference':r['Lreference'],'floor':r['floor']},'design':{'earliestOriginalNongapImpactAndMaterialEnd':T,'nativeMoundMinStageYAtEnd':Nend,'illustrative2pxMaterialGuardNotFinalCertifiedRasterBudget':2,'sharedLaunchRiseForNativeCenterAlignmentNominal':D,'newCommonLcenterNominal':r['Lcenter']-D,'materialSamples':rows},'limits':['No proposedrecipe executed or accepted','Fullglyphink/ghost/camera/rounding proofs remain implementationreview requirements','Beforewasunwrapped nativeframe, onlyexpectedsourcevisibility algebra derivedhere, notobservedgeometry']}
(out/'source-facts.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
