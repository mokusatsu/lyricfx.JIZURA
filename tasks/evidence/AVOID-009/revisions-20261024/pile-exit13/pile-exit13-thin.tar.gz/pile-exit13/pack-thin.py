from pathlib import Path
import json,hashlib,tarfile,io,gzip,datetime
r=Path('/tmp/avoid009-pile-exit13');repo=Path('/workspace/lyricfx.JIZURA');pre=json.loads((r/'pre-run.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();items={};byhash={}
def add(path,name):
 p=Path(path);b=p.read_bytes();h=sha(b)
 if name in items:assert items[name]['sha256']==h;return name
 items[name]={'path':str(p),'bytes':len(b),'sha256':h};byhash.setdefault(h,name);return name
# All small owned source/math/runner records; only the canonical raw is included.
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.name in ['pile-exit13-thin.tar.gz','capsule-receipt.json','capsule-manifest.json'] or p.parts[-2]=='run01' and p.name.endswith('.json.gz') and p.name!='raw.json.gz':continue
 if p.parts[-2]=='run01' or p.parent==r or p.parent.name in ['source','before-source']:add(p,str(p.relative_to(r)))
for p in sorted((repo/'src').glob('*.js')):
 if (r/'before-source'/p.name).exists():continue
 add(p,'inputs/current-source/src/'+p.name)
for q in json.loads((r/'integration-receipt.json').read_text())['buildInputsUnchanged']:add(q['path'],'inputs/build/'+str(Path(q['path']).relative_to(repo)))
for p in ['/tmp/parent-pile-exit13.py','/tmp/parent-pile-exit13.json']:
 if Path(p).exists():add(p,'parent/'+Path(p).name)
inputmap=[]
for q in pre['files']:
 h=q['sha256'];name=byhash.get(h)
 if name:inputmap.append({'pinnedPath':q['path'],'bytes':q['bytes'],'sha256':h,'storage':'embedded-or-bytealias','member':name});continue
 p=Path(q['path']);assert p.exists() and sha(p.read_bytes())==h,q['path']
 locator={'actualRetainedPath':q['path']}
 if q.get('existingExternalSnapshot'):locator.update({'existingGzipCAS':q['existingExternalSnapshot'],'snapshotExists':Path(q['existingExternalSnapshot']).exists(),'expectedDecodedSHA256':h})
 if q['path']=='/tmp/avoid009-pile-revision12/run01/raw.json.gz':locator['canonicalPacket']={'path':'tasks/evidence/AVOID-009/revisions-20261024/pile-entry12/pile-entry12-thin.tar.xz','member':'evidence/run01/raw.json.gz','packetSHA256':'3fce8ee5e295475ebdb04c0bae2bf2f8b48974da118c5d3019172432f6854867','memberVerifiedByListing':True}
 inputmap.append({'pinnedPath':q['path'],'bytes':q['bytes'],'sha256':h,'storage':'canonical-external','locator':locator})
assert len(inputmap)==706
# Checkpoint files are retained, not duplicated inside the canonical full-raw packet.
checkpoints=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'storage':'retained-external-checkpoint','coveredByCanonicalFullRaw':True} for p in sorted((r/'run01').glob('*-before.json.gz'))]+[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'storage':'retained-external-checkpoint','coveredByCanonicalFullRaw':True} for p in sorted((r/'run01').glob('*-after.json.gz'))]
manifest={'kind':'pile-exit13-thin-source-raw-v1','baseDeclaredHEAD':'5d110265','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact tested4sources/runner/canonical raw,95otherJS/build inputs and706processinput mapping; runtime/font assets external canonical CAS, not self-contained installed runtime','humanApproval':False,'fullNativePhysicsAcceptance':False,'canonicalRawSHA256':'a1e0ffd9efa3263f77623efd34313b682b2c3c1eb93bff531afb2ea60f43a574','members':items,'inputMap':inputmap,'retainedSideCheckpoints':checkpoints,'restoreNote':'pre-run original pinned paths include main4 BEFORE bytes intentionally changed by integration; use mapped before-source members when restoring old inputs in an isolated workspace, never overwrite current main to rerun. Original runner/raw and pre-run remain unmodified; no replay execution claimed.','externalLimit':'Runtime/font CAS locators preserve existing originals; no huge environment copy, no guarantee of standalone cross-machine runtime installation'}
# Write external inspectable manifest and archive it once.
b=json.dumps(manifest,indent=2).encode()+b'\n';(r/'capsule-manifest.json').write_bytes(b);out=r/'pile-exit13-thin.tar.gz'
with tarfile.open(out,'w:gz',compresslevel=6) as tf:
 for name,q in sorted(items.items()):
  data=Path(q['path']).read_bytes();assert sha(data)==q['sha256'];info=tarfile.TarInfo('pile-exit13/'+name);info.size=len(data);info.mode=0o600;tf.addfile(info,io.BytesIO(data))
 info=tarfile.TarInfo('pile-exit13/capsule-manifest.json');info.size=len(b);info.mode=0o600;tf.addfile(info,io.BytesIO(b))
verified=0
with tarfile.open(out,'r:gz') as tf:
 for x in tf:
  if not x.isfile():continue
  data=tf.extractfile(x).read();name=x.name.removeprefix('pile-exit13/')
  if name=='capsule-manifest.json':assert data==b
  else:assert sha(data)==items[name]['sha256'] and len(data)==items[name]['bytes'];verified+=1
assert verified==len(items)
receipt={'status':'ALL_ARCHIVE_MEMBERS_AND706INPUT_MAPPING_VERIFIED','archive':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'manifestSHA256':sha(b),'memberCountExcludingManifest':len(items),'inputMapCount':len(inputmap),'embeddedOrAliasInputs':sum(q['storage']=='embedded-or-bytealias' for q in inputmap),'canonicalExternalInputs':sum(q['storage']=='canonical-external' for q in inputmap),'canonicalRawSHA256':manifest['canonicalRawSHA256'],'sideCheckpointsRetained':len(checkpoints),'runtimeBundled':False,'archiveExtracted':False,'gitOperations':0};(r/'capsule-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
