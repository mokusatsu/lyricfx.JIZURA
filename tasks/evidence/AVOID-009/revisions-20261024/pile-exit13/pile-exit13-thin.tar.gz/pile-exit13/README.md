# Pile exit13 sealed source-only packet

Status PREPARED / UNEXECUTED, awaiting parent execution review. Product modules/browser/media/main/Git have NOT run or changed. Static node --check only and pure Python source algebra completed.

Current source baseline: parent-declared HEAD5d110265/product card2c606bdb, pileee5. New isolated source under source/, exact four originals before-source/. source.patch is the complete proposed diff; source-review.json pins95otherJS plus exact nonpile/card. before/after-index.html are current standalone and four literal replacements; no copied app/assets/vendor tree. MATH13.md and RUNNER-REVIEW.md explain proof/runtime/cache/endpoints, limitations and focused qualification. DESIGN13.md is the earlier parent-approved design; its endpoint assumption is corrected byMATH13 source findings. No document here accepts a human pile version.

Parent command, not yet executed:

cd /tmp/avoid009-pile-exit13 && /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node exit-test.cjs

Use ordinary local loopback validation permissions only, no public network checks. pre-run.json actual files are rehashed before any server/browser starts; outputs run01 must not already exist. Existing8face font pack/runtime modules/libs are external immutable references from prior canonical CAS, all actual inputs rehashed in prep. No extra copy of runtime or old source archive is made.

Runtime output plan: four gzip case-side complete checkpoints plus one canonical fullraw gzip, summary, invocation and endpins. Existing entrance12 fullraw was12MB gzip / case sides total12MB, while this runner saves fewer fullcatalog clocks and fewer probes than12. Allow conservative40MB for outputs, below present82MB freeTMP; expected about20–25MB including checkpoints+canonical but this is an estimate, not measured output. No oldraw/archive/CAS cleanup is authorized or required. No new capsule copy is prepared before parent review. If actual output grows unexpectedly, stop with retained checkpoints/error; do not delete old evidence or misstate completeness.

All previous source tests/failures/22absent flags/7390pycache/unrelated untracked assets remain untouched. Later integration, building JA/EN, native media and any public operation require parent review/authorization. Public result checks remain permanently prohibited.
