# AVOID-009 pile exit13 — sealed source-only design for parent review

Status: DESIGN READY, product SOURCE unmodified, no module/browser/media/Git execution. Base declared by parent work HEAD5d110265, fullscreen-card product2c606bdb accepted by latest user. Local records still show prior pending card in places; newest user instruction takes precedence. This design does not convert pile's conditional response into human approval. Repo skill/AGENTS/policy/task009/task-list/progress/latest checkpoint read; public result checking and parent-image prohibitions persist. Time-box instruction received through parent; continue sequential work within009, no automatic010 acceptance.

## Objective and immutable behavior

Keep accepted physical mound hold shape, size, placement, common first witness, row/run partition, sharedY, font/size, seed, native conditional heap membership/cap/break, painter order, dust, when/mi/f/.34s, offscreen launchDelta, and .5s material fade unchanged. Restore ONLY the source exit common vertical displacement/velocity/acceleration that was reduced with beta=.25. No claim that native and physical entrance/fall are identical physics.

At original effective source clock lt, pOut=clamp((lt-(dur-outDur))/outDur), define:

N=.5*nativeHm, C=(recipe.mode==='physical'?.5*recipe.Hm:N), D=N-C >=0,

d(lt)=D*inCubic(pOut).

For the selected fixture nativeHm264.24, physicalHm66.06, N132.12, C33.03, D99.09. Current surface rise includes C*pOut³. Apply d to EVERY emitted owned object after the unchanged source drawing decisions; then surface/material/main have N*pOut³ in their vertical trajectory. Body floor must move by the SAME d, otherwise changing Aout alone deforms the mound rather than translating it.

## Narrow source runtime transport (no shared infrastructure edits)

In11p pile's existing try/finally, after pilePhysicalFrame has validated the owned recipe and before the first draw, when owned exit exists and d>0, ctx.save();ctx.translate(0,d). Restore once in finally, before storing/deep-freezing the catalog. When d===0 do not introduce a save/translate/restore sequence at all, preserving exact hold/entrance operation stream and pixels. Exception paths must restore; zero-text early return precedes any save. All mound vertices/floor/heap/main/dust paint commands are enclosed; no new clipping or masking. Catalog's local base coordinates and source memberships remain unchanged.

09a A.record currently: nativeD34 implies nativeA26; proxy save/restore preserves native root/ops; translate is a supported native op (09a197–200); events capture nativeTransform.ops; clipless pile A.replay live-root path345 replays those original ops after fixed postcamera placement. Thus source ctx translation works with existing recording/replay and observation event matrices. No09a/common bridge/renderer/cache changes, no getTransform→setTransform reconstruction, no function wrapper/replacement. Exact direct-vs-replay qualification remains a later execution gate, not a design assertion.

09v pilePhysicalFrame will validate a compact owned exit descriptor against n.Hm/r.Hm, effective source dur/outDur, exact kind and D bounds, then expose scalar pOut/d/exitStart/expiry metadata. It must not mutate surface/floor/launch/rest/heap formulas or g.source data. Current recipe.signature includes dur/outDur and source params and is still enforced.

11p catalog adds explicit exitTransport: kind/sourceDeltaY/pOut/clock/start/expiry/allPrimary/geometrySpace. Geometry fields y/restY/mound/floor/heap remain BASE SOURCE, before the added exit ctx op; actual event matrix/polygon is AFTER source exit and camera. Observation adds exitTransport and phase ledger. Do not misleadingly overwrite launch/rest or classify base catalog coordinates as moved runtime coordinates.

## Preserve old candidate and hold witness FIRST

Run the exact existing four-candidate schedule and first old nine-witness placement, then the exact existing common entrance launchDelta calculation and admission. Do not re-search fonts, pose, recipe, run, witness, or offset to make exit fit. candidate can retain frozen exit source data from its existing trial (nativeHm, original effective cut clocks, complete sourceCircleStrict for EVERY unit, latest nongap when+.34), but exit-domain/admission failures must be evaluated ONLY AFTER that old base/entrance selection. Reject/mark the already selected composition insufficient rather than moving to a different hold candidate. Preserve attempts truthfully and typed unsupported/insufficient; active runtime must throw, never nativefallback SAFE. Generic unsupported restore remains non-SAFE; UI017 preflight still required.

## Initial exit domain

Inherit all current source/font/camera/numeric/source identity checks. New restoring exit path initially supports captured stock push/panL/panR only: these have no rotation/skew so positive sourceY maps to positive screenY without changing screenX. Dutch is typed unsupported for this restoration, without modifying its source camera or generic support. This is a deliberate bounded-domain limitation, not proof of impossibility.

For outDur>0 require exitStart=effectiveDur-outDur >= latest nongap source impact (max when+.34), so exit-only main support is the old settled sourceCircleStrict. Existing native trial already separates initial rise from exit (exitStart>=.5). An exit beginning during a falling owner is typed exit-clock-inconclusive; no new overlap animation. outDur0 has zero native exit motion: keep base behavior and no bottom waiver/transport. native-equivalent has D0 and should preserve exact current paint. D must be finite nonnegative, derived rather than fixture-hardcoded. Existing coordinate ceiling65536 includes expanded source supports/d. Bound malformed/negative/nonfinite/out-of-domain values explicitly.

Policy clock is original effective source cut, not avoidance region time: env.realTime selects fixed placement segment; each main/A/B env.lt/pOut determines that pass's exit. Local exit rule starts strictly after exitStart, expires at effectiveDur, upper endpoint excluded. Actual source drawing lifetime is preserved; no phase extension, hold window, ghost clock synchronization, lag change or alpha threshold shortcut.

## Fresh continuous exit supports and circle/stage proof

Introduce small frozen owned helpers in09v, e.g. pileExitData(trial) and pileExitProof(data,plan,cut); final names may change with parent review. Reuse old trial.continuous.units[*].sourceCircleStrict: for main it is complete SETTLED guarded geometry; for mound/heap/dust it is all-phase guarded geometry including body floor. Never translate the old projected screen hull or use only actual sampled frames. For each base source rectangle b and Dmax=outward-rounded D, define new exit source:

x=b.x exactly; y=[down(b.y.min), up(b.y.max+Dmax)]

with current adjacent-double/512EPS numeric reserves and new coordinate-ceiling check. This covers all pOut∈[0,1], guarded font/squash/bounce/material membership and the same original per-pass clocks. Then call unchanged captured A.cameraEnvelope(rectangle(exitSource),plan,cut,20.25) ONCE. Existing20.25 AA/root reserve and copied-vs-live root numerical contract remain explicit; no new formal libm/Canvas guarantee claimed. Check that minimum supports and fixed offset still fit X/top. Require unchanged margin and strict circle clearance for ALL old envelopes plus ALL new exit envelopes (complete geometry even outside bottom). If proof blocks, preserve chosen hold composition and return typed insufficient; no margin enlargement.

Keep q.envelope and q.settledEnvelope EXACT old entrance12 hull values for nonexit phases; add q.exitEnvelope / q.exitSource / q.exitRule. Runtime selects the exitEnvelope ONLY for original valid exit phase; otherwise uses q.envelope and original main f>=1 settledEnvelope rule. Do not use old settledEnvelope to test moved exit glyphs. All owners must have one unique proof; no absent heap/dust event is force-painted by the proof union. Circle check runs against actual un-clipped polygons on every pass, with full support proof independent of sampled observations.

For representative push, independently recomputed conservative camera RECTANGLES (supersets of exact hull) pass circle, X/top for all164 owners. Minimum Y331.22269570693527>circle.cy302.4; downward sweep does not decrease distance to that circle. Extended conservative maxY819.09;114 proof-only owner hulls cross bottom. These are proof-union owners, not actual simultaneous emissions. Existing final raw actual maxY695.7971 would become784.7034. This forces honest bottom-exit policy; not an all-phase stage-contained result. source-algebra.py/json calculate this without any product execution. Other fixtures/cameras remain unqualified until later execution and fresh proof.

## Runtime stage policy and truthful ledger

Retain factual stageContained=all actual vertices in four sides. Retain strictCircleClear using un-clipped actual geometry. stagePolicySatisfied separately means:

* X must always be within[0,W].
* NegativeY allowed ONLY for an original main owner with existing0<=f<1 top-entry rule; unchanged ledger/expiry.
* Y>H allowed ONLY for an owner with validated exitRule during that pass's original exitStart<lt<effectiveDur and0<pOut<1. No body/heap exception before exit, no bottom allowance because another owner is falling, no global/always-on relaxation.
* All remaining sides/phases strict; source-specific top and bottom rules do not authorize each other.

Each actual polygon crossing bottom yields exitLedger row owner/kind/pass/lt/pOut/exitStart/expiry/sourceDeltaY/side:'bottom'/outsideVertices/reason:'original-source-exit displacement restoration'. Record all crossing vertices before clipping. The final source endpoint has zero source paint by unchanged source lifetime/alpha; direct endpoint probes must truthfully report what actually paints and cannot create an indefinite pOut1 waiver. At runtime repeat original clock/descriptor checks and fail closed on stale/malformed phase. No circle exception.

## Certificate / cache dependencies

Bump local adapter REV to a new pile-native-entry-exit-source-v3 (exact name after implementation). Compact recipe stores exit descriptor scalar D/native/currentAout/effective clock interval, no full trial/metrics/cell tables. Certificate has old entryProof, new exitProof, new perowner phase support and rule, separate factual vs policy assertions, same fixed composition/quality/offset. trajectory.sourceProof precisely states both narrow source entry/exit policies and remaining limitations. If09k wording changes, it is wording-only to avoid obsolete strict-bottom claims; no09k behavior/status change. Build/JAEN later only after source review/authorization.

Add every new helper identity to existing dependency refs, plus existing pilePhysicalFrame/11p source identities. Capture deps before preparation, check after base selection/exit proof, and every render INCLUDING FIRST warm completed-cache-decoded frame. Owned numeric exit descriptor must survive plain serialized numeric identity cache binding; no WeakMap-only external trial needed for render. Source/clock/font/camera/helper drift rejects PILE_STALE_DEPENDENCY. Existing noactive/OFF paths remain unchanged; no new generic cache behavior. Old dependency failure histories retained.

## Planned source scope after parent approval

Only09v exit helper/frame metadata,09x local cert/proof/phase/ledger/dependency logic,11p PILE SECTION source context ops/catalog, optional09k one-line inventory wording. Nonpile11p/card09p byteexact pinned; no card code change. SOURCE implementation starts only on parent approval of this design; no browser/module/media/main/Git now.

## Later qualification gates (not executed)

Parent first reviews source/math/runner/prepins. Then one authorized bounded ordinary local runner should retain prior failures and test: representative source/ghost clocks; second bounded gap/unicode fixture and two regions; all nonexit old/new frames pixel/catalog exact; when/.34/materialfade/launch/seed/run/membership unchanged; actual new exit polygons equal base event transformed by sourceY within current numerical model; native exit time-displacement component restored; explicit honest bottom ledger; all circle/X/top proofs and observations; direct/replay native live-root parity; expiry/outDur0/exitStart/first-impact boundary probes; unsupported Dutch and overlap clocks typed; fonts/helper/camera stale checks; first decoded-cache frame equality; noactive/OFF/nonpile controls. Samples falsify, continuous proof owns safety. Formal performance/fullD/009/humanmotion approval not inferred from this gate. New representative native60 media/independent visual review only after source/raw acceptance and separate authorization.
