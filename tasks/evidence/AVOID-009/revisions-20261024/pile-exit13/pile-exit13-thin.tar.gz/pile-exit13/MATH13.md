# Exit13 implemented source / math review (UNEXECUTED)

Base four sources are exact current work5d110265 copies. Modified source is only source/09v,09x,11p PILE,09k inventory sentence. before-index.html is byteexact current standalone; after-index.html is four literal source replacements, each old source occurs exactly once. No common recorder/transport/renderer/cache, card or other layout changes. Node --check compiles syntax only; no product module is instantiated.

## Scalar and time

D=.5*nativeHm-currentPhysicalAout, d=D*inCubic(env.pOut). D is taken from frozen original trial/native dimensions and source effective cut clock, never fixture literals. .5*nativeHm=132.12000000000006, current33.030000000000015, D99.09000000000005 in representative. Native-equivalent D0 and outDur0 do not get a recipe.exit or any source ctx op. Physical restoring D>0 requires captured rotationless stock camera and exitStart>=max(.5,latestImpact). New restriction is applied after original candidate/first witness/entrance have been selected, so failure never changes accepted hold pose.

pOut0 means d0, no save/translate/restore source op. Otherwise the one owned ctx translate encloses every source-owned paint command including body floor. Each pass uses its actual env.pOut. Source slots/rest/surface/heap/dust geometry, source membership and painter order are kept exactly; catalog.exitTransport declares that fields remain BASE SOURCE, and actual event matrices include the extra sourceY transport. No imported paint is skipped, no mask/clip/ghost synchronization is added.

For fixed source point P(t), camera C(t), fixed placement o, actual point is C(t)(P(t)+(0,d(t)))+o. Existing camera/offset application still occurs once. In current rotationless camera, C linear vertical coefficient is positive and sourceY doesn't affect X. For this push fixture scale=1+.03*.65*lt/4. Thus old/new screenY difference is scale*d, up to the already documented native/copy root numerical precision. Runtime observes both un-clipped source/camera polygons and final placement polygons. Exact direct/live-root replay must be verified by execution; static support of translate/save/restore in09a is already established.

## Fresh exit support

Old continuousTrial.sourceCircleStrict is complete material or settled main support. By requiring exitStart>=latestImpact, it covers every reachable exit owner before the added motion; initial rise already finished. Dust support includes all original tau[0,.35] and physical rise; material union remains conservative over conditional native membership/cap/break.

For b=(bx,by), directed Dmax=guard(up(D+512EPS*(1+abs(D)))). Let rounding=512EPS*(1+abs(by0)+abs(by1)+Dmax). Exit source box is x=bx, y=[down(by0-rounding),up(up(by1+Dmax)+rounding)]. Check finite coordinates inside65536. Since0<=inCubic(clamp(pOut))<=1, every moved source point lies in this box under the inherited practical binary64/Canvas numerical model. Project rectangle once with captured unchanged A.cameraEnvelope(...,20.25). No old screen hull translation or sample union is used.

09x certifies each new exit hull against fixed original circle+margin, X and TOP; BOTTOM is separately source-phase-limited. Keep old unit.envelope and unit.settledEnvelope exact. Runtime tests exitEnvelope only during validated own-pass source exitStart<lt<expiry and0<pOut<1. Otherwise tests original envelope/settledEnvelope. Circle actual geometry remains strict in every phase; full un-clipped exit hull remains in proof. Top rule continues original0<=f<1 per main owner. All164 representative units pass even a conservative rectangular projection's circle/X/top check, but this Python result is one fixture/source algebra only and does not replace product proof execution or certify another camera/fixture.

## Endpoint / ghost tail: corrected earlier assumption

06_layouts J.mainDraw with EXIT.cut does NOT itself suppress main text at pOut1. Normal source selection is J.lyricCutsAt(plan,tp). At realTime=dur, main's tp=dur is expired, while lagged A/B can still have tp<dur. Region selection uses realTime; if last region ended atdur these ghosts can be outside active avoidance region. This is existing boundary behavior; no012-style residue/region fix is introduced.

Therefore forced direct A.record/drawCut at lt>=dur may retain main text. Runner keeps both before/after raw source events and polygons, labels them outsideSourceLifetime/stagePolicyGuaranteed:false, and never counts them as safe exit policy. No source paint deletion and no pOut1/expiry waiver. Ordinary Renderer.frame atrealTime4 records actual pass clocks and any inactive-region observations as DIAGNOSTIC_NOT_SAFE_ACCEPTANCE. The source endpoint observation is not assumed empty and no actual browser result is claimed yet.

## Dependency/cache/certificate

Local REV is pile-native-entry-exit-source-v3. New pileExitData/pileExitProof helper IDs join existing dependency refs. Source render/pilePhysicalFrame/record/replay/camera identities remain in refs; checks before/after preparation and every render, including first decoded-cache frame. Compact recipe.exit stores only derived scalar descriptor/original clocks; no full trial/cell table required at render. Exit failure is explicit unsupported/insufficient on already selected composition; no alternate witness search or safe fallback. Existing generic unsupported restore is not SAFE;017 preflight required.

ExitProof carries scalar descriptor, delta range, perpass tags, X/top/circle outcome; owner proof carries source support, fresh camera exitEnvelope, clock rule. Observations retain factual stageContained separately from stagePolicySatisfied and full owner/pass/phase/expiry/outsideVertices exitLedger. Future execution must verify these promises. No human approval/performance/full009 acceptance inferred.
