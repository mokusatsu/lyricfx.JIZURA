from pathlib import Path
p=Path('/tmp/avoid009-card-fullscreen02/src/11p_layoutsD.js');s=p.read_text();start=s.index('/* ================================================================== 3 flipCards');end=s.index('/* ================================================================== 4 accordion',start);c=s[start:end]
c=c.replace("recipe?.strategy === 'stationary-field-opening-cells-v2'","recipe?.strategy === 'fullscreen-stationary-field-v3'")
a=c.index('    // ON-only stationary field:');b=c.index('    const primaryCell',a)
c=c[:a]+'''    // ON-only full viewport lattice. No source lyric is stored in blank cells.
    // The whole field shares native paper dimensions/pitch and one fixed phase.
    const fieldCells = [], selectedCells = new Map(), glyphPass = [];
    const fieldFail = message => { const e = Error(message); e.code = 'FLIPCARDS_FIELD_RECIPE'; throw e; };
    if (fieldRecipe) {
      if (!Array.isArray(recipe.assignments) || recipe.assignments.length !== n || !recipe.grid || ![recipe.grid.x,recipe.grid.y].every(Number.isFinite) || ![1,.95,.9,.85,.8,.75].includes(recipe.fontScale)) fieldFail('Finite full field phase, source assignments and accepted font level required');
      const {x:gx,y:gy}=recipe.grid;
      const c0=Math.floor((-cw/2-gx)/sx)+1,c1=Math.ceil((W+cw/2-gx)/sx)-1,r0=Math.floor((-chh/2-gy)/sy)+1,r1=Math.ceil((H+chh/2-gy)/sy)-1;
      const nc=c1-c0+1,nr=r1-r0+1;
      if (![c0,c1,r0,r1,nc,nr].every(Number.isSafeInteger) || nc<1 || nr<1 || nc>512 || nr>512 || nc*nr>512) fieldFail('Full field cell ceiling512 before allocation');
      for(let row=r0;row<=r1;row++)for(let column=c0;column<=c1;column++){
        const nativeIndex=cards.findIndex(cd=>cd.r===row&&cd.j===column),peek=Pm.table&&[-1,nativeRowsL].includes(row)&&column>=0&&column<nativePer;
        fieldCells.push({id:'field.'+row+'.'+column,origin:peek?'native-table':'literal-field',row,column,x:gx+column*sx,y:gy+row*sy,appearanceOrdinal:nativeIndex<0?null:ord[nativeIndex],owner:peek?'flipCards.table.'+row+'.'+column:'flipCards.blank.'+row+'.'+column});
      }
      if (new Set(recipe.assignments).size!==n) fieldFail('One unique field cell per source lyric required');
      recipe.assignments.forEach((id,i)=>{const cell=fieldCells.find(c=>c.id===id);if(!cell)fieldFail('Every lyric needs an existing full field cell');selectedCells.set(id,i);cell.assignedLyricIndex=i;cell.owner='flipCards.card.'+i;});
      const reading=recipe.assignments.map(id=>fieldCells.find(c=>c.id===id));
      if(reading.some((c,i)=>i&&(c.row<reading[i-1].row||c.row===reading[i-1].row&&c.column<=reading[i-1].column)))fieldFail('Stable row-major source reading order required');
      for(const cell of fieldCells)cell.contentKind=selectedCells.has(cell.id)?'source-lyric':cell.origin==='native-table'?'literal-native-peek':'literal-blank-back';
    } else if (recipe) fieldFail('Only full viewport stationary field recipes are supported');
''' +c[b:]
c=c.replace("fieldRecipe?{assignments:recipe.assignments,extraCells:recipe.extraCells}:null","fieldRecipe?{assignments:recipe.assignments,grid:recipe.grid,paintOrder:'all-paper-then-source-glyphs-v1'}:null")
c=c.replace('    if (Pm.table) {','    if (Pm.table && !fieldRecipe) {',1)
c=c.replace("          if (fieldRecipe && selectedCells.has('table.'+rr0+'.'+j)) continue; // one selected surface replaces this literal peek\n",'')
a=c.index('    if (fieldRecipe) for (const cell');b=c.index('    cards.forEach',a)
c=c[:a]+'''    if (fieldRecipe) for (const cell of fieldCells) if (cell.assignedLyricIndex == null) {
      const prior=env.drawOwnership;
      env.drawOwnership={role:'independentDecor',owner:cell.owner};
      try {
        const ta=tin(env,0,.4,E.outCubic)*(1-E.inCubic(J.clamp((env.pOut-.4)/.6)));
        if(cell.contentKind==='literal-native-peek'){
          let p=0,ch=null;
          if(Pm.peek){const T=1.3,kk=Math.floor(env.ltb/T),f=env.ltb/T-kk;
            if(kk>=1&&J.h(s,kk,5)%(nativePer*2)===cell.column+(cell.row<0?0:nativePer)){p=f<.25?E.inOutCubic(f/.25):f<.6?1:1-E.inOutCubic((f-.6)/.25);ch=J.h(s,kk,6)%2?'？':'★';}}
          const r=drawCard(cell.x,cell.y,p,ch,false,0,ta*.8,1);
          if(r.up&&ch){const item={text:ch,font:Pm.font,size:k*.46,x:cell.x,y:cell.y,sx:Math.abs(r.c)*r.sc2,sy:r.sc2,color:sc.accent===faceC?faceT:sc.accent,alpha:ta*.8,ghost:false};
            if(env.withDProjectedText)env.withDProjectedText('flipCards-face',()=>env.draw(item));else env.draw(item);}
        }else{
          const appear=cell.appearanceOrdinal==null?ta:tin(env,cell.appearanceOrdinal*.02,.25,E.outCubic)*(1-E.inCubic(J.clamp((env.pOut-.55)/.45)));
          drawCard(cell.x,cell.y,0,null,false,0,appear,1);
        }
      } finally {env.drawOwnership=prior;}
    }
''' +c[b:]
a=c.index('      const m = [Math.abs(r.c)');b=c.index('      } finally { if (nativeD) env.drawOwnership = prior; }',a)
glyph=c[a:b]
c=c[:a]+'''      const drawGlyphs=()=>{
        const priorGlyphOwnership=env.drawOwnership;
        if(nativeD)env.drawOwnership={role:'primary',owner:'flipCards.card.'+i};
        try {
'''+glyph+'''        } finally {if(nativeD)env.drawOwnership=priorGlyphOwnership;}
      };
      if(fieldRecipe)glyphPass.push(drawGlyphs);else drawGlyphs();
'''+c[b:]
c=c.replace('    const bw = per * sx, bh = rowsL * sy;','    for(const drawGlyphs of glyphPass)drawGlyphs();\n    const bw = per * sx, bh = rowsL * sy;')
s=s[:start]+c+s[end:];p.write_text(s)
