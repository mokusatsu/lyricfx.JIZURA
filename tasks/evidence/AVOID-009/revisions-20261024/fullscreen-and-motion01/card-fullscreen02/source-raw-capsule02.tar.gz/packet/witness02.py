import gzip,json,math,itertools,hashlib
p='/tmp/avoid009-flipcards-revision02/focused-raw02.json.gz'
r=json.load(gzip.open(p))['rows'][0];g=r['records'][0]['nativeG'];s=r['trajectory']['units'][0]['segments'][0];k=g['k'];cw=g['cw'];ch=g['chh'];lw=g['lw'];W=960;H=540;sx=1.16*k;sy=ch+.16*k;guard=8*lw+10
local=[-.55*cw-guard,-.605*ch-guard,.55*cw+.125*k+guard,.605*ch+.175*k+guard]
# All already measured .9-font outlines and their unchanged two-device-pixel guard fit body-bound branch.
for u in s['unitProofs']:
 pts=sum(u['source']['fontOutlines'],[])
 gb=[min(x for x,y in pts)-2,min(y for x,y in pts)-2,max(x for x,y in pts)+2,max(y for x,y in pts)+2]
 assert gb[0]*1.1-20>=local[0] and gb[1]*1.21-20>=local[1] and gb[2]*1.1+20<=local[2] and gb[3]*1.21+20<=local[3]
maxscale=1+.03*.8125
circle=(480,226.8,108);margin=2.7
# A convex hull and point/segment distances reconstruct source cameraEnvelope without module/browser.
def hull(points):
 p=sorted(set(points));cross=lambda o,a,b:(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);lo=[];hi=[]
 for a in p:
  while len(lo)>1 and cross(lo[-2],lo[-1],a)<=0:lo.pop()
  lo.append(a)
 for a in reversed(p):
  while len(hi)>1 and cross(hi[-2],hi[-1],a)<=0:hi.pop()
  hi.append(a)
 return lo[:-1]+hi[:-1]
def env(x,y):
 pts=[]
 for xx,yy in itertools.product([x+local[0],x+local[2]],[y+local[1],y+local[3]]):
  for sc in [1,maxscale]:
   a=480+(xx-480)*sc;b=270+(yy-270)*sc
   pts += list(itertools.product([a-20,a+20],[b-20,b+20]))
 return hull(pts)
def dist(poly):
 px,py,_=circle;ds=[]
 if all((b[0]-a[0])*(py-a[1])-(b[1]-a[1])*(px-a[0])>=0 for a,b in zip(poly,poly[1:]+poly[:1])):return 0
 for a,b in zip(poly,poly[1:]+poly[:1]):
  vx=b[0]-a[0];vy=b[1]-a[1];t=max(0,min(1,((px-a[0])*vx+(py-a[1])*vy)/(vx*vx+vy*vy)))
  ds.append(math.hypot(px-a[0]-t*vx,py-a[1]-t*vy))
 return min(ds)
def safe(x,y):
 p=env(x,y);return all(0<=a<=W and 0<=b<=H for a,b in p) and dist(p)>=108+margin
xmin=max(W/2+(20-W/2)/sc-local[0] for sc in [1,maxscale])
xmax=min(W/2+(W-20-W/2)/sc-local[2] for sc in [1,maxscale])
span=6*sx
assert xmax-xmin>=span
x0=(xmin+xmax-span)/2
selected=[(j,0,x0+j*sx,270) for j in [0,1,5,6]]
assert all(safe(x,y) for j,i,x,y in selected)
witness={'phaseDerivation':{'admissibleStageX':[xmin,xmax],'sixPitchSpan':span,'firstX':x0,'formula':'firstX=(admissibleMin+admissibleMax-6*sx)/2; j=[0,1,5,6]'},'selected':selected}
counts=[1]
witness['primaryEnvelopes']=[{'xy':[x,y],'envelope':env(x,y),'stageMin':min(min(a,W-a,b,H-b) for a,b in env(x,y)),'circleDistance':dist(env(x,y))} for j,i,x,y in witness['selected']]
witness.update({'status':'SOURCE_ALGEBRA_WITNESS_NOT_RUNTIME_ACCEPTANCE','rawSha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'localBounds':local,'native':{'W':W,'H':H,'k':k,'cw':cw,'chh':ch,'sx':sx,'sy':sy,'lw':lw},'fontScale':.9,'sourceText':r['spec']['text'],'maxScale':maxscale,'circle':circle,'margin':margin,'phasesTried':len(counts)})
with open('/tmp/avoid009-card-fullscreen01/witness02.json','w') as f:json.dump(witness,f,indent=2)
print(json.dumps(witness,indent=2))
oldg=r['records'][0]['g'];olds=s['unitProofs'][0]['envelopes'][0]
oldxy=(oldg['cards'][0]['x'],oldg['cards'][0]['y'])
assert max(min(math.hypot(x-a,y-b) for a,b in olds) for x,y in env(*oldxy))<1e-10
paperhalf=.5*math.sqrt(1.01)*k
shadowright=(math.sqrt(.5**2+.125**2)+.05)*k
outline=lw*math.sqrt(2)/2*10
fontx=max(abs(x)*1.1 for u in s['unitProofs'] for x,y in sum(u['source']['fontOutlines'],[]))
separation={'paperHalfWidthCauchy':paperhalf,'shadowRightCauchy':shadowright,'outlineUnchangedMiterReserve':outline,'completeFontCoreX':fontx,'laterPaperOutlinePathAAToEarlierCompleteFontGap':sx-paperhalf-outline-10-fontx,'laterShadowPathAAToEarlierCompleteFontGap':sx-shadowright-10-fontx,'laterGlyphDeviceAAToEarlierCompleteFontGap':sx-2*fontx-20,'completePaperCoreGap':sx-2*paperhalf,'paperVsShadowCoreGap':sx-paperhalf-shadowright,'AAExplanation':'Target complete font/stroke/font guard is protected from later source core plus full worst-.1 device raster guard; AA rectangles of BOTH objects can overlap without either physical core being covered. No primary circle/stage/raster guard reduced. Whole paper rim AA disjointness is not claimed.'}
assert min(separation[k] for k in ['laterPaperOutlinePathAAToEarlierCompleteFontGap','laterShadowPathAAToEarlierCompleteFontGap','laterGlyphDeviceAAToEarlierCompleteFontGap','completePaperCoreGap','paperVsShadowCoreGap'])>0
xs=[x0+j*sx for j in range(-10,10) if x0+j*sx+cw/2>0 and x0+j*sx-cw/2<W]
ys=[270+i*sy for i in range(-5,5) if 270+i*sy+ch/2>0 and 270+i*sy-ch/2<H]
witness['fullField']={'columns':len(xs),'rows':len(ys),'count':len(xs)*len(ys),'xs':xs,'ys':ys,'paperExtent':[min(xs)-cw/2,min(ys)-ch/2,max(xs)+cw/2,max(ys)+ch/2],'missingLatticeCells':0}
witness['separation']=separation;witness['existingRecordedEnvelopeMatch']='Existing selected primary0 six hull vertices match reconstructed source formula within1e-10'
with open('/tmp/avoid009-card-fullscreen01/witness02.json','w') as f:json.dump(witness,f,indent=2)
print(json.dumps({'separation':separation,'fullField':witness['fullField']},indent=2))
