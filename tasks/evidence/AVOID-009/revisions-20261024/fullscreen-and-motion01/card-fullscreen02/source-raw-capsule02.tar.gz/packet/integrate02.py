from pathlib import Path
import hashlib,json,gzip,os,shutil,subprocess,time,sys
root=Path('/tmp/avoid009-card-fullscreen02');main=Path('/workspace/lyricfx.JIZURA');changes=['src/09p_layoutsD_flipCards.js','src/11p_layoutsD.js']
assert not (root/'integration-receipt02.json').exists(),'Do not overwrite receipt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def paths():return sorted(str(p.relative_to(main)) for p in main.rglob('*') if p.is_file() and '.git' not in p.relative_to(main).parts)
files=sorted((main/'src').glob('*.js'))+[main/'build.py',main/'index.html',main/'en/index.html',main/'app/__pycache__/english.cpython-312.pyc',main/'.git/index']
before={str(p.relative_to(main)):sha(p) for p in files};beforePaths=paths()
(root/'integration-before02.json.gz').write_bytes(gzip.compress(json.dumps({'hashes':before,'allExistingFilePaths':beforePaths,'note':'No Git command: complete existing path set plus git index hash protects index/skip flags; untracked files not deleted or renamed'},ensure_ascii=False).encode(),mtime=0))
prepared=json.loads((root/'prepared02.json').read_text())
for pin in prepared['pins']:
 p=Path(pin['path']) if pin['path'].startswith('/') else root/pin['path'];assert sha(p)==pin['sha256'],str(p)
oldEN=(main/'en/index.html').read_text();old={n:(main/n).read_text() for n in changes}
for n in changes:shutil.copyfile(root/n,main/n)
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
r=subprocess.run([sys.executable,'build.py'],cwd=main,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(root/'integration-build02.log').write_text(r.stdout)
after={str(p.relative_to(main)):sha(p) for p in files};afterPaths=paths()
unchanged=[n for n in before if n not in changes+['index.html','en/index.html']]
assert all(before[n]==after[n] for n in unchanged),'Non-target source/build/index/pycache changed'
assert beforePaths==afterPaths,'Existing path set changed'
assert r.returncode==0,'Offline build failed'
assert sha(main/'index.html')==sha(root/'index.html'),'Qualified JA must be byte exact'
sys.dont_write_bytecode=True;sys.path.insert(0,str(main));from app.english import localize_js
expectedEN=oldEN
for n in changes:
 a=localize_js(old[n],n);b=localize_js((root/n).read_text(),n);assert expectedEN.count(a)==1,n;expectedEN=expectedEN.replace(a,b,1)
assert expectedEN==(main/'en/index.html').read_text(),'English only exact localized2source replacement'
assert sha(main/'app/__pycache__/english.cpython-312.pyc')==before['app/__pycache__/english.cpython-312.pyc']
receipt={'status':'EXACT_TWO_SOURCE_MAIN_INTEGRATION_AND_OFFLINE_JA_EN_BUILD','parentProvidedHead':'1d62d5f3','sourceCandidate':'fullscreen02 accepted parent actual36375 / raw78b42dd9a2180435188c397e779ce0640a2ba9aa264e43d90db264deba690a7e','copiedSource':{n:after[n] for n in changes},'unchangedOtherSources':len([n for n in unchanged if n.startswith('src/')]),'nonFlip11pByteExact':'Verified during source packet sealing and parent review','buildPyUnchanged':before['build.py']==after['build.py'],'buildCommand':'PYTHONDONTWRITEBYTECODE=1 python3 build.py','buildExit':r.returncode,'generated':{n:after[n] for n in ['index.html','en/index.html']},'qualifiedIsolatedJAByteExact':True,'englishExactTwoLocalizedSourceReplacement':True,'pycacheUnchanged':after['app/__pycache__/english.cpython-312.pyc'],'gitIndexHashUnchanged':before['.git/index']==after['.git/index'],'allExistingFilePathsUnchanged':True,'existingFileCount':len(beforePaths),'gitOperations':0,'newBrowserRuns':0,'newMediaRuns':0,'publicResultChecks':0,'beforeReceipt':'integration-before02.json.gz'}
(root/'integration-receipt02.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
