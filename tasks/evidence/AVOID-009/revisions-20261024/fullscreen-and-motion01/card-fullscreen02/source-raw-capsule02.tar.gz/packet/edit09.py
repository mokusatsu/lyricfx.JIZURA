from pathlib import Path
p=Path('/tmp/avoid009-card-fullscreen02/src/09p_layoutsD_flipCards.js');s=p.read_text();s=s.replace("const A=J.placement,ID=", "const stockPush=J.CAMERA.push?.get;\nconst A=J.placement,ID=",1)
s=s.replace("fontOutlines,attachment:","fontOutlines,localBounds:[x0,y0,x1,y1],attachment:",1)
a=s.index(' const allowedDecor=new Set();');b=s.index(" if(program.events.some",a)
s=s[:a]+''' const allowedDecor=new Set();if(g.fieldRecipe){if(g.fieldDraws.length!==g.fieldCells.length||new Set(g.fieldDraws).size!==g.fieldCells.length||g.fieldCells.some(c=>!g.fieldDraws.includes(c.id)))fail('FLIPCARDS_FIELD_LEDGER','Exactly one physical draw per full field cell required');for(const c of g.fieldCells)if(c.assignedLyricIndex==null)allowedDecor.add(c.owner);
  const primaryItems=program.events.filter(e=>e.role==='primary'&&e.kind==='item'),paper=program.events.filter(e=>e.kind!=='item');if(primaryItems.length&&paper.some(e=>e.order>primaryItems[0].order))fail('FLIPCARDS_PAINT_ORDER','Every field paper/shape/shadow must precede original source rank/main glyphs');
 }else if(g.table){const rows=Math.max(...g.cards.map(c=>c.r))+1,per=Math.max(...g.cards.map(c=>c.cnt));for(const r of [-1,rows])for(let j=0;j<per;j++)allowedDecor.add('flipCards.table.'+r+'.'+j);}
''' +s[b:]
a=s.index('// Finite stationary-field candidates.');b=s.index('\nconst contains=',a)
s=s[:a]+Path('/tmp/avoid009-card-fullscreen02/new09helpers.txt').read_text()+s[b:]
s=s.replace("id:'flipCards-stationary-field-v2'","id:'flipCards-fullscreen-field-v3'")
s=s.replace('No common stationary field assignment satisfies complete primary and distinct-cell proofs','No common full viewport field assignment satisfies complete primary and two-pass physical/font proofs')
p.write_text(s)
