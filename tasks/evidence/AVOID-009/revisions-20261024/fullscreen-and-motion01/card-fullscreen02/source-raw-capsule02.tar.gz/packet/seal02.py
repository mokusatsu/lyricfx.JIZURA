from pathlib import Path
import hashlib,json,difflib,os
root=Path('/tmp/avoid009-card-fullscreen02');main=Path('/workspace/lyricfx.JIZURA')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
html=(root/'baseline/index.html').read_text();changes=['09p_layoutsD_flipCards.js','11p_layoutsD.js']
for n in changes:
 old=(main/'src'/n).read_text();assert html.count(old)==1;html=html.replace(old,(root/'src'/n).read_text(),1)
(root/'index.html').write_text(html)
patch=''.join(''.join(difflib.unified_diff((main/'src'/n).read_text().splitlines(True),(root/'src'/n).read_text().splitlines(True),fromfile='a/src/'+n,tofile='b/src/'+n)) for n in changes)
(root/'source.patch').write_text(patch)
old=(main/'src/11p_layoutsD.js').read_text();new=(root/'src/11p_layoutsD.js').read_text();a='/* ================================================================== 3 flipCards';b='/* ================================================================== 4 accordion';assert old[:old.index(a)]==new[:new.index(a)];assert old[old.index(b):]==new[new.index(b):]
mainfiles=sorted((main/'src').glob('*.js'))+[main/'build.py',main/'index.html',main/'en/index.html',main/'dev/browser.cjs',main/'app/__pycache__/english.cpython-312.pyc']
(root/'sourcepins-before.json').write_text(json.dumps({'mainFiles':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in mainfiles],'nonFlip11pExact':True,'other97SourcesUntouched':True,'mainEdits':0,'gitOperations':0},indent=2)+'\n')
localfiles=sorted(p for p in root.rglob('*') if p.is_file() and p.name not in ['prepared02.json'] and not p.name.startswith('focused-raw') and not p.name.startswith('focused-progress'))
runtime=[main/'dev/browser.cjs',Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'),Path('/usr/bin/chromium'),Path('/usr/lib/chromium/chromium'),Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')]
node=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')
for package in ['playwright','playwright-core']:
 runtime.extend(p for p in (node/package).rglob('*') if p.is_file() and p.suffix in ['.js','.cjs','.mjs','.json'])
files=list(dict.fromkeys(localfiles+mainfiles+runtime));pins=[]
for p in files:pins.append({'path':str(p.relative_to(root)) if p.is_relative_to(root) else str(p),'sha256':sha(p),'bytes':p.stat().st_size})
(root/'prepared02.json').write_text(json.dumps({'status':'SEALED_SOURCE_RUNNER_REVIEW_PACKET_NOT_EXECUTED','pins':pins,'pinCount':len(pins),'baseline':'current main byte copy; only two source replacements in candidate HTML','sourceMainEdits':0,'buildRuns':0,'moduleRuns':0,'syntaxRuns':0,'browserRuns':0,'mediaRuns':0,'gitOperations':0,'publicResultChecks':0,'exactBrowserCommandNotExecuted':'node /tmp/avoid009-card-fullscreen02/focused-runner02.cjs'},indent=2)+'\n')
print(json.dumps({'pins':len(pins),'localBytes':sum(p.stat().st_size for p in root.rglob('*') if p.is_file()),'sourcePatchSha256':sha(root/'source.patch'),'preparedSha256':sha(root/'prepared02.json'),'execution':0}))
