# AVOID-009 fullscreen card02 source review packet

PREPARED, NOT EXECUTED. Isolated two-source candidate; main product unchanged.
Parent provided current work HEAD1d62d5f3; no Git command issued by child. Current main baseline includes pile entry ee5a2788 and prior flipcards field02. Copy baseline HTML verbatim, replace exactly the two complete source bodies to create isolated index.html; no build/module evaluation.

Review files: source.patch, src/09p_layoutsD_flipCards.js, src/11p_layoutsD.js, DESIGN02.md, witness02.py/json, focused-runner02.cjs, prepared02.json, sourcepins-before.json. Source review now includes render-time domain() check as requested by parent. No generic placement/registry/cache/renderer changes; non-flip11p regions exactly retained.

Contract: ON full source-derived regular viewport field, native paper/pitch; fixed single-row source assignment derived from complete guarded stage/circle support. Full primary stage/circle/attachment and render event guard unchanged. All paper/shape/shadow painted first, primary rank/main groups afterwards in original source order and original source clocks. Same-row physical paper cores separated; complete font/stroke/font-space core protected against later glyph's unchanged worst-scale device guard. Old both-object raster gaps remain diagnostic; overlap count is explicitly recorded and rimHaloSeparation false. Closed blank geometry uses p0; generated blanks contain no lyric. Native table peeks retain source row/column/seed/clock and share chosen whole-grid phase. OFF uses original native path.

Domain deliberately narrow: exact stock push getter, contentScale1..4, motionScale0..1, fx.motion0..1, no ghost/chroma/shake. Typed unsupported outside. Bound512cells,64regions,14owners,4096nodes/font,64candidate assignments/font,64phases/font, original ordered sixfontlevels and readability floors; explicit size uses original fontsize only. Single-row restriction means portrait/ragged13/owners14 etc may honestly be insufficient. No success expectation is imposed except the approved representative; blocked radius.45 must remain insufficient.

Focused runner tests selected4, random order,tablefalse,blocked.45,portrait,ragged13,owners14,camera unsupported,two regions,explicit1,unsupported order. Avoidance input contract preflight; case-level compressed raw saved durably; full raw written before assertions. At .1/1/4 it records all events and full field metadata, compares source identity/order/card dimensions and every original clock, verifies source glyphs after every paper, complete field row/column/pitch/cardinality/coverage, stage/circle bounds and render coverage. Completed-plan warm decode requires cache hit plus fresh root/cut/trajectory and equal content; cold/warm times are observations, not formal performance acceptance. OFF hashes compare current main baseline at identical six times. All sealed inputs rehash before and after. Runtime dependencies referenced in place; no duplicate runtime/CAS or cleanup.

Not executed commands, requiring parent's source/runner/pin approval first:

    node --check /tmp/avoid009-card-fullscreen02/src/09p_layoutsD_flipCards.js
    node --check /tmp/avoid009-card-fullscreen02/src/11p_layoutsD.js
    node --check /tmp/avoid009-card-fullscreen02/focused-runner02.cjs
    node /tmp/avoid009-card-fullscreen02/focused-runner02.cjs

Runner uses /usr/bin/chromium and dev/browser.cjs launch policy, routes only127.0.0.1 local URLs, and blocks every external request. No media/image/view/public operation; public result checks permanently0. No prior raw/capsule/CAS/22missing archive/pycache/untracked files modified or removed. Initial free /tmp162MB,/workspace209MB; this small packet duplicates only baseline+candidate HTML (~12MB),2sources and small text, not workspace/runtime.
