from pathlib import Path
import gzip,json,hashlib,tarfile,io
root=Path('/tmp/avoid009-card-fullscreen02');main=Path('/workspace/lyricfx.JIZURA')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
raw=root/'focused-raw02.json.gz';checkpoint=root/'focused-progress02.jsonl.gz';canonical=json.loads(gzip.decompress(raw.read_bytes()));rows=[json.loads(line) for line in gzip.decompress(checkpoint.read_bytes()).splitlines()]
assert len(rows)==11 and rows==canonical['rows'],'Canonical raw must exactly preserve all checkpoint rows'
(root/'checkpoint-equivalence02.json').write_text(json.dumps({'canonicalRaw':raw.name,'rawSha256':sha(raw),'checkpointSha256':sha(checkpoint),'rows':len(rows),'allFullRowsDeepEqual':True,'rowSha256':[hashlib.sha256(json.dumps(r,separators=(',',':'),ensure_ascii=False).encode()).hexdigest() for r in rows],'checkpointArchiveOmitted':True,'reason':'Exact full-row equivalence; canonical raw stored once; durable on-disk checkpoint retained unchanged'},indent=2)+'\n')
prepared=json.loads((root/'prepared02.json').read_text());names=sorted((main/'src').glob('*.js'));baseline=(root/'baseline/index.html').read_text();oldSources={}
for n in ['09p_layoutsD_flipCards.js','11p_layoutsD.js']:
 i=[p.name for p in names].index(n);prev=(names[i-1]).read_text();nxt=(names[i+1]).read_text();a=baseline.index(prev)+len(prev)+1;b=baseline.index(nxt,a)-1;oldSources[n]=baseline[a:b].encode()
entries=[];embedded={};external=[];gitrefs=[]
for pin in prepared['pins']:
 p=Path(pin['path']) if pin['path'].startswith('/') else root/pin['path'];want=pin['sha256'];record=dict(pin)
 if p.is_relative_to(root):dest='packet/'+str(p.relative_to(root));assert sha(p)==want;embedded[dest]=p;record.update(storage='embedded',archivePath=dest)
 elif p.is_relative_to(main):
  rel=str(p.relative_to(main));dest='inputs/main/'+rel
  if p.name in oldSources and rel.startswith('src/'):
   data=oldSources[p.name];assert hashlib.sha256(data).hexdigest()==want;embedded[dest]=data;record.update(storage='embedded',archivePath=dest,origin='exact source recovered from pinned baseline HTML')
  elif rel=='index.html':assert sha(root/'baseline/index.html')==want;record.update(storage='embedded-alias',archivePath='packet/baseline/index.html')
  elif rel=='en/index.html':record.update(storage='git-reference',revision='1d62d5f3',gitPath=rel,verification='Parent must resolve Git blob bytes/hash; child does not run Git');gitrefs.append(record)
  else:assert sha(p)==want;embedded[dest]=p;record.update(storage='embedded',archivePath=dest)
 else:assert sha(p)==want;record.update(storage='external-runtime-reference',location=str(p),notStandaloneRuntime=True);external.append(record)
 entries.append(record)
extra=['prepared02.json','focused-raw02.json.gz','focused-progress02-receipt.json','checkpoint-equivalence02.json','integration-before02.json.gz','integration-build02.log','integration-receipt02.json','integrate02.py','parent-card-fullscreen02.py','parent-card-fullscreen02.json','capsule02.py']
for name in extra:embedded['packet/'+name]=root/name
mapping={'inputCount':len(entries),'inputs':entries,'embeddedByteInputs':sum(e['storage']=='embedded' for e in entries),'embeddedAliases':sum(e['storage']=='embedded-alias' for e in entries),'gitReferenceInputs':len(gitrefs),'externalRuntimeInputs':len(external),'canonicalRawOnly':True,'fullCheckpointRowsEquivalent':True,'runtimeStandalone':False,'gitReferenceResolution':'pending parent review; never claimed verified by child'}
(root/'input-map02.json').write_text(json.dumps(mapping,indent=2)+'\n');embedded['packet/input-map02.json']=root/'input-map02.json'
manifest=[]
for name,value in sorted(embedded.items()):
 data=value if isinstance(value,bytes) else value.read_bytes();manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=root/'source-raw-capsule02.tar.gz';assert not archive.exists(),'Do not overwrite archive'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,value in sorted(embedded.items()):
  data=value if isinstance(value,bytes) else value.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 data=(json.dumps({'files':manifest,'inputCount':len(entries),'gitReferences':gitrefs,'externalRuntimeReferences':len(external),'noMedia':True},indent=2)+'\n').encode();info=tarfile.TarInfo('capsule-manifest02.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
receipt={'status':'SMALL_PRIVATE_SOURCE_RAW_CAPSULE_WITH_EMBEDDED_BYTES_GIT_AND_EXTERNAL_RUNTIME_REFERENCES','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'archiveFiles':len(manifest)+1,'sealedInputs':len(entries),'embeddedInputs':mapping['embeddedByteInputs'],'embeddedAliases':mapping['embeddedAliases'],'gitReferenceInputs':len(gitrefs),'externalRuntimeInputs':len(external),'gitReferenceResolutionPendingParent':True,'canonicalRawSha256':sha(raw),'checkpointFullRowsDeepEqual':True,'checkpointDuplicateOmitted':True,'runtimeStandalone':False,'mediaRuns':0,'publicResultChecks':0}
(root/'capsule-receipt02.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
