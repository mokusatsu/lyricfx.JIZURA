import math,json
from pathlib import Path
W,H=960,540;k=H*.86/(3*1.38+2*.16);chh=k*1.38;lw=max(1,.012*k);sx=1.16*k;guard=8*lw+10
local=[min(-.55*k-guard,-(k/2+2)*1.1-20),min(-.605*chh-guard,-(chh/2+2)*1.21-20),max(.675*k+guard,(k/2+2)*1.1+20),max(.605*chh+.175*k+guard,(chh/2+2)*1.21+20)]
outline=lw*math.sqrt(2)/2*10+1;span=1.21*chh+.175*k+2*outline;sep=span+1.5*.16*k;yc=(H-local[1]-local[3])/2
xs=[W/2-1.5*sx-1.4*sx,W/2+1.5*sx+1.4*sx];ys=[yc-sep/2,yc+sep/2]
S=max(1,1+.03*max(.65*1.25,.65),1.02);boxes=[]
for y in ys:
 for x in xs:
  raw=[x+local[0],y+local[1],x+local[2],y+local[3]];b=[min(W/2+(raw[0]-W/2)*v for v in [1,S])-20,min(H/2+(raw[1]-H/2)*v for v in [1,S])-20,max(W/2+(raw[2]-W/2)*v for v in [1,S])+20,max(H/2+(raw[3]-H/2)*v for v in [1,S])+20]
  boxes.append({'center':[x,y],'proofEnvelope':b,'stageClearance':min(b[0],b[1],W-b[2],H-b[3]),'circleMargin':math.hypot(max(b[0]-480,0,480-b[2]),max(b[1]-226.8,0,226.8-b[3]))-108})
physOutline=lw*math.sqrt(2)/2*10+10;physical=[-.55*k-physOutline,-.605*chh-physOutline,.675*k+physOutline,.605*chh+.175*k+physOutline]
result={'status':'ALGEBRA_ONLY_NOT_FONT_OR_BROWSER_SUCCESS','actualSelectedFixture':{'camera':'push','fxMotion':.65,'fxChroma':0,'ghost':0,'events':[],'contentScale':1,'motionScale':1},'cameraEnvelopeMaxScale':S,'acceptedPrimaryLocalBoundsConditionalOnAttachment':local,'recipeFamily':{'pitch':1.4,'physicalGapFraction':1.5,'centers':[[x,y] for y in ys for x in xs]},'envelopes':boxes,'completePreCameraBodyShadowStrokeRasterBounds':physical,'bodyRasterPairGaps':{'nativeToAdded':1.4*sx-(physical[2]-physical[0]),'sameAddedColumn':sep-(physical[3]-physical[1])},'limits':['No actual glyph font measured; complete attachment and glyph pair supports may reject this candidate','Allscale primary stage/circle guard uses unchanged accepted 20px reserve','Pair domain explicitly excludes ghost/chroma/shake/dutch and grows guard for contentScale<1','Original field untouched; four additions required only if native assignments fail']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
