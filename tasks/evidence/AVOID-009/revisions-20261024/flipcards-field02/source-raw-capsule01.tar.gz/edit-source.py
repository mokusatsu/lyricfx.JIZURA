from pathlib import Path
p=Path('/tmp/avoid009-flipcards-revision02/src/11p_layoutsD.js');s=p.read_text()
s=s.replace("const nativeD = cut.placementLayoutsD === true, recipe = nativeD ? cut.layoutDRecipe : null;","const nativeD = cut.placementLayoutsD === true, recipe = nativeD ? cut.layoutDRecipe : null;\n    const fieldRecipe = recipe?.strategy === 'stationary-field-opening-cells-v2';")
old="    if (nativeD) env.placementDGeometry = {kind:'flipCards',k,cw,chh,lw,rows:rowsL,idx:Pm.idx,table:Pm.table,peek:Pm.peek,fd,gapT,cards:cards.map((cd,i)=>({...cd,index:i,ord:ord[i],x:W/2+(cd.j-(cd.cnt-1)/2)*primarySX,y:H/2+(cd.r-(rowsL-1)/2)*primarySY})),fontScale:recipe?.fontScale || 1};"
new="""    // ON-only stationary field: every native physical slot remains in place.
    // A selected slot owns one lyric surface; unused middle slots are literal
    // blank backs, without latent lyric/rank/reveal content. OFF stays native.
    const fieldCells = [], selectedCells = new Map();
    const fieldFail = message => { const e = Error(message); e.code = 'FLIPCARDS_FIELD_RECIPE'; throw e; };
    if (fieldRecipe) {
      if (!Array.isArray(recipe.assignments) || recipe.assignments.length !== n || !Array.isArray(recipe.extraCells) || recipe.extraCells.length > 4 || ![1,.95,.9,.85,.8,.75].includes(recipe.fontScale)) fieldFail('Bounded source field assignments and accepted font level required');
      for (const cd of cards) fieldCells.push({id:'middle.'+cd.r+'.'+cd.j,origin:'native-middle',row:cd.r,column:cd.j,x:W/2+(cd.j-(cd.cnt-1)/2)*sx,y:H/2+(cd.r-(nativeRowsL-1)/2)*sy,appearanceOrdinal:ord[fieldCells.length]});
      if (Pm.table) for (const row of [-1,nativeRowsL]) for (let j=0;j<nativePer;j++) fieldCells.push({id:'table.'+row+'.'+j,origin:'native-table',row,column:j,x:W/2+(j-(nativePer-1)/2)*sx,y:H/2+(row-(nativeRowsL-1)/2)*sy});
      recipe.extraCells.forEach((cell,i)=>{ if (!cell || cell.id !== 'extra.'+i || ![cell.x,cell.y].every(Number.isFinite) || cell.x<0 || cell.x>W || cell.y<0 || cell.y>H) fieldFail('Finite stage-bounded extra cells with canonical IDs required'); fieldCells.push({id:cell.id,origin:'added-perimeter',x:cell.x,y:cell.y}); });
      if (fieldCells.length > 46 || new Set(recipe.assignments).size !== n) fieldFail('Unique selected cells and maximum46 field cells required');
      recipe.assignments.forEach((id,i)=>{const cell=fieldCells.find(c=>c.id===id);if(!cell)fieldFail('Every source lyric needs a declared field cell');selectedCells.set(id,i);cell.assignedLyricIndex=i;});
      if (recipe.extraCells.some(c=>!selectedCells.has(c.id))) fieldFail('No unused extra cells');
      const reading=recipe.assignments.map(id=>fieldCells.find(c=>c.id===id));
      if (reading.some((c,i)=>i && (c.y<reading[i-1].y-1e-7 || Math.abs(c.y-reading[i-1].y)<1e-7 && c.x<=reading[i-1].x))) fieldFail('Stable field row-major reading order required');
      for (const cell of fieldCells) cell.contentKind=selectedCells.has(cell.id)?'source-lyric':cell.origin==='native-middle'?'literal-blank-back':'literal-native-peek';
    } else if (recipe) fieldFail('Only stationary field opening recipes are supported');
    const primaryCell = i => fieldRecipe ? fieldCells.find(c=>c.id===recipe.assignments[i]) : null;
    if (nativeD) env.placementDGeometry = {kind:'flipCards',k,cw,chh,lw,rows:rowsL,idx:Pm.idx,table:Pm.table,peek:Pm.peek,fd,gapT,fieldCells,fieldRecipe:fieldRecipe?{assignments:recipe.assignments,extraCells:recipe.extraCells}:null,cards:cards.map((cd,i)=>({...cd,index:i,ord:ord[i],x:primaryCell(i)?.x??(W/2+(cd.j-(cd.cnt-1)/2)*primarySX),y:primaryCell(i)?.y??(H/2+(cd.r-(rowsL-1)/2)*primarySY)})),fontScale:recipe?.fontScale || 1};"""
assert old in s;s=s.replace(old,new)
old="          const prior = env.drawOwnership;\n          if (nativeD) env.drawOwnership = {role:'independentDecor',owner:'flipCards.table.'+rr0+'.'+j};"
new="          if (fieldRecipe && selectedCells.has('table.'+rr0+'.'+j)) continue; // one selected surface replaces this literal peek\n"+old
assert old in s;s=s.replace(old,new)
old="    cards.forEach((cd, i) => {\n      const prior = env.drawOwnership;\n      if (nativeD) env.drawOwnership = {role:'primary',owner:'flipCards.card.'+i};"
new="""    if (fieldRecipe) for (const cell of fieldCells) if (cell.contentKind === 'literal-blank-back') {
      const prior=env.drawOwnership;
      env.drawOwnership={role:'independentDecor',owner:'flipCards.blank.'+cell.row+'.'+cell.column};
      try {
        const appear=tin(env,cell.appearanceOrdinal*.02,.25,E.outCubic)*(1-E.inCubic(J.clamp((env.pOut-.55)/.45)));
        drawCard(cell.x,cell.y,0,null,false,0,appear,1);
      } finally {env.drawOwnership=prior;}
    }
    cards.forEach((cd, i) => {
      const prior = env.drawOwnership;
      if (nativeD) env.drawOwnership = {role:'primary',owner:'flipCards.card.'+i};"""
assert old in s;s=s.replace(old,new)
old="      const x = W / 2 + (cd.j - (cd.cnt - 1) / 2) * primarySX, y = H / 2 + (cd.r - (rowsL - 1) / 2) * primarySY;"
new="      const x = primaryCell(i)?.x ?? (W / 2 + (cd.j - (cd.cnt - 1) / 2) * primarySX), y = primaryCell(i)?.y ?? (H / 2 + (cd.r - (rowsL - 1) / 2) * primarySY);"
assert old in s;s=s.replace(old,new)
p.write_text(s)
p=Path('/tmp/avoid009-flipcards-revision02/src/09p_layoutsD_flipCards.js');s=p.read_text()
s=s.replace("e.owner.startsWith('flipCards.table.')","(e.owner.startsWith('flipCards.table.')||g.fieldRecipe&&e.owner.startsWith('flipCards.blank.'))")
start=s.index('function finalize(');end=s.index('\nconst contains=',start)
s=s[:start]+r'''// Finite stationary-field candidates. Native cells first; additions never move
// an existing slot. Assignment is fixed for ALL active avoidance regions.
function fieldCandidates(g,plan,cut){
 const cells=g.cards.map(c=>({id:'middle.'+c.r+'.'+c.j,origin:'native-middle',x:c.x,y:c.y})),sx=g.k*1.16,sy=g.chh+g.k*.16,n=g.cards.length;
 if(g.table){const rows=Math.max(...g.cards.map(c=>c.r))+1,per=Math.max(...g.cards.map(c=>c.cnt));for(const r of [-1,rows])for(let j=0;j<per;j++)cells.push({id:'table.'+r+'.'+j,origin:'native-table',x:plan.W/2+(j-(per-1)/2)*sx,y:plan.H/2+(r-(rows-1)/2)*sy});}
 cells.sort((a,b)=>a.y-b.y||a.x-b.x);const recipes=[],add=(selected,extraCells=[])=>recipes.push({strategy:'stationary-field-opening-cells-v2',fontScale:1,assignments:selected.map(c=>c.id),extraCells});
 // Sliding native row-major windows are finite and retain source reading order.
 for(let i=0;i+n<=cells.length;i++)add(cells.slice(i,i+n));
 if(n<=4){const x0=Math.min(...cells.map(c=>c.x)),x1=Math.max(...cells.map(c=>c.x)),outline=g.lw*Math.SQRT2/2*10+1,span=1.21*g.chh+.175*g.k+2*outline;
  // The accepted proof rectangle is vertically asymmetric (shadow). Centre the
  // added pair in its stage-safe range; the final unchanged proof decides fit.
  const guard=8*g.lw+10,lo=Math.min(-.605*g.chh-guard,-(g.chh/2+2)*1.21-20),hi=Math.max(.605*g.chh+.175*g.k+guard,(g.chh/2+2)*1.21+20),yc=(plan.H-lo-hi)/2;
  for(const pitch of [1,1.2,1.4,1.6])for(const gap of [.5,1,1.5,2]){const sep=span+gap*.16*g.k,points=[{x:x0-pitch*sx,y:yc-sep/2},{x:x1+pitch*sx,y:yc-sep/2},{x:x0-pitch*sx,y:yc+sep/2},{x:x1+pitch*sx,y:yc+sep/2}].slice(0,n).map((c,i)=>({...c,id:'extra.'+i}));if(points.every(c=>c.x>=0&&c.x<=plan.W&&c.y>=0&&c.y<=plan.H))add(points,points);}
 }
 if(recipes.length>64)fail('FLIPCARDS_CANDIDATE_BUDGET','At most64 stationary field assignments required');return recipes;
}
function pairLedger(trial,plan,cut){
 const g=trial.g,cells=g.fieldCells;if(!g.fieldRecipe||!Array.isArray(cells)||cells.length>46)fail('FLIPCARDS_FIELD_LEDGER','Complete bounded source field ledger required');
 const outline=g.lw*Math.SQRT2/2*10+10,body=[-.55*g.k-outline,-.605*g.chh-outline,.675*g.k+outline,.605*g.chh+.175*g.k+outline],env={pass:'main',scale:1},supports=[];
 for(const cell of cells){const ink=[];if(cell.assignedLyricIndex!=null){const unit=trial.units.find(u=>u.source.index===cell.assignedLyricIndex);if(!unit)fail('SOURCE_COVERAGE','Assigned card must retain original lyric owner');ink.push(...unit.source.fontOutlines);}else if(cell.origin==='native-table'&&g.peek){for(const text of ['？','★'])ink.push(...A.itemGeometry({text,font:cut.params.font,size:g.k*.46,x:0,y:0},ID,env).inkPolygons);}
  const points=ink.flat(),glyph=points.length?[Math.min(...points.map(v=>v[0]))*1.1-20,Math.min(...points.map(v=>v[1]))*1.21-20,Math.max(...points.map(v=>v[0]))*1.1+20,Math.max(...points.map(v=>v[1]))*1.21+20]:null;
  // Complete raster supports, scale>=.1: path one-device-pixel guards=>10;
  // glyph two-device-pixel guards=>20. These are NOT the coarse camera proof.
  const b=glyph?[Math.min(body[0],glyph[0]),Math.min(body[1],glyph[1]),Math.max(body[2],glyph[2]),Math.max(body[3],glyph[3])]:body;
  supports.push({cellId:cell.id,origin:cell.origin,assignedLyricIndex:cell.assignedLyricIndex??null,contentKind:cell.contentKind,body:rect(cell.x+body[0],cell.y+body[1],cell.x+body[2],cell.y+body[3]),glyph:glyph?rect(cell.x+glyph[0],cell.y+glyph[1],cell.x+glyph[2],cell.y+glyph[3]):null,bounds:[cell.x+b[0],cell.y+b[1],cell.x+b[2],cell.y+b[3]]});
 }
 const pairs=[];for(let i=0;i<supports.length;i++)for(let j=i+1;j<supports.length;j++){const a=supports[i],b=supports[j];if(a.assignedLyricIndex==null&&b.assignedLyricIndex==null)continue;const gap=Math.max(b.bounds[0]-a.bounds[2],a.bounds[0]-b.bounds[2],b.bounds[1]-a.bounds[3],a.bounds[1]-b.bounds[3]);pairs.push({a:a.cellId,b:b.cellId,gap});if(gap<=1e-7)fail('FLIPCARDS_CELL_OCCLUSION','Distinct card physical/shadow/guarded-glyph supports overlap: '+a.cellId+'/'+b.cellId);}
 return {kind:'source-body-shadow-outline-and-complete-glyph-supports',space:'pre-camera common affine; supports include worst .1-scale device guards; common source camera preserves distinct-ink separation',cells,supports,pairs,replacedNativePeeks:cells.filter(c=>c.origin==='native-table'&&c.assignedLyricIndex!=null).map(c=>c.id),unchangedNativePeeks:cells.filter(c=>c.origin==='native-table'&&c.assignedLyricIndex==null).map(c=>c.id),literalBlankCells:cells.filter(c=>c.contentKind==='literal-blank-back').map(c=>c.id)};
}
function finalize({plan,cut,revision,stepDur,reachTail,explicitSize}){
 if(cut.enter!=='cut'||cut.exit!=='cut'||cut.hold!=='still'||cut.treat!=='none'||!['ltr','random'].includes(cut.params.order)||!['accent','ink'].includes(cut.params.back)||['table','peek','idx'].some(k=>typeof cut.params[k]!=='boolean'))fail('UNSUPPORTED_PARAMETER_RANGE','Native flipCards cut/cut/still, no treatment and original boolean/order/back parameters required');
 const count=[...norm(cut.text)].length;if(count<1||count>14)fail('UNSUPPORTED_PARAMETER_RANGE','Native flipCards1..14 lyric glyphs required');
 const capability=A.layoutsDProjectionCapability?.('flipCards-face');if(capability?.version!==1||capability.kind!=='finite-forward-text')fail('D_FINITE_PROJECTION_PENDING','Unchanged narrow finite-forward projection bridge required');
 const renderer=Object.create(J.Renderer.prototype),native=proof(renderer,plan,cut,true),evaluationRange=[Math.min(cut.start,cut.renderStart??cut.start)-stepDur,Math.max(cut.end,cut.displayEnd??cut.end)+reachTail],regions=plan.lyricAvoidanceIndex.regions.map((r,i)=>({start:r.start,end:Math.min(r.end??plan.lyricAvoidanceIndex.regions[i+1]?.start??plan.duration,plan.duration),region:r.id,circle:{cx:r.center.x*plan.W,cy:r.center.y*plan.H,r:r.radius*Math.min(plan.W,plan.H)}})).filter(r=>r.start<evaluationRange[1]&&r.end>evaluationRange[0]&&r.end>r.start),base=fieldCandidates(native.g,plan,cut),attempts=[];
 if(!regions.length||regions.length>64)fail('UNSUPPORTED_PARAMETER_RANGE','One to64 active avoidance regions required');
 let chosen=null;for(const fontScale of explicitSize?[1]:[1,.95,.9,.85,.8,.75]){for(const candidate of base){const recipe={...candidate,fontScale};try{const trial=proof(renderer,plan,{...cut,layoutDRecipe:recipe});if(trial.quality.minPrimaryPx<Math.min(native.quality.minPrimaryPx,Math.max(18,.035*Math.min(plan.W,plan.H)))-1e-7||native.quality.minRankPx!=null&&trial.quality.minRankPx<Math.min(native.quality.minRankPx,12)-1e-7)fail('READABILITY_FLOOR','Native primary/rank readable floor required');
   const stage=trial.envelopes.every(p=>p.every(v=>v[0]>=0&&v[0]<=plan.W&&v[1]>=0&&v[1]<=plan.H)),clear=stage&&regions.every(r=>A.clear(trial.envelopes,r.circle,Math.max(2,.005*Math.min(plan.W,plan.H))));if(!stage||!clear){attempts.push({recipe,status:'insufficient-space',reason:!stage?'complete-stage-envelope':'active-circle-envelope'});continue;}
   const ledger=pairLedger(trial,plan,cut);chosen={trial,recipe,ledger};attempts.push({recipe,status:'safe',reason:'one fixed field assignment, all regions, complete primary and distinct-cell supports'});break;
  }catch(e){attempts.push({recipe,status:'unsupported',reason:e.code||'DRAW_PROGRAM_ERROR',details:e.message});}}if(chosen)break;}
 const selected=chosen?.trial||native,segments=regions.map(r=>({...r,from:[0,0],to:[0,0],status:chosen?'safe':'insufficient-space',decision:chosen?'certified':'excluded-during-avoidance',composition:chosen?.recipe||null,envelopes:selected.envelopes,unitProofs:selected.units,fieldLedger:chosen?.ledger||null,attempts}));
 return {kind:'layouts-d-source-native',version:1,revision,evaluationRange,measurementSupported:true,units:[{owner:'flipCards.composition',segments}],sourceProof:{kind:'analytic-card-face-and-glyph-projection-intervals',coverage:native.quality,nativeAttachmentStatus:native.error?'unsupported-native-attachment':'complete',selectedAttachment:'Unchanged complete font/stroke/font-space attachment required; native failure retained and never selected safe',projection:capability,interval:'Unchanged accepted full-phase primary card/glyph/rank/shadow rectangles and cameraEnvelope(...,20), scale.1..4',chronology:'Original source count/order/seed/ord/ti/fd/gapT/appear/po/mi retained; fixed native field cells, one assigned surface per cell; unselected literal peeks exact; selected peeks explicitly replaced',field:'Native middle cells not selected become explicit literal blank backs with original native appearance ordinal and no latent lyric',explicitSizePreserved:explicitSize,candidateBudget:{assignments:base.length,fontLevels:explicitSize?1:6,maxAssignments:64,maxAttempts:384,maxFieldCells:46,maxExtraCells:4},attemptCount:attempts.length},safety:chosen?'certified-bounded-adapter':'insufficient-space'};
}
''' +s[end:]
s=s.replace("offset=A.offsetAt(unit,env.realTime);if(active?.composition)","offset=A.offsetAt(unit,env.realTime);if(active?.status==='insufficient-space')fail('FLIPCARDS_COMPOSITION_EXCLUDED','No common stationary field assignment satisfies complete primary and distinct-cell proofs');if(offset.some(v=>v!==0))fail('FLIPCARDS_FIELD_MOVED','Stationary field requires fixed zero offset');if(active?.composition)")
s=s.replace("id:'flipCards-native-face-v1'","id:'flipCards-stationary-field-v2'")
p.write_text(s)
