# Pendulum selected native60fps raw evidence — split durability

Three exact accepted examples: cradle-four-normal, fan-four-high-motion, chunks-one-original-run. Original whole beforecaddb6a; afterbc39ce2b7893a514e6ddd7e053312dde469f8640. All are1920×1080,4seconds,240 native60fps encoder inputs per side; six MP4s have240distinct image hashes each. The accepted matrix used planFPS24. Both capture source plans deliberately use planFPS60 for output sampling; motion laws, phase, durations, parameters,8-face fonts, ghosts and source cuts remain unchanged. Full sourcePlan JSON is equal between before/after. Preflight additionally checks exact accepted source cut/style/fx and same chosen geometry/offset before encoding.

Before uses the unchanged original full-stage renderer without D flags. Its240 main-clock positions are DERIVED from exact source quantizer, not observed. After uses the existing placementObservation actualmotionTime,240distinct positions per case, with no source/renderer/core hooks. All720afterframes/2160observations/15499polygons were independently checked against circle/stage+margin and continuous owner envelopes by parent. Fresh-context sol sampled30original images/extracted frames and6ffprobe streams. These are bounded numerical and limited visual reviews, not human adoption or full temporal aesthetic approval. Cradle tinytype/shortsuspension/prominence and trail/support overlap, fan legibility/swing, paper squarer shape/shortsuspension remain human questions.

## What is embedded, and what is external

capture-output/ contains ALL six full frame-gzip records, six actual source/final-plan input-gzip records, actual executed runner02, capture manifest, native-image hashes, cases/reference/freeze and original JA/ENcomparison HTML. invocation02/ keeps the exact local prepins/command log and postrun validation. Parent math/source restoration verification and freshsol report/pins are included. visual-extracts/ embeds all12 exact extracted PNGs actually inspected by sol, with hashes; the other18 inspected native PNGs are the external original media listed below. All30 inspected image bytes thus have explicit durability across main+companion source Git, without assuming a later decoder can recreate the same extracted PNG bytes. No old failure is rewritten as success.

The24binary assets (6MP4+18PNG,27.52MB) are deliberately NOT embedded in this main raw capsule. external-media-restore-map.json gives every exact path/byte/SHA and companion Sites SOURCE Git project/path. The source commit must be obtained from the later main record `tasks/evidence/AVOID-009/pendulum-media02/sites-publication02.json`. That future source commit is not guessed or claimed here. Do not fetch public URLs to restore or verify media. Durability is split across the main raw Git object and the companion source Git repository; this is not a claim that one archive or one repository embeds every media byte.

Original failed invocation01 is separately preserved in history01: runner567..., prepins, command stderr, failure, unique raw/actual inputs. It failed because its clock probe changed sealed drawCut; the product guard correctly rejected afterframe0. Original before video840746B SHA1fd104... and corresponding stills are byte-identical to current02 assets and restore through the same exact source-Git paths. history01/restore-map.json maps aliases and the original whole baseline Git blob truthfully. It does not imply the failed run passed.

## Source dependency reconstruction

All109 actual capture snapshot pins were independently checked by parent.108 are exact Git bytes, with per-file commits/paths in parent-pendulum-media-source-refs02.json (including actual Bfixture and8 real face files; NOT the earlier ribbon Noto alias). The isolated consumed limited-test runner is not falsely labeled canonical: it restores from the accepted pendulum thin packet02 member recorded in that receipt. The packetSHA is d32f78a378299a6fcdff84dab00c8dca45cb000a0ee96c53cb51d8a82cc36e46,2,635,586B; main path `tasks/evidence/AVOID-009/pendulum-final01/avoid009-pendulum-final-packet02.tar.gz`.

After restoring that packet into/tmp and retaining a repository with the recorded Git objects, prepare a NEW directory:

```bash
python3 restore-capture-inputs.py --repo /workspace/lyricfx.JIZURA --pendulum-packet /tmp/avoid009-pendulum-final-packet02.tar.gz --destination /tmp/pendulum-capture-replay-new
```

This verifies and restores all109 exact source bytes and the original whole before HTML, copies runner02/cases/freezemanifest/reference, and prints an optional new capture command. It does not execute a browser/encoder or overwrite old reports. Node/Playwright/Chromium/ffmpeg runtime dependencies are external and their actual versions are in the captured manifest. A future different runtime is not represented as the original invocation.

The original parent checker is preserved unchanged with its original/tmp input paths; adapt only input/output paths in a clearly named new replay if needed. Original captured HTML is immutable; the projection’s human questions are a deliberate later text derivation in human-questions02.json, with unchanged media bytes. Parent owns main/source Git, Site projection merge, private audience, publication and unanswered human queue. Public result checks remain prohibited; none were performed.
