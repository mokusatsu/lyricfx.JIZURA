"""Restore exact109 pendulum capture inputs; does not run a browser or encoder."""
import argparse,pathlib,json,hashlib,gzip,tarfile,subprocess,shutil
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--pendulum-packet',type=pathlib.Path,required=True);p.add_argument('--destination',type=pathlib.Path,required=True);a=p.parse_args();here=pathlib.Path(__file__).parent;refs=json.loads((here/'parent-pendulum-media-source-refs02.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();assert not a.destination.exists();a.destination.mkdir(parents=True);snapshot=a.destination/'source-snapshot';snapshot.mkdir();assert sha(a.pendulum_packet.read_bytes())=='d32f78a378299a6fcdff84dab00c8dca45cb000a0ee96c53cb51d8a82cc36e46'
with tarfile.open(a.pendulum_packet,'r:gz') as packet:
 for pin in refs['files']:
  rel=pathlib.PurePosixPath(pin['file']);assert not rel.is_absolute() and '..' not in rel.parts
  if pin['origin']=='Git':b=subprocess.check_output(['git','-C',str(a.repo),'cat-file','blob',pin['commit']+':'+pin['gitPath']])
  else:b=gzip.decompress(packet.extractfile(pin['member']).read())
  assert sha(b)==pin['sha256'],pin['file'];dest=snapshot/pin['file'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
before=subprocess.check_output(['git','-C',str(a.repo),'cat-file','blob','caddb6a:index.html']);assert sha(before)=='f84bec328c26bacbda52af4b7d75304417297c2ae8a9242536a4538e097a16ca';(a.destination/'before-caddb6a.html').write_bytes(before)
for n in ['capture02.cjs','cases.json','accepted-case-reference.json','accepted-source-freeze.json']:shutil.copyfile(here/'invocation02'/n,a.destination/n)
freeze=(a.destination/'accepted-source-freeze.json').read_bytes()
for pin in json.loads(freeze)['sourcePins']:assert sha((snapshot/pin['file']).read_bytes())==pin['sha256']
print('Exact109 source input pins restored. Before source quantizer clocks are derived, after clocks use existing observations. No capture executed.')
print('Optional newly authorized capture needs Playwright, Chromium, ffmpeg/ffprobe. Use a fresh output path:')
print('JIZURA_BROWSER=/usr/bin/chromium node',a.destination/'capture02.cjs',snapshot,sha(freeze),a.destination/'NEW-output')
