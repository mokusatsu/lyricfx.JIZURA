from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
review=json.loads((root/'review01.json').read_text());rows=[]
for case in review['comparisons']:
 stem=Path(case['suite']).stem
 a=(root/'runs01'/('baseline-'+stem)/'stdout-stderr.log').read_bytes()
 b=(root/'runs01'/('candidate-'+stem)/'stdout-stderr.log').read_bytes()
 # The ONLY normalization is these exact variant path segments.
 na=a.replace(b'/snapshots/baseline/',b'/snapshots/VARIANT/')
 nb=b.replace(b'/snapshots/candidate/',b'/snapshots/VARIANT/')
 rows.append({'suite':case['suite'],'rawEqual':a==b,'normalizedEqual':na==nb,'baselineSHA256':hashlib.sha256(a).hexdigest(),'candidateSHA256':hashlib.sha256(b).hexdigest()})
print(json.dumps(rows,indent=2));assert len(rows)==11 and all(r['normalizedEqual']for r in rows)
