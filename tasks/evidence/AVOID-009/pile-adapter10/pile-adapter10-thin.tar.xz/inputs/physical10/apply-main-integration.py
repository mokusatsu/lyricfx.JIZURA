from pathlib import Path
import json,hashlib,subprocess,os,datetime
repo=Path('/workspace/lyricfx.JIZURA');out=Path('/tmp/avoid009-pile01/main-integration10');before=json.loads((out/'before-receipt.json').read_text());build=out/'build';qualified=Path('/tmp/avoid009-pile01/physical10/version');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==before['beforeHEAD'];pycache=Path(before['pycache']['path']);assert sha(pycache.read_bytes())==before['pycache']['beforeSHA256']
for row in before['sourceChanges']:
 p=repo/row['path'];assert (not p.exists()) if row['newFile'] else sha(p.read_bytes())==row['beforeSHA256'];assert sha((build/row['path']).read_bytes())==row['qualifiedSHA256']
for row in before['HTML']:assert sha((build/row['path']).read_bytes())==row['qualifiedSHA256']==sha((qualified/row['path']).read_bytes())
written=[]
for row in before['sourceChanges']+before['HTML']:
 p=repo/row['path'];data=(build/row['path']).read_bytes();assert sha(data)==row['qualifiedSHA256'];p.parent.mkdir(parents=True,exist_ok=True)
 # In-place truncate/write intentionally avoids a second root-sized HTML copy.
 with p.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 actual=sha(p.read_bytes());assert actual==row['qualifiedSHA256'];written.append({**row,'actualSHA256':actual,'exactQualifiedSourceOrHTML':True})
for row in before['unaffectedJSAndBuild']:assert sha((repo/row['path']).read_bytes())==row['sha256'],row['path']
assert sha(pycache.read_bytes())==before['pycache']['beforeSHA256'];skip=[line[2:]for line in git('ls-files','-v').decode().splitlines()if line.startswith('S ')];assert skip==before['skipWorktreeAbsent']and all(not(repo/p).exists()for p in skip);head=git('rev-parse','HEAD').decode().strip();assert head==before['beforeHEAD']
for q in json.loads(Path('/tmp/avoid009-pile01/physical10/pre-run02.json').read_text())['files']:assert sha(Path(q['path']).read_bytes())==q['sha256'],q['path']
receipt={**before,'phase':'AUTHORIZED_MAIN_INTEGRATION_WRITTEN_OFFLINE_BYTE_QUALIFIED','atAfter':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mainWritesYet':True,'afterHEAD':head,'afterWorktreePorcelain':git('status','--porcelain=v1').decode(),'written':written,'unaffectedJSAndBuildExact':True,'qualified1499InputBytesUnchanged':True,'pycacheAfterSHA256':sha(pycache.read_bytes()),'all14SkipArchivesAbsentAndFlagsPreserved':True,'buildCommand':'PYTHONDONTWRITEBYTECODE=1 python build.py in /tmp/avoid009-pile01/main-integration10/build','mainBuildExecuted':False,'browserExecutedForIntegration':False,'integrationValidation':'Exactqualifiedsource/HTML hashes plus91unaffectedJS+build/pycache/1499input/skipflags; no duplicated main tests'};(out/'integration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'writtenPaths':[q['path']for q in written],'afterHEAD':head,'pycacheUnchanged':True,'unaffectedJSAndBuild':len(before['unaffectedJSAndBuild']),'qualified1499InputsUnchanged':True,'receipt':str(out/'integration-receipt.json'),'receiptSHA256':sha((out/'integration-receipt.json').read_bytes())}))
