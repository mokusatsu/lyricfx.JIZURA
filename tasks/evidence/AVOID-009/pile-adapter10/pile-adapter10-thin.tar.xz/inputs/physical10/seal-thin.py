from pathlib import Path
import json,hashlib,shutil,re,subprocess
b=Path('/tmp/avoid009-pile01');r=b/'physical10';d=b/'thin-physical10';d.mkdir(exist_ok=False);old=b/'thin-physical09'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json']:put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical10.patch')
for run in ['run01','run02']:
 for p in (r/run).glob('*'):put(p,'evidence/'+run+'/'+p.name)
parent=Path('/workspace/lyricfx.JIZURA/tasks/evidence/AVOID-009/pile-adapter10')
for p in parent.iterdir():
 if p.is_file()and p.suffix!='.xz':put(p,'parent/'+p.name)
for p in (b/'main-integration10').glob('*'):
 if p.is_file():put(p,'integration/'+p.name)
for p in r.iterdir():
 if p.is_file():put(p,'inputs/physical10/'+p.name)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical10:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text().replace("'physical08', 'physical09']","'physical08', 'physical09', 'physical10']").replace("+(['physical09.patch'] if variant in variants[6:] else []):","+(['physical09.patch'] if variant in variants[6:] else [])+(['physical10.patch'] if variant in variants[7:] else []):");(d/'reconstruct-html.py').write_text(s)
oldrows=json.loads((old/'portable-reference-map.json').read_text())['files'];oldmap={x['path']:x['portableReference']for x in oldrows};gitbysha={x['sha256']:x['portableReference']for x in oldrows if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run02.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p))
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction'if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical10','path':rel}
 elif p.is_relative_to(r/'run01'):
  ref={'kind':'embedded','path':'evidence/run01/'+p.name}
 elif p.is_relative_to(r):
  rel='inputs/physical10/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 elif p==b/'physical09/pre-run.json':
  rel='inputs/physical09/pre-run.json';ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'1499actualrun02inputs; all1486run01inputs unchanged; stockfonts/Git/source/16HTML exact; runtime567CAS EXTERNAL/notstandalone','files':files})
put(old/'verify-artifacts.py','verify-artifacts.py')
ref={'blob':'a38d4b77ebb61cf818059d7882483cc17753822d','gitPath':'tasks/evidence/AVOID-009/pile-groupY09/pile-groupY09-thin.tar.xz','archiveSHA256':'8cba752867a6b230f8e4d40551087424666c0c2256bb1d75c40a24a9a99e1e11','archiveBytes':2434420,'member':'evidence/run01/raw.json','rawSHA256':'211302dec292e584202946c73529b9074d5766530de051fdc92b0199b37d8959','purpose':'Exactaccepted09capturedraw required by parent10comparison; storedGitcapsule, notduplicated or fetchednetwork'};blob=subprocess.check_output(['git','show',ref['blob']],cwd='/workspace/lyricfx.JIZURA');assert hashlib.sha256(blob).hexdigest()==ref['archiveSHA256'];write('prior09-evidence-Git-reference.json',ref)
s=(old/'restore-inputs.py').read_text().replace("for run in ['run01']:","for run in ['run01','run02']:").replace("out/'consumed/physical09'","out/'consumed/physical10'")
s+='''\n# Restore exact prior accepted09 raw from its verified immutable Git capsule.
import io,tarfile
ref=json.loads((base/'prior09-evidence-Git-reference.json').read_text());blob=subprocess.check_output(['git','show',ref['blob']],cwd=a.repo);assert len(blob)==ref['archiveBytes']and hashlib.sha256(blob).hexdigest()==ref['archiveSHA256']
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as archive:
 matches=[m for m in archive.getmembers()if m.name.removeprefix('./')==ref['member']];assert len(matches)==1 and matches[0].isfile();data=archive.extractfile(matches[0]).read()
assert hashlib.sha256(data).hexdigest()==ref['rawSHA256'];target=out/'consumed/physical09/run01/raw.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(out/'prior09-restore-result.json').write_text(json.dumps({**ref,'restoredPath':str(target),'exact':True},indent=2)+'\\n');print(json.dumps({'prior09RawFromVerifiedGitCapsule':True,'rawSHA256':ref['rawSHA256']}))
''';(d/'restore-inputs.py').write_text(s)
(d/'recompute-parent-checks.py').write_text('''"""Archive-only parent10geometry against exact09Git evidence, no browser/network.
Original scripts/failures retained; derivedcopies redirect root/output paths only.
"""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--restored-root',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);results=[]
for run in ['run01','run02']:
 text=(b/'parent/parent-independent10.py').read_text();old="root=pathlib.Path('/tmp/avoid009-pile01')";assert text.count(old)==1;text=text.replace(old,'root=pathlib.Path('+repr(str(Path(a.restored_root).resolve()))+')',1);target='/tmp/parent-pile-adapter10-raw.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(run+'.json'))),1);script=out/(run+'.py');script.write_text(text);r=subprocess.run(['python',str(script),str(Path(a.restored_root)/'physical10'/run/'raw.json')],check=True,capture_output=True,text=True);(out/(run+'.stdout')).write_text(r.stdout);q=json.loads((out/(run+'.json')).read_text());expected=json.loads((b/'parent'/('parent-independent-'+run+'.json')).read_text());assert q==expected;results.append({'run':run,'independentGeometryExactlyMatchesActualParent':True,'runnerOverallPassed':run=='run02','originalRunnerFailureCount':sum(len(v['failures'])for v in q['originalRunnerFailures'])})
(out/'recompute-result.json').write_text(json.dumps({'allMathMatched':True,'runtimeRehashed':False,'results':results},indent=2)+'\\n');print(json.dumps({'allMathMatched':True,'runtimeRehashed':False,'results':results}))
''')
(d/'README.md').write_text('''PILEphysical10 within AVOID-009: bounded FULLYSTRICTsource adapter accepted/source-integrated; no humanvisual/contact/readability/formalperformance/global009/010/017 acceptance. No font reduction or entry/exit waiver; no UI017 activation.

Actualrun01 parent26293exit1:2cases22wholeframes2FAIL ONLY erroneous runner184totalregistry expectation (actual194),errors0. ALL1486inputs unchanged. FreshRUNNERONLYrun02 parent43087exit0:2cases22wholeframes0FAIL/errors,1499actualpostpins unchanged+independentlyrehashed; rawSHA63eb968d7e2195d7f398caf842bd9204ba5994fcc6004ff72e55a0658d5be5f5. Runtime194=184ordinary stock+10stock specialcards, NOTcustom. Exacttrackedbc39literalregistration/sourceflags provenance embedded; sourcepaint/math/HTML unchangedrun01→02. Originalfailure/runner/prepins/summary/raw retained, not rewritten successful.

Finalparent independent10 source/results for BOTHactualruns embedded, plus TWOactualfailedparentanalyzer snapshots: one corrected snapshot-vs-time-dependent f assumption to original(lt-when)/fd; second retained JS floor*step operation vs algebraicallyequivalent Pythondivision withdifferent binary64 rounding. These were parentverificationassumptions, NOT product/Chromiumfailures. Temporaryexecutionenvunavailable thenrestored recorded inparentrun01receipt; no duplicatebrowser. Parentboundedraw02:610fullphaseownerhulls EXACTaccepted09,4first9witnesses,74observations54active/3192actualpolys2613active/2845heapindex mappings333slots74clocks. Cold806/876ms warm9.2/9.7ms and94.7/107.8KBcertificate observedonly, NOTformalperformance acceptance.

Nativefont fourcandidate lazyfamily, ALLcorrelatedownerbudgets mandatory includingfreshsharedYrecheck; allphase fullstageownerhulls ALSOstrictcircle, noentrygate. SharedY twoownedruns, sameconnectedmound/lattice/sourceIDs/counts/gaps/when/seed/order. Compact runtimecertificate/sourcehelperdeps numericidentitytokens surviveactualcompletedcachedecode/newsegment/firstframeparity; firstfont/camerastale/revisionrefinalize qualified. ActualwholeRenderer.frame mainAB/realTime region/nativeclock/OFF/outsidezerooffset andoldaccordionoffsetscales. Activeinsufficient throws BEFOREnativefallback. Genericunsupported09krestore NOTSafe; future017preflight MUSTreject. Narrowone-row2..8nongap/sourcestockcamera/numericdomain only. Guardprojection budget not solidinkcontact/readability.

Integrationreceipt/full8sourcepatch vsPRODUCTbc39 embedded: exactqualified09a/09k/11p_layoutsD/11za +new09u/v/w/x,offlineJAENbuildin/tmp theninplace truncatecopyto MAIN. NochildGit/browser/mainbuild. Receiptbefore/afterHEADbc331f4,pycache739041.../14skiparchives preserved,91otherJS+build unchanged,1499qualifiedinputs unchanged. Parent latercommit064cd99 separatelyreviewed; originalintegrationreceipt is precommittruth. Parentpush status onlyas suppliedreceipt, no publicresultcheck. Rawtestsource is exactmainintegratedbytes; no duplicate mainbrowser claimed.

Every1499consumedinput mapped:102verifiedGitbasebuildrefs+sourcepatchchain rebuildall16historicJAENHTML; nativeOTF/TTF/manifests restored via individuallyverifiedbc39Gitrefs. Runtime567CAS explicitlyEXTERNAL, NOTstandaloneChromium. Earlieraccepted09capturedraw requiredbyparentcomparison restored EXACT fromGitblob a38d4b77.../capsule8cba7528... (prior09-evidence-Git-reference.json), no network and no duplicatedfull09raw inthisarchive. Priorcapsule also preservespriorparent09scripts/fullproof history. Mainrepository withthatGitobject is necessary; no fake standalone runtime/history claim.

Extract into freshdirectory; python verify-artifacts.py FIRST. Offline/read-onlyGit/no browser/network:
python restore-inputs.py --repo /path/to/repo --out /tmp/pile-adapter10-restored-fresh
python recompute-parent-checks.py --restored-root /tmp/pile-adapter10-restored-fresh/consumed --out /tmp/pile-adapter10-parent-math-fresh

RestorechecksALLnonruntimeconsumedbytes includingnativefonts; capturedrun01/02outputscopiedseparately asEVIDENCE (run01isalsoactualhistoricalinputofrun02 andhashpinned). ParentderivedcopiesredirectONLYroot/outputpaths, originalscripts/results unchanged. RecomputecomparesresultJSONexacttoactualparentBOTHruns, preservesoriginal2runnerFAIL inrun01; runtimeexternalnotrehashed, no JS/browser implied. No images/MP4/publicresultchecks. Sourcephysical10actualinputs/CASnotdeleted.
''')
print(json.dumps({'prepared':str(d),'inputTargets':len(files)}))
