from pathlib import Path
import hashlib,json,gzip,datetime,difflib,subprocess
root=Path('/tmp/avoid009-pile01');out=root/'physical10';old=root/'physical09/pre-run.json';cas=root/'frozen-inputs'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();h=sha(b);q=cas/(h+'.gz')
 if not q.exists():
  with q.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(b)
 return {'path':str(p),'bytes':len(b),'sha256':h,'snapshot':str(q)}
previous=json.loads(old.read_text())['files'];changedOld=[]
for q in previous:
 if sha(Path(q['path']).read_bytes())!=q['sha256']:changedOld.append(q['path'])
assert not changedOld,changedOld
base=root/'physical09/version';new=out/'version';diff=[];identity=[]
for p in sorted(new.glob('src/*.js')):
 q=base/p.relative_to(new);same=q.exists() and p.read_bytes()==q.read_bytes();identity.append({'path':str(p.relative_to(new)),'same09':same,'newFile':not q.exists(),'beforeSHA256':sha(q.read_bytes()) if q.exists() else None,'sha256':sha(p.read_bytes())})
 if not same:diff.extend(difflib.unified_diff(q.read_text().splitlines(True) if q.exists() else [],p.read_text().splitlines(True),fromfile='physical09/'+str(q.relative_to(base)) if q.exists() else '/dev/null',tofile='physical10/'+str(p.relative_to(new))))
assert new.joinpath('build.py').read_bytes()==base.joinpath('build.py').read_bytes()
(out/'source.patch').write_text(''.join(diff));(out/'render-source-identity.json').write_text(json.dumps({'moduleExecuted':False,'buildPyExact09':True,'files':identity},indent=2)+'\n')
checks=[]
for p in [new/'src/09x_layoutsD_pile_adapter.js',new/'src/09k_layoutsD_placement.js',new/'src/11za_layoutsD_transport.js',out/'adapter-test.cjs']:
 c=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);assert c.returncode==0,c.stderr;checks.append({'file':str(p),'sha256':sha(p.read_bytes()),'command':['node','--check',str(p)],'exitCode':c.returncode,'stdout':c.stdout,'stderr':c.stderr})
(out/'syntax-checks.json').write_text(json.dumps({'moduleExecuted':False,'checks':checks},indent=2)+'\n')
review=[new/'src/09x_layoutsD_pile_adapter.js',new/'src/09k_layoutsD_placement.js',new/'src/11za_layoutsD_transport.js',out/'source.patch',out/'MATH-SOURCE-REVIEW.md',out/'RUNNER-REVIEW.md',out/'adapter-test.cjs',out/'cases.json',out/'render-source-identity.json',out/'syntax-checks.json']
(out/'source-review-pins.json').write_text(json.dumps({'phase':'PHYSICAL10_UNEXECUTED_FULLY_STRICT_ADAPTER','moduleExecuted':False,'files':[pin(p) for p in review]},indent=2)+'\n')
rows={q['path']:q for q in previous};rows[str(old)]=pin(old)
for p in sorted(out.rglob('*')):
 if p.is_file() and p!=out/'pre-run.json':rows[str(p)]=pin(p)
receipt={'beforeBrowserExecution':True,'moduleExecuted':False,'phase':'PHYSICAL10_BOUNDED_FULLY_STRICT_ADAPTER_QUALIFICATION_PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'cd /tmp/avoid009-pile01 && node physical10/adapter-test.cjs','physical09All1347InputsUnchanged':True,'files':sorted(rows.values(),key=lambda q:q['path'])}
(out/'pre-run.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'files':len(rows),'preRunSHA256':sha((out/'pre-run.json').read_bytes()),'sourceReviewSHA256':sha((out/'source-review-pins.json').read_bytes()),'sourcePatchSHA256':sha((out/'source.patch').read_bytes()),'runnerSHA256':sha((out/'adapter-test.cjs').read_bytes()),'moduleExecuted':False}))
