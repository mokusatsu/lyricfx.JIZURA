from pathlib import Path
import json
b=Path('/tmp/avoid009-pile01');r=b/'physical10'
setup='\n'.join((b/'physical09/group-y-test.cjs').read_text().splitlines()[6:8])
# setup spans lines7/8 in the sealed09 runner, source clocks and live-root arithmetic unchanged.
(r/'oldD-setup-fragment.txt').write_text(setup+'\n')
