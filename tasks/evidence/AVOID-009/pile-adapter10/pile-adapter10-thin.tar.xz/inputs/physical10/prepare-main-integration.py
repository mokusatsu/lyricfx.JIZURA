from pathlib import Path
import subprocess,json,hashlib,difflib,datetime,shutil
repo=Path('/workspace/lyricfx.JIZURA');b=Path('/tmp/avoid009-pile01');out=b/'main-integration10';out.mkdir(exist_ok=False);qualified=b/'physical10/version';commit='bc39ce2b7893a514e6ddd7e053312dde469f8640';sha=lambda x:hashlib.sha256(x).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
head=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain=v1').decode();skip=[line[2:]for line in git('ls-files','-v').decode().splitlines()if line.startswith('S ')];assert len(skip)==14,len(skip);assert all(not(repo/p).exists() for p in skip)
pycache=repo/'app/__pycache__/english.cpython-312.pyc';pyhash=sha(pycache.read_bytes());refs=git('ls-tree','-r','--name-only',commit,'src').decode().splitlines();refs=[p for p in refs if p.endswith('.js')];diff=[];changed=[];unaffected=[]
for rel in refs+['build.py']:
 baseline=git('show',commit+':'+rel);current=(repo/rel).read_bytes();assert current==baseline,rel+' current main differs fromproduct baseline';q=(qualified/rel).read_bytes()
 if q!=baseline:
  changed.append({'path':rel,'newFile':False,'beforeSHA256':sha(current),'qualifiedSHA256':sha(q),'beforeBytes':len(current),'qualifiedBytes':len(q)});diff.extend(difflib.unified_diff(baseline.decode().splitlines(True),q.decode().splitlines(True),fromfile='bc39/'+rel,tofile='qualified10/'+rel))
 else:unaffected.append({'path':rel,'sha256':sha(current),'exactBaselineAndQualified':True})
for p in sorted((qualified/'src').glob('*.js')):
 rel=str(p.relative_to(qualified))
 if rel in refs:continue
 assert not(repo/rel).exists(),rel
 q=p.read_bytes();changed.append({'path':rel,'newFile':True,'beforeSHA256':None,'qualifiedSHA256':sha(q),'beforeBytes':0,'qualifiedBytes':len(q)});diff.extend(difflib.unified_diff([],q.decode().splitlines(True),fromfile='/dev/null',tofile='qualified10/'+rel))
expected={'src/09a_placement.js','src/09k_layoutsD_placement.js','src/11p_layoutsD.js','src/11za_layoutsD_transport.js','src/09u_layoutsD_pile.js','src/09v_layoutsD_pile_trial.js','src/09w_layoutsD_pile_contact.js','src/09x_layoutsD_pile_adapter.js'};assert {q['path']for q in changed}==expected
html=[]
for rel in ['index.html','en/index.html']:
 current=(repo/rel).read_bytes();assert current==git('show',commit+':'+rel),rel
 q=(qualified/rel).read_bytes();html.append({'path':rel,'beforeSHA256':sha(current),'qualifiedSHA256':sha(q),'beforeBytes':len(current),'qualifiedBytes':len(q)})
(out/'full-source-vs-bc39.patch').write_text(''.join(diff));receipt={'phase':'AUTHORIZED_MAIN_INTEGRATION_PREPARED_NOT_WRITTEN_YET','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baselineProductCommit':commit,'beforeHEAD':head,'beforeWorktreePorcelain':status,'skipWorktreeAbsent':skip,'pycache':{'path':str(pycache),'beforeSHA256':pyhash,'beforeBytes':pycache.stat().st_size},'sourceChanges':changed,'unaffectedJSAndBuild':unaffected,'HTML':html,'patchSHA256':sha((out/'full-source-vs-bc39.patch').read_bytes()),'mainWritesYet':False,'gitMutations':False,'browserExecuted':False};(out/'before-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copytree(qualified,out/'build');print(json.dumps({'sourcePaths':[q['path']for q in changed],'unaffectedJSAndBuild':len(unaffected),'beforeHEAD':head,'pycacheSHA256':pyhash,'absentSkipArchives':len(skip),'patchSHA256':receipt['patchSHA256'],'receipt':str(out/'before-receipt.json')}))
