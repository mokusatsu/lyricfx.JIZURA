from pathlib import Path
import hashlib,json,gzip,datetime,subprocess
r=Path('/tmp/avoid009-pile01/physical10');cas=r.parent/'frozen-inputs';sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();h=sha(b);q=cas/(h+'.gz')
 if not q.exists():
  with q.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(b)
 return {'path':str(p),'bytes':len(b),'sha256':h,'snapshot':str(q)}
original=json.loads((r/'pre-run.json').read_text())['files'];end=json.loads((r/'run01/end-pins.json').read_text());assert len(original)==1486 and len(end['files'])==1486 and end['allInputsUnchanged'];rows={p['path']:p for p in original}
for p in original:assert sha(Path(p['path']).read_bytes())==p['sha256'],p['path']
check=subprocess.run(['node','--check',str(r/'adapter-test-run02.cjs')],capture_output=True,text=True);assert check.returncode==0,check.stderr
(r/'syntax-run02.json').write_text(json.dumps({'runnerExecuted':False,'syntaxOnly':True,'command':['node','--check',str(r/'adapter-test-run02.cjs')],'exitCode':check.returncode,'stdout':check.stdout,'stderr':check.stderr},indent=2)+'\n')
paths=[r/n for n in ['adapter-test-run02.cjs','registry-provenance.py','registry-provenance.json','runner-run02.patch','RUN02-REGISTRY-REVIEW.md','freeze-run02.py','syntax-run02.json','pre-run.json']]+list((r/'run01').glob('*'))
for p in paths:rows[str(p)]=pin(p)
review=[r/'version/src/09x_layoutsD_pile_adapter.js',r/'version/src/09k_layoutsD_placement.js',r/'version/src/11za_layoutsD_transport.js',*paths[:7]]
(r/'review-run02-pins.json').write_text(json.dumps({'sourcePaintMathUnchangedFromActualRun01':True,'runnerExecuted':False,'files':[pin(p) for p in review]},indent=2)+'\n');rows[str(r/'review-run02-pins.json')]=pin(r/'review-run02-pins.json')
receipt={'beforeBrowserExecution':True,'runnerExecuted':False,'sourceModulePreviouslyExecutedInRun01':True,'run01ActualExit':1,'run01FailureScope':'Only badtotalregistry184expectation;2FAIL retained; runtime194=184ordinary+10stockspecial','phase':'PHYSICAL10_RUNNER_ONLY02_REGISTRY_PROVENANCE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'cd /tmp/avoid009-pile01 && node physical10/adapter-test-run02.cjs','run01All1486InputsUnchanged':True,'files':sorted(rows.values(),key=lambda q:q['path'])};(r/'pre-run02.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'files':len(rows),'preRun02SHA256':sha((r/'pre-run02.json').read_bytes()),'reviewPinsSHA256':sha((r/'review-run02-pins.json').read_bytes()),'runnerSHA256':sha((r/'adapter-test-run02.cjs').read_bytes()),'diffSHA256':sha((r/'runner-run02.patch').read_bytes()),'registryProvenanceSHA256':sha((r/'registry-provenance.json').read_bytes())}))
