UNEXECUTED proof-only08. Proposed parent-only ordinary command:
cd /tmp/avoid009-pile01 && node physical08/contact-proof-test.cjs

Two existing07 landscape1280x720/nativefont/scale1 fixtures: Japanese4nongaps and A B C with2sourcegaps/Unicodeheappool. Same push/mainAB, FOURunchanged recipes nativeEquivalent/a84NoSplit/rho.9/rho1.1. Only realtimes .60/.90:48newactual08 observations +48reference07, not120new frames. Newdiagnostic runs once pertrial (8calls). Baseline07page prepares same07trial, source98thmodule onlyafterpage; no renderhook/camera/replay changes.

Checks: fullpaint direct/replay RGBA SHA allfourrecipes equal07; OFFdirectdrawCut2times/case counts+pixels equal07, instrumentation restored (no renderer/mainDraw wrappers). Sourcecatalogoriginalfields/eventorder/heapindex→gxgy mapping unchanged. NewhelperinputJSON and recursivelyfrozenstate unchanged; planJSON/nestedfreeze unchanged; all oldledgers/comparisons exact07 and retained in clonednewoutput. Scope flags no geometry/recipe/groupY/adapter/SAFE. SourceJS/build hashes independently unchanged.

Newcorrelatednative/candidate: independent ordinary4cornerhull clipping by actualbodyline slabs checks allnominalcell extrema inside outwardallpairs interval. Actualsource settledguard loweredge probes use actualitemx/y/rot/sy and actualsourcebody nodes/rise, allclipped extrema insidecontinuouscandidate bounds. Everyoriginalnongap owner must be probed. Exactnominalprobes supplementaryfalsification, notproof admissions/tightening. Native/candidate compare unchangedallowances and preserve oldfailed budgetreports; no budgetsuccess/quality assertion required.

Existing07translatedvisibletransport/offsetwitness results remain separatehistorical evidence; no broad stage/circle replay of unchangedpaintsource. ThisrunnerB0pixels can be clipped as before; proof-only parity is meaningful for identical paint paths but not newvisibility acceptance. No images/MP4/publicchecks/fonts/groupY/adapter.

HTTP ephemeral127.0.0.1 only, exactlocalorigin allow, every externalroute abortedbefore request/sanitizedhostlog. Fullsource/build/consumedHTML/fixtures/fonts/runner/cases/math/current sourcepins +existingruntimeCAS pinned before parentexecution; actualsealed07referenceHTML/07FAIL+PASS inputs unchanged. Freshoutputphysical08/run01. Syntaxcheck/offlinebuild only, no08module/browser execution.
