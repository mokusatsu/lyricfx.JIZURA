"""Archive-only parent10geometry against exact09Git evidence, no browser/network.
Original scripts/failures retained; derivedcopies redirect root/output paths only.
"""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--restored-root',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);results=[]
for run in ['run01','run02']:
 text=(b/'parent/parent-independent10.py').read_text();old="root=pathlib.Path('/tmp/avoid009-pile01')";assert text.count(old)==1;text=text.replace(old,'root=pathlib.Path('+repr(str(Path(a.restored_root).resolve()))+')',1);target='/tmp/parent-pile-adapter10-raw.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(run+'.json'))),1);script=out/(run+'.py');script.write_text(text);r=subprocess.run(['python',str(script),str(Path(a.restored_root)/'physical10'/run/'raw.json')],check=True,capture_output=True,text=True);(out/(run+'.stdout')).write_text(r.stdout);q=json.loads((out/(run+'.json')).read_text());expected=json.loads((b/'parent'/('parent-independent-'+run+'.json')).read_text());assert q==expected;results.append({'run':run,'independentGeometryExactlyMatchesActualParent':True,'runnerOverallPassed':run=='run02','originalRunnerFailureCount':sum(len(v['failures'])for v in q['originalRunnerFailures'])})
(out/'recompute-result.json').write_text(json.dumps({'allMathMatched':True,'runtimeRehashed':False,'results':results},indent=2)+'\n');print(json.dumps({'allMathMatched':True,'runtimeRehashed':False,'results':results}))
