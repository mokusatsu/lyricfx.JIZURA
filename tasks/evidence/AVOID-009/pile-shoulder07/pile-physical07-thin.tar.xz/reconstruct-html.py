"""Rebuild consumed historical HTML from verified tracked bc39ce2 inputs and supplied source patches.
No Git mutation; all extraction/build/patch writes go to a fresh requested /tmp directory.
"""
from pathlib import Path
import argparse,subprocess,hashlib,json,os
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out).resolve();assert str(out).startswith('/tmp/'),'Fresh /tmp destination required';out.mkdir(exist_ok=False)
base=Path(__file__).resolve().parent;commit='bc39ce2b7893a514e6ddd7e053312dde469f8640';refs=json.loads((base/'git-build-references.json').read_text());expected=json.loads((base/'html-reconstruction.json').read_text());rows=[]
for variant in ['native02','diagnostic04','physical05','physical06','physical07']:
 d=out/variant;d.mkdir()
 for row in refs:
  b=subprocess.check_output(['git','show',commit+':'+row['path']],cwd=a.repo);assert hashlib.sha256(b).hexdigest()==row['sha256'],row['path'];f=d/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
 for patch in ['source.patch','root-fix.patch']+(['diagnostic04.patch'] if variant in ['diagnostic04','physical05','physical06','physical07'] else [])+(['physical05.patch'] if variant in ['physical05','physical06','physical07'] else [])+(['physical06.patch'] if variant in ['physical06','physical07'] else [])+(['physical07.patch'] if variant=='physical07' else []):
  subprocess.run(['patch','-p1','--fuzz=0','--batch','--input',str(base/'source'/patch)],cwd=d,check=True,stdout=subprocess.PIPE)
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'};subprocess.run(['python','build.py'],cwd=d,check=True,env=env,stdout=subprocess.PIPE)
 for rel in ['index.html','en/index.html']:
  f=d/rel;h=hashlib.sha256(f.read_bytes()).hexdigest();key=variant+':'+rel;want=expected.get(key)
  if want:assert h==want['sha256'],key
  rows.append(dict(variant=variant,path=rel,bytes=f.stat().st_size,sha256=h,matchedConsumedSnapshot=bool(want)))
(out/'reconstruction-result.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
