"""Portable replay of parent math ONLY; original parent source/results unchanged.
Derived copies replace ONLY absolute base/output paths. Runtime rehash skipped;
restore-inputs already hashes all nonruntime bytes. No JS/browser/network.
"""
from pathlib import Path
import argparse,subprocess,json
p=argparse.ArgumentParser();p.add_argument('--evidence-base',required=True);p.add_argument('--out',required=True);a=p.parse_args();b=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert str(out).startswith('/tmp/');out.mkdir(exist_ok=False);rows=[]
for name in ['parent-pile-physical07-base','parent-pile-shoulder07']:
 src=b/'parent'/(name+'.py');text=src.read_text();target='/tmp/'+name+'.json';assert text.count(repr(target))==1;text=text.replace(repr(target),repr(str(out/(name+'.json'))),1)
 argv=['python',str(out/(name+'.py'))]
 if name=='parent-pile-physical07-base':argv += [a.evidence_base,'--skip-input-rehash']
 else:
  original="base=pathlib.Path('/tmp/avoid009-pile01/physical07')";assert text.count(original)==1;text=text.replace(original,'base=pathlib.Path('+repr(a.evidence_base)+')',1)
 (out/(name+'.py')).write_text(text);r=subprocess.run(argv,check=True,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);rows.append(json.loads((out/(name+'.json')).read_text()))
(out/'recompute-result.json').write_text(json.dumps({'mathPassed':all(q['status']=='PASS'for q in rows),'runtimeRehashed':False,'pathOnlyDerivedParentCopies':True,'results':rows},indent=2)+'\n');print(json.dumps({'mathPassed':all(q['status']=='PASS'for q in rows),'runtimeRehashed':False}))
