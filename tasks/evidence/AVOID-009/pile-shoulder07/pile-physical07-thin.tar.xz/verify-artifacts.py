"""Verify sealed artifact bytes before offline reconstruction. No network/browser."""
from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent;q=json.loads((b/'artifact-manifest.json').read_text())['files']
for x in q:
 p=b/x['path'];assert p.stat().st_size==x['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['path']
print(json.dumps({'artifactPinsExact':len(q)}))
