Actual07run01 parent-executed terminalexit1. No complete cases/rows: page.evaluate threw Empty/nonfinite ink at translated proposedStrictActualCircleClear when emitted circle-applicable polygon list was EMPTY on an early pass. This is runner empty-set semantics, not a source circle failure and not evidence that all functional checks executed. Original failingrunner/source/pre-run/raw/invocation/endpins preserved; all1074actualinputs unchanged. Parent failure receipt retained/pinned. No rerun/browser by child.

Fresh run02runner changes only output/prepin filenames and this callsite: strictPolygons.length===0 means proposedStrictActualCircleClear=true; otherwise call the unchanged A.clear. No product/source/API change. Other A.clear callsites inspected: offset witnesses pass one nonempty support polygon; entrycrossing tests pass one actual nonempty polygon inside filter callbacks, which are never invoked for an empty actual list. ActualitemGeometry/shape records contribute only existing nonempty polygons. No additional guard/test expansion needed.

All native/source/pixel/visibility/contiguousrun/budget/completegeometry/witness expectations retained exactly. Empty actual list still skips positivePixels assertion, as priorcondition actual.length>0; emitted actual list still requires positivePixels>0. No exception swallowing, tolerance relaxation or skipped actual checks.

Exact proposed parent-only ordinary command:
cd /tmp/avoid009-pile01 && node physical07/physical-trial-test-run02.cjs

Same local127.0.0.1 exactorigin-route abort policy. Source/HTML/cases unchanged. node--check only, no new module/browser execution. Output freshphysical07/run02, freshpre-run02.json. Original07run01FAIL remains historical evidence.
