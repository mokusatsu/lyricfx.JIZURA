from pathlib import Path
import json,hashlib,shutil
b=Path('/tmp/avoid009-pile01');r=b/'physical07';d=b/'thin-physical07';d.mkdir(exist_ok=False);old=b/'thin-physical06'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json']:put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical07.patch')
for run in ['run01','run02']:
 for p in (r/run).glob('*'):put(p,'evidence/'+run+'/'+p.name)
for n in ['parent-run01-failure.json','parent-terminal-receipts.json']:put(r/n,'evidence/'+n)
for n in ['parent-pile-physical07-base.py','parent-pile-physical07-base.json','parent-pile-shoulder07.py','parent-pile-shoulder07.json']:put(Path('/tmp')/n,'parent/'+n)
for p in r.iterdir():
 if p.is_file():put(p,'inputs/physical07/'+p.name)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical07:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text().replace("['native02','diagnostic04','physical05','physical06']","['native02','diagnostic04','physical05','physical06','physical07']").replace("variant in ['diagnostic04','physical05','physical06']","variant in ['diagnostic04','physical05','physical06','physical07']").replace("variant in ['physical05','physical06']","variant in ['physical05','physical06','physical07']").replace("(['physical06.patch'] if variant=='physical06' else [])","(['physical06.patch'] if variant in ['physical06','physical07'] else [])+(['physical07.patch'] if variant=='physical07' else [])")
(d/'reconstruct-html.py').write_text(s)
oldrows=json.loads((old/'portable-reference-map.json').read_text())['files'];oldmap={x['path']:x['portableReference']for x in oldrows};gitbysha={x['sha256']:x['portableReference']for x in oldrows if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run02.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p))
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction'if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical07','path':rel}
 elif p.is_relative_to(r):
  rel='inputs/physical07/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'1082run02actualinputs; exactsource/HTML reconstruction and verifiedGitrefs;567runtimebinaryCAS explicitlyEXTERNAL, notstandalone runtime; original1074run01inputs unchanged','files':files})
(d/'README.md').write_text('''Physical07 contiguous-shoulder diagnostic checkpoint. NO placement/quality/SAFE/adapter acceptance, no font reduction.

Parent actualrun01 session61247 terminalexit1: runner A.clear called with EMPTYstrict-polygons list on earlypass; completedRows0, all1074inputs unchanged. Original failingrunner/raw/invocation/endpins/failure receipt retained. This is runnerempty-set semantics, not sourcecircle failure and not allchecks executed. Fresh02runner changes onlyfreshoutput/prepin filenames and emptystrict list→true; unchanged A.clear otherwise. Parent actualrun02session40848exit0:2normalnR1cases120observations4515polygons0fail/errors,1082actualpostpins unchanged, originalsourceJSON/nestedfreeze unchanged. Parenttoolreturn receipts explicitly NOTshellcommandlogs. Raw02 SHA71baa5d182dac0bf15b4b1cedf68f4b807b6039e33afe4c4d30413e2df1fa784.

Two final selfcontained independentparent analyzers/results embedded. Verify8contiguousruns18slots includinggaps,54offsetwitnesses,72translatedframes25896shiftedvertices, sourceclocks/IDs/font/membership/paint/order, trueconvexhull coverage and exactlive-root postcamera transport.60nonempty translatedpaints positivepixel counts;12emptyghostpasses vacuouslyclear. rho1.1 has3Japanese/1gap prospectivecircleclearhullwitnesses, but allowedsource-footbudgetonly2/4or1/3: NOT placement orquality acceptance. Penetration/gap values are conservativeSOURCE-ENVELOPE budgets, not filledink physics. Verticalmultirow proofPENDING; no multirow/n1reflow. Entrycircle exception remains PROPOSALONLY, no stage/exit waiver.

Native/noRecipe+equivalent pixels compare06; OFFdirectdrawCut counts/pixels ONLY, historicalnative02wholeframe tests separate. Fullactual shiftedmeasuredguards stagecontained, exactdirect/replayRGBA andpositivecompositionpaint whennonempty; this does NOTprove eachowner unobscured/readable orhumanvisual quality. UntranslatedB0pixels retainclippedscope. No images/media/publicchecks.

Includes fullactualFAIL+PASS raw/runner/cases/invocations/endpins/prepins/source/math/parentreceipts, finalparentindependentchecks. Reconstruct native02/04/05/06/07 source+consumedJA/EN HTML from exact trackedGitbc39ce2pluspatches:all10historicalHTML exact. Canonicalnativefonts/fixture bytes individuallyverifiedGitrefs and restorable by restore-inputs.py. All567runtime binaries/wrapper/linkedlibs CAS EXTERNAL: NOTstandalone browserruntime; originalCAS paths declared. Earlierfullnative01FAIL/native02PASS/rootdiagnoses in6de061...;04in32c6f...;05in66d877...;06inf0a754... remainrequired for their earlierraw/history, not duplicated here.

Extract safely into a fresh directory, verify artifact-manifest.json SHA256 for EVERYentry before reconstruction. Then read-onlyGit/offlinewrites only, no browser/network:
python restore-inputs.py --repo /path/to/repo --out /tmp/pile-physical07-restore-fresh

This rebuilds all10HTML and copies/hashes everyembedded/reconstructed/Gitconsumedinput (including nativefont manifest/OTF/TTF) into out/consumed withoriginalisolationrelativepaths. restore-result.json lists exact matches and explicitlyEXTERNALruntimeCAS. Runtime is not downloaded/fetched. For source-only math recompute use the embedded parentanalyzer CLI --help; --base remaps isola­tion paths and --skip-input-rehash leaves runtime external rather than pretending it was restored. No JS/browser execution implied.
'''.replace('isola­tion','isolation'))
