from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).resolve().parent;s=json.loads((r/'start.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for pin in s['pins']+s['browserDependencies']:
 p=Path(pin['path']);a=sha(p);rows.append({'path':pin['path'],'before':pin['sha256'],'after':a,'equal':a==pin['sha256']})
main=Path('/workspace/lyricfx.JIZURA');mainrows=[{'path':p['path'],'before':p['sha256'],'after':sha(main/p['path'])}for p in s['mainCopiedFiles']]
d={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allInvocationPinsUnchanged':all(x['equal']for x in rows),'allMainCopiedFilesUnchanged':all(x['before']==x['after']for x in mainrows),'pins':rows,'mainCopiedFiles':mainrows}
(r/'end.json').write_text(json.dumps(d,indent=2)+'\n');assert d['allInvocationPinsUnchanged'] and d['allMainCopiedFilesUnchanged']
print(json.dumps({k:v for k,v in d.items()if k not in ['pins','mainCopiedFiles']}))
