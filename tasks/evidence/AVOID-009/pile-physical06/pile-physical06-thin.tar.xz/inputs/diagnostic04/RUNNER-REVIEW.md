Unexecuted focused functional diagnostic runner prepared after the two source-domain fixes.

Exact proposed parent command:

    cd /tmp/avoid009-pile01 && node diagnostic04/native-diagnostic-test.cjs

Four normal representatives: landscape push, portrait panL with original display extension, Latin/Unicode/gap panR, nonzero-start/fps60/koma12 dutch. Each uses all main/A/B source passes at four selected real times, with render scales1/.1/4/1. The complete continuous diagnostic is evaluated once per case; discrete actual observations only falsify its conservative support. No samples tighten bounds or admit a safe result.

Actual clocks mirror renderer tq/tp/lt/ltb and J.lyricCutsAt selection, then J.lyricRenderCut effective duration/group exit/outDur. The test composes the actual stock camera/chroma root once at the selected render scale, records unchanged native source events, and measures actual itemGeometry glyphs. Every heap glyph.index maps back to original native heap ordinal/gx/gy/id/ch and actual J.layoutText index; the source callback values and original membership counts remain in raw. Every actual guarded glyph/shape polygon is checked against its exact owner/pass/source-clock interval box; pixel imagery is not produced or read. Full raw proof/actual polygons and source clocks remain available for independent parent math recomputation.

Before/after complete plan JSON plus every nested object's freeze/seal/extensibility state must match. Pile adapter registry remains empty; diagnostic status must remain diagnostic-only with no safety certificate. All four real stock camera pointers must match the late-captured helper; the helper property is read-only. Only three simple functional out-of-domain requests are checked: cut.trans wipe, unsupported camera roll, renderScale0. There are no registry/prototype/callback mutations, fuzz/cyber checks, source geometry candidates, publication or performance tests.

Fresh version/ contains the96current source JS files and tracked build/font/fixture inputs. It was built offline without executing09u; current sealednative02HTML is unchanged. Complete pre-run input bytes (source, built HTML, runner/cases, fonts, support fixtures, existing Chromium/Playwright/shared-library runtime) are frozen and individually pinned before any browser. Runner binds ephemeral127.0.0.1 and aborts every request outside the exact local origin, recording only blocked hostnames. Parent must review revised math/source, actual runner and complete pins before execution. No browser/module test has run yet.
