from pathlib import Path
import json,hashlib,gzip,shutil,tarfile
b=Path('/tmp/avoid009-pile01');r=b/'physical06';d=b/'thin-physical06';d.mkdir(exist_ok=False);old=b/'thin-physical05'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json']:put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical06.patch')
for p in (r/'run01').glob('*'):put(p,'evidence/'+p.name)
put(r/'command-run01.log','evidence/command-run01.log')
for n in ['parent-pile-physical06.py','parent-pile-physical06.json']:put(Path('/tmp')/n,'parent/'+n)
for p in r.iterdir():
 if p.is_file():put(p,('history/'if '.review'in p.name else'inputs/physical06/')+p.name)
current={x['sha256']for x in json.loads((r/'pre-run.json').read_text())['files']};delta=[]
for p in r.glob('pre-run.json.review*'):
 for x in json.loads(p.read_text())['files']:
  if x['sha256']not in current:
   snap=Path(x['snapshot']);put(snap,'history/cas/'+snap.name);delta.append({**x,'portableSnapshot':'history/cas/'+snap.name})
write('history/historical-delta-snapshots.json',delta)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical06:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text().replace("['native02','diagnostic04','physical05']","['native02','diagnostic04','physical05','physical06']").replace("variant in ['diagnostic04','physical05']","variant in ['diagnostic04','physical05','physical06']").replace("(['physical05.patch'] if variant=='physical05' else [])","(['physical05.patch'] if variant in ['physical05','physical06'] else [])+(['physical06.patch'] if variant=='physical06' else [])")
(d/'reconstruct-html.py').write_text(s)
oldrows=json.loads((old/'portable-reference-map.json').read_text())['files'];oldmap={x['path']:x['portableReference']for x in oldrows};gitbysha={x['sha256']:x['portableReference']for x in oldrows if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p))
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction'if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical06','path':rel}
 elif p.is_relative_to(r):
  rel='inputs/physical06/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'948actualinputs; exactsource/HTML reconstruction and verifiedGitrefs;567runtimebinaryCAS explicitlyEXTERNAL, notstandalone runtime','files':files})
(d/'README.md').write_text('''Physical06 isolated analytic-support/nativefont geometry trial checkpoint. NO adapter, SAFE/outcome, stage/circle fit, visual/readability acceptance, or font reduction.

Parent executed run01 exit0:2ordinarycases96observations3936polygons0fail/errors. Source JSON/nested freeze state unchanged,948actualpostpins unchanged. Raw6ee35b256cc3413a44d4bac50db092098c81cd30b2632cb22b42efa7fc1ba79b. Parent selfcontained independent source/math/analytictrig/settledsy/actualheight/convexcamera-hull checks embedded. Native/noRecipe+native-equivalent pixels compare05; OFFdirectdrawCut counts/pixels ONLY, not wholeframe. PhysicalB0maypaint offcanvas: physicalRGBA clipped-raster scope, all complete measured geometry retained numerically. Vertical prior-layer budget PENDING. AA/time/membership unions remain broad; no fit/impossibility/fontshrink conclusion.512EPS ordinarymodel is not formal libm guarantee.

Includes fullactual raw/summary/runner/cases/log/prepins/endpins, source/math and unexecuted06review history/deltaCAS. Native02/diagnostic04/physical05/physical06source and consumed JA/EN HTML reconstructed from exactGitbc39ce2pluspatches. Canonicalfonts/fixture/build inputs individuallyverifiedGit references. All567runtime binaryCAS EXTERNAL at original paths: not standalone runtime. Earlier05fullraw and review histories sealed in capsule66d8776d...; earliernative01FAIL/native02PASS/rootdiagnoses in6de061...; diagnostic04in32c6f... . These prior capsules remain required for their earlier fullraw history, not duplicated here; failures are retained.

Read-only reconstruction, no browser/network:
python reconstruct-html.py --repo /path/to/repo --out /tmp/pile-physical06-reconstruction-fresh
''')
