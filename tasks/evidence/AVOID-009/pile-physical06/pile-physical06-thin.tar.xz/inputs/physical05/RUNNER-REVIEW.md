UNEXECUTED focused physical trial05. No adapter, safety outcome, actual circle-clearance acceptance, visual acceptance, or font reduction.

Exact proposed parent-only command:
cd /tmp/avoid009-pile01 && node physical05/physical-trial-test.cjs

Two existing ordinary fixtures: landscape push, scale1, four Japanese main glyphs; portrait panL, scale.1,14glyphs/3rows. Four real times .08/.42/.7699999/3.85, actual quantized main/A/B clocks. Both are unchanged camera cut/cut/still/none. Runs frozen04 consumed HTML as reference, then new05 native/noRecipe, native-equivalent, and two reviewed physical recipes at native font: a.90/beta.40/rise.10/k.60 and a.84/beta.25/rise.10/k1. Only six complete trial proofs total, not65family search. Prepared runner syntax only; no module execution.

Expected05actual observations:2cases*4choices*4times*3passes=96, plus24reference04observations. OFF direct drawCut samples (not whole renderer.frame) at four times each case compare exactRGBA SHA and adv/measure/fitSize/layoutText/fillText/strokeText call counts against04; instrumentation restored before identity-guarded source calls. Native/noRecipe and native-equivalent compare exact direct pixels to04. All programs compare direct/replay exactRGBA SHA; selected main dust-boundary time also offset[13,-17] for native-equivalent/two physical recipes. Pixels read only after complete paint; no midpaint readback.

All choices compare projected original catalog fields and exact source event order against04: row/slot/gaps/counts/nativefit/clocks/seeds/font/size/heapIDs/gxgy/ordinal/pool/a/c/rot, original heap x/y and original mainlaunch/x. New nativeGxp/originalLaunchY fields are explicitly additive metadata, not claimed to make whole catalogs identical. Physical y/tilt/body/floor/contact/density can differ and are raw evidence, not excluded ownership.

Every actual itemGeometry glyph uses actualglyph.index to map heap catalog ordinal/ch/gxgy and actual J.layoutText ch; polygons are checked against continuous stage envelopes for every phase/pass. Every body/heap/dust polygon and each individually settled main originalf>=1 polygon is checked against its separate circle-strict ENVELOPE. This checks envelope coverage, NOTcircle clearance or SAFE. Full guarded ink polygons retained numerically; no images generated/viewed. Physical launch rawdrop>=guardheight and F>=allbodytops+.82cell/potentialheapguardbottom are asserted; positive anchor gap asserted. Heap intersection increase and row budget failures are reported, not recipe rejection. Prior-layer vertical acceptance explicitly PENDING.

Deep source JSON and every nested object's frozen/sealed/extensible state are compared before/after preparation and all drawing. Trial recipe owned/frozen, no pile adapter registered, no safe status. Trial broad20.25AAreserve and all-angle settled support may block fit; this cannot justify font reduction. No trial/candidate selection or registry activation occurs.

HTTP server binds ephemeral127.0.0.1 only. Browser route interception permits only that exact origin plus slash and aborts every other route before request, logging sanitized host only. Local numericRGBA/artifact SHA only. No public URLs/HTTP/hash/result checks, images/media, external probing, or extra browser retries.

All actual inputs including04referenceHTML, new97JS/consumedHTML/build inputs/fonts/fixture, runner/cases/math/patch, existing browser wrapper/node/Chromium/libs are frozen in pre-run.json BEFORE any parent execution. Old native01 failure/native02 PASS/diagnoses/04 archives are untouched.

The20OFF whole-frame comparisons from actual native02 remain separate historical evidence; this05runner covers direct drawCut OFF only.
