from pathlib import Path
import argparse,json,hashlib,subprocess,shutil
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--out',required=True);a=p.parse_args()
root=Path(__file__).resolve().parent;out=Path(a.out).resolve();assert not out.exists();out.mkdir(parents=True)
source=json.loads((root/'source-provenance02.json').read_text());rows=[]
for q in source['gitRefs']:
 ref=q['restore'];b=subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','show',ref['commit']+':'+ref['path']],cwd=a.repo)
 assert hashlib.sha256(b).hexdigest()==q['sha256'] and len(b)==q['bytes'],q['path']
 target=out/Path(q['path']).relative_to('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);rows.append(q['path'])
for q in source['embedded']:
 b=(root/q['capsuleMember']).read_bytes();assert hashlib.sha256(b).hexdigest()==q['sha256'] and len(b)==q['bytes'],q['path']
 target=out/Path(q['path']).relative_to('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);rows.append(q['path'])
(out/'restore-receipt.json').write_text(json.dumps({'actualConsumedInputs':len(rows),'allHashesVerified':True,'network':0,'runtimeExternal':True,'paths':rows},indent=2)+'\n');print(len(rows))
