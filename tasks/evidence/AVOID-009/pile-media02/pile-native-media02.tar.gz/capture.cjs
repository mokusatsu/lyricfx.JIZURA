'use strict';
const fs=require('fs'),path=require('path'),http=require('http'),crypto=require('crypto'),zlib=require('zlib'),assert=require('assert/strict'),{spawn,execFileSync}=require('child_process');
const root=__dirname,out=path.join(root,'output01'),version='/tmp/avoid009-pile01/physical10/version',sha=b=>crypto.createHash('sha256').update(b).digest('hex'),pins=JSON.parse(fs.readFileSync(root+'/pins.json')),spec=JSON.parse(fs.readFileSync(root+'/spec.json'));
function verify(){for(const q of pins.files)assert.equal(sha(fs.readFileSync(q.path)),q.sha256,q.path);}
async function setup({spec,fonts,side}){
 window.r=await runLayoutsBFixture(J,{...spec,control:side==='before'?'off':'auto'},{newPath:false,fonts,renderInitial:false,exportDataURL:false});
 r.plan.fps=60;r.plan.fx.koma=0;
 window.sourcePlan=r.plan;window.sourceJSON=JSON.stringify(sourcePlan);
 if(side==='after')r.plan=J.finalizePlacementPlan(sourcePlan,{layoutsD:true});
 window.renderJSON=JSON.stringify(r.plan);window.nativeRecords=[];const observerParity=[];
 // Observe source drawCut without changing the real native drawing. The recording
 // call uses its own proxy context; only the original subsequent draw paints.
 if(side==='before'){
  const original=r.renderer.drawCut;let recording=false;
  r.renderer.drawCut=function(env){if(recording)return original.call(this,env);recording=true;let p;try{p=J.placement.record(this,env);}finally{recording=false;}
   nativeRecords.push({pass:env.pass,motionTime:env.t,realTime:env.realTime,lt:env.lt,ltb:env.ltb,root:(()=>{const m=env.ctx.getTransform();return[m.a,m.b,m.c,m.d,m.e,m.f];})(),measurementSupported:p.measurementSupported,diagnostics:p.diagnostics,geometry:p.nativeDGeometry,events:p.events.map(e=>({kind:e.kind,owner:e.owner,role:e.role,order:e.order,args:e.args,polygons:e.polygons,matrix:e.matrix,glyphs:e.kind==='item'?J.placement.itemGeometry(e.args[0],e.matrix,env).glyphs:null}))});return original.call(this,env);};
  const wrapped=r.renderer.drawCut,hash=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b))).map(x=>x.toString(16).padStart(2,'0')).join('');
  for(const t of [.6,.9]){r.renderer.drawCut=original;r.renderer.frame(r.canvas.getContext('2d'),r.plan,t,{noHud:true,noPost:true});const native=await hash(r.canvas.getContext('2d').getImageData(0,0,r.plan.W,r.plan.H).data);r.renderer.drawCut=wrapped;r.renderer.frame(r.canvas.getContext('2d'),r.plan,t,{noHud:true,noPost:true});const observed=await hash(r.canvas.getContext('2d').getImageData(0,0,r.plan.W,r.plan.H).data);observerParity.push({t,native,observed,equal:native===observed});}
 }
 return {sourcePlan:JSON.parse(sourceJSON),renderPlan:JSON.parse(renderJSON),observerParity,fontAudit:layoutsBFixtureFontAudit,fontsStatus:document.fonts.status,dpr:devicePixelRatio};
}
async function frame(n){
 const observations=[];nativeRecords.length=0;
 r.renderer.frame(r.canvas.getContext('2d'),r.plan,n/60,{noHud:true,noPost:true,placementObservation:q=>observations.push(q)});
 return {png:r.canvas.toDataURL().split(',')[1],observations,nativeRecords,sourceUnchanged:sourceJSON===JSON.stringify(sourcePlan),renderUnchanged:renderJSON===JSON.stringify(r.plan)};
}
const receipt={scope:'ONE bounded representative pile comparison; no human acceptance, full family, formal performance,009 completion or010 activation',before:'bc39ce2b7893a514e6ddd7e053312dde469f8640',after:'064cd99978bc19e23051352e2bbdca0258d03220',spec,publicChecks:0,creatorImageViews:0,parentImageViews:0,sourcePinsSHA256:sha(fs.readFileSync(root+'/pins.json')),sides:{},assets:{},errors:[],networkAborts:[]};
function add(name,b){fs.writeFileSync(path.join(out,name),b);receipt.assets[name]={bytes:b.length,sha256:sha(b)};}
const server=http.createServer((req,res)=>{try{const p=new URL(req.url,'http://localhost').pathname;if(p==='/before.html')return res.end(fs.readFileSync(root+'/before-bc39.html'));if(p==='/after.html')return res.end(fs.readFileSync(version+'/index.html'));const file=path.resolve(version,'.'+p);if(!file.startsWith(version+'/'))return res.writeHead(403).end();res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}});let browser;
(async()=>{
 verify();assert(!fs.existsSync(out),'fresh output required');fs.mkdirSync(out);fs.mkdirSync(out+'/images');fs.mkdirSync(out+'/videos');add('spec.json',fs.readFileSync(root+'/spec.json'));add('pins.json',fs.readFileSync(root+'/pins.json'));add('capture.cjs',fs.readFileSync(__filename));
 await new Promise((ok,bad)=>{server.once('error',bad);server.listen(0,'127.0.0.1',ok);});const origin='http://127.0.0.1:'+server.address().port;
 browser=await require('/tmp/avoid009-pile01/dev/browser.cjs').launch({headless:true,executablePath:'/usr/bin/chromium',args:['--disable-dev-shm-usage']});receipt.browser=browser.version();const fonts=JSON.parse(fs.readFileSync(version+'/dev/avoidance/layouts-c-editorial-fonts/manifest.json'));
 const pages={};
 // Fresh fps60 finalize is mandatory and all preflights precede encoding.
 for(const side of ['before','after']){
  const page=pages[side]=await browser.newPage({viewport:{width:1280,height:800},deviceScaleFactor:1});page.on('pageerror',e=>receipt.errors.push(String(e)));
  await page.route('**/*',route=>{if(new URL(route.request().url()).origin===origin)return route.continue();receipt.networkAborts.push({host:new URL(route.request().url()).hostname,action:'aborted-before-request'});return route.abort();});
  await page.goto(origin+'/'+side+'.html');await page.waitForFunction(()=>window.J?.ui?.plan);await page.addScriptTag({path:version+'/dev/avoidance/layouts-b-fixture.js'});
  const actual=await page.evaluate(setup,{spec,fonts,side});if(side==='before')assert(actual.observerParity.length===2&&actual.observerParity.every(x=>x.equal),'before observer changes pixels');assert.equal(actual.sourcePlan.fps,60);assert.equal(actual.sourcePlan.fx.koma,0);assert.equal(actual.dpr,1);assert(actual.fontAudit.faces.every(f=>f.status==='loaded'));assert.equal(actual.sourcePlan.cuts[0].text,spec.text);assert.deepEqual(actual.sourcePlan.cuts[0].params,spec.params);assert(!actual.sourcePlan.cuts[0].placementTrajectory);
  if(side==='after'){const tr=actual.renderPlan.cuts[0].placementTrajectory;assert.equal(tr?.safety,'certified-bounded-adapter',JSON.stringify(actual.renderPlan.placementFinalization));assert.equal(tr.units[0].segments.length,1);assert.equal(tr.units[0].segments[0].start,0);assert.equal(tr.units[0].segments[0].end,4);assert.equal(tr.units[0].segments[0].status,'safe');}
  receipt.sides[side]={input:side+'-inputs.json.gz',keys:[]};add(side+'-inputs.json.gz',zlib.gzipSync(JSON.stringify(actual)));console.log(JSON.stringify({preflight:side,safety:actual.renderPlan.cuts[0].placementTrajectory?.safety||'native avoidance OFF',fps:60}));
 }
 const b=JSON.parse(zlib.gunzipSync(fs.readFileSync(out+'/before-inputs.json.gz'))).sourcePlan,a=JSON.parse(zlib.gunzipSync(fs.readFileSync(out+'/after-inputs.json.gz'))).sourcePlan;
 for(const key of ['style','fx','W','H','fps','duration','events','beats'])assert.deepEqual(a[key],b[key],key);
 for(const key of ['params','text','words','lineText','seed','start','end','dur','cam','camP','motionScale','contentScale','area'])assert.deepEqual(a.cuts[0][key],b.cuts[0][key],key);
 verify();
 for(const side of ['before','after']){
  const video='videos/pile-'+side+'.mp4',args=['-y','-f','image2pipe','-vcodec','png','-framerate','60','-i','pipe:0','-an','-c:v','libx264','-threads','2','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',out+'/'+video],encoder=spawn('ffmpeg',args,{stdio:['pipe','ignore','pipe']});let stderr='';encoder.stderr.on('data',b=>stderr+=b);const done=new Promise((ok,bad)=>{encoder.on('error',bad);encoder.on('close',c=>c===0?ok():bad(Error(stderr)));});const rows=[];
  try{for(let n=0;n<240;n++){
   const raw=await pages[side].evaluate(frame,n);assert(raw.sourceUnchanged&&raw.renderUnchanged);const obs=side==='after'?raw.observations:raw.nativeRecords;
   const tq=Math.floor((n/60)/(1/60)+1e-6)/60,expected=['B','A','main'].map(pass=>{const lag=pass==='B'?1.6/24:pass==='A'?.8/24:0,tp=Math.max(0,tq-lag);return{pass,lag,tp};});assert.equal(obs.length,3,'whole frame3passes '+n);
   for(let i=0;i<3;i++){const o=obs[i],e=expected[i];assert.equal(o.pass,e.pass);assert(Math.abs(o.motionTime-e.tp)<1e-12);assert(Math.abs(o.lt-e.tp)<1e-12);assert(Math.abs(o.ltb-(e.tp+e.lag))<1e-12);if(side==='after'){assert.equal(o.realTime,n/60);assert(o.envelopeCovered&&o.stageContained&&o.strictCircleClear&&o.safety==='safe');assert.equal(o.activeRegion,'normal');}else assert(o.measurementSupported,JSON.stringify(o.diagnostics));}
   const png=Buffer.from(raw.png,'base64');assert.equal(png.readUInt32BE(16),1280);assert.equal(png.readUInt32BE(20),720);rows.push({frame:n,time:n/60,encoderInputPNG:sha(png),observations:raw.observations,nativeRecords:raw.nativeRecords});
   if(spec.keyframes.includes(n)){const file='images/pile-'+side+'-'+String(n).padStart(3,'0')+'.png';add(file,png);receipt.sides[side].keys.push({frame:n,time:n/60,file});}
   if(!encoder.stdin.write(png))await new Promise(ok=>encoder.stdin.once('drain',ok));
  }encoder.stdin.end();await done;}catch(e){encoder.kill();throw e;}
  const probe=JSON.parse(execFileSync('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',out+'/'+video],{encoding:'utf8'})),s=probe.streams.find(s=>s.codec_type==='video');assert.equal(s.nb_read_frames,'240');assert.equal(s.nb_frames,'240');assert.equal(s.avg_frame_rate,'60/1');assert.equal(s.r_frame_rate,'60/1');assert.equal(Number(s.duration),4);assert.equal(s.width,1280);assert.equal(s.height,720);
  const distinct=new Set(rows.map(r=>r.encoderInputPNG)).size;assert(distinct>200,'native visible motion');add(side+'-frames.json.gz',zlib.gzipSync(JSON.stringify(rows)));add(side+'-motion.json',Buffer.from(JSON.stringify(rows.map(r=>({frame:r.frame,time:r.time,encoderInputPNG:r.encoderInputPNG})))));receipt.assets[video]={bytes:fs.statSync(out+'/'+video).size,sha256:sha(fs.readFileSync(out+'/'+video))};Object.assign(receipt.sides[side],{video,probe,distinct,frameReceipt:side+'-frames.json.gz',encoderArgs:args});await pages[side].close();console.log(JSON.stringify({encoded:side,distinct,bytes:receipt.assets[video].bytes}));
 }
 assert.equal(receipt.errors.length,0);verify();receipt.status='Local wholeframe native60 source/clock/geometry guards and ffprobe passed; independent visual review and human review pending';receipt.completedAt=new Date().toISOString();add('index.html',fs.readFileSync(root+'/compare-template.html'));add('en.html',fs.readFileSync(root+'/compare-template-en.html'));fs.writeFileSync(out+'/manifest.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify({output:out,manifestSHA256:sha(fs.readFileSync(out+'/manifest.json'))}));
})().catch(e=>{if(fs.existsSync(out))fs.writeFileSync(out+'/failure.json',JSON.stringify({error:String(e),stack:e.stack,receipt},null,2));console.error(e);process.exitCode=1;}).finally(async()=>{await browser?.close();if(server.listening)await new Promise(ok=>server.close(ok));});
