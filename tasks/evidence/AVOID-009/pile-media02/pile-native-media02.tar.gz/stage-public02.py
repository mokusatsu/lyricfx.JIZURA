from pathlib import Path
import hashlib,json,shutil,datetime
r=Path(__file__).resolve().parent
source=r/'output02'
clone=Path('/tmp/avoid009-motion2-sites-synced01')
dist=clone/'dist'
target=dist/'review/AVOID-009/pile-selected-20261024-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert dist.is_dir() and not target.exists(),'Existing dist required and new target must be absent'
before={str(p.relative_to(dist)):sha(p) for p in sorted(dist.rglob('*')) if p.is_file()}
m=json.loads((r/'public-media-manifest02.json').read_text())
for rel,q in m['assets'].items():
 p=source/rel
 assert p.stat().st_size==q['bytes'] and sha(p)==q['sha256'],rel
target.mkdir(parents=True)
for rel in m['assets']:
 p=target/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/rel,p)
shutil.copyfile(r/'public-media-manifest02.json',target/'media-manifest.json')
after={str(p.relative_to(dist)):sha(p) for p in sorted(dist.rglob('*')) if p.is_file() and not p.is_relative_to(target)}
assert before==after,'Existing dist changed'
projection={str(p.relative_to(target)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(target.rglob('*')) if p.is_file()}
assert len(projection)==22
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Local source projection only; no Git/push/publish/public result checks','clone':str(clone),'newPath':str(target),'existingDistFilesPreserved':len(before),'existingRootLandingPreserved':before.get('index.html')==after.get('index.html'),'allExistingDistExactlyPreserved':before==after,'files':projection,'publicChecks':0,'imagesViewed':0}
(r/'projection-receipt02.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'target':str(target),'files':len(projection),'bytes':sum(v['bytes']for v in projection.values()),'allExistingDistExactlyPreserved':True}))
