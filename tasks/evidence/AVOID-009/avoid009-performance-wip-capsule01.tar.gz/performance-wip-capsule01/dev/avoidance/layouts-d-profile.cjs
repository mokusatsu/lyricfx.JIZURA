'use strict';
// Phase diagnostic only: reuse the exact performance workload's evaluator,
// prepare a completed result, then profile its repeat. No timing acceptance.
const fs=require('node:fs'),assert=require('node:assert/strict'),zlib=require('node:zlib'),H=require('./layouts-b-test-harness.cjs');
(async()=>{
 const target=process.env.JIZURA_D_PROFILE_REPORT||'/tmp/avoid009-profile01.json',perfFile=__dirname+'/layouts-d-perf.cjs',perf=fs.readFileSync(perfFile,'utf8'),startup=H.pin(target,__filename,['dev/avoidance/layouts-d-perf.cjs','dev/avoidance/layouts-a-fixture.js']);
 const begin='report.sides[side]=await page.evaluate(',end='},{side,config});',at=perf.indexOf(begin),stop=perf.indexOf(end,at);assert(at>=0&&stop>at);
 const evaluator=perf.slice(at+begin.length,stop+1).replace('return {results,stress};','return {results,stress,exactCache:J.placement.layoutsCFinalCacheStats(),proofMemo:J.placement.layoutsDFisheyeProofMemoStats?.()};');
 const h=await H.open();
 try{
  await h.page.addScriptTag({content:fs.readFileSync(__dirname+'/layouts-a-fixture.js','utf8')});
  // The existing A fixture loads its pinned single-face URL; remap that exact
  // local request to the archived TTC bytes rather than aborting font requests.
  const fontPath='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',font=fs.readFileSync(fontPath);fs.writeFileSync(target+'-font.ttc.gz',zlib.gzipSync(font,{mtime:0}));
  await h.page.route('**/font.otf',r=>r.fulfill({body:font,contentType:'font/collection'}));
  const args={side:'after',config:{sizes:[1000],warmup:0,samples:1,stress:false,runtimeProfile:false}},invoke=()=>h.page.evaluate('('+evaluator+')('+JSON.stringify(args)+')');
  const cold=await invoke(),session=await h.page.context().newCDPSession(h.page);await session.send('Profiler.enable');await session.send('Profiler.setSamplingInterval',{interval:500});await session.send('Profiler.start');
  const repeat=await invoke(),{profile}=await session.send('Profiler.stop');
  H.verify(startup);assert.equal(cold.results[0].inputSHA256,repeat.results[0].inputSHA256);assert(repeat.exactCache.hits>cold.exactCache.hits,'Repeat must actually hit the completed cache');
  fs.writeFileSync(target+'.gz',zlib.gzipSync(JSON.stringify({scope:'1000-cut cold and exact-repeat phase diagnostic; timings have no acceptance assertion',startup,cold,repeat,warnings:h.warnings,font:{path:fontPath,sha256:H.sha(font)},browser:h.browser.version()}),{mtime:0}));fs.writeFileSync(target+'.cpuprofile.gz',zlib.gzipSync(JSON.stringify(profile),{mtime:0}));
  const nodes=new Map(profile.nodes.map(n=>[n.id,n])),cost=new Map();for(let i=0;i<(profile.samples||[]).length;i++){const n=nodes.get(profile.samples[i]),key=n.callFrame.functionName+' '+n.callFrame.url+':'+n.callFrame.lineNumber;cost.set(key,(cost.get(key)||0)+(profile.timeDeltas[i]||0));}
  console.log(JSON.stringify({cold:cold.results[0].cold,repeat:repeat.results[0].cold,proofMemo:cold.proofMemo,cache:repeat.exactCache,topSelfMs:[...cost].sort((a,b)=>b[1]-a[1]).slice(0,25).map(([key,us])=>({key,ms:us/1000})),report:target+'.gz'}));
 }finally{await h.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
