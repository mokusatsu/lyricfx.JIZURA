# AVOID-009 performance WIP capsule

This is functional parent-accepted checkpoint10 WIP, NOT a formal performance pass and NOT part of the selected four-example preview. Parent alone owns Git staging/commits. Do not overwrite the working WIP when staging reviewed preview04 through index blobs. Original pycache is excluded.

Apply `performance-source.patch` to the exact preview04 source (manifest SHA2042464b01b16ef8bc0de800424f57892524464a42257e6fc03ffe045ded54d1), or restore the two included complete source files. Only09a and09l differ from that frozen source. No compiled HTML/fonts/heavy CPU profiles are included. Build with PYTHONDONTWRITEBYTECODE=1 python build.py after restoring both.

The source adds a synchronous per-finalization pool of pure frozen fisheye geometry/flat envelopes, post-solver diagnostic records and ordered record arrays. Separate128-entry caps share one8MB serialized data budget. Every region solver runs before diagnostic interning. Full JSON is equal to layoutsDProofMemo:false; intentional alias graphs and cold/hit descriptors/fresh objects are checked. Source keys keep complete relevant metadata; only audited identity/absoluteclock/background/unused none-treatment fields are omitted, with conservative raw-slot/stagger presence guard. Errors/contextual records remain fresh.

Proof10 passes six real three-cut glass/aspect families(108observations), changed circle/boundary fresh decisions/solver counts, distinct seeds, spaced/late-source coverage preservation,15key controls and shared output graph cold/hit/detachment. Cache04 separately passes six C/D cases and six invalidation controls. Source09n06 was then independently updated on main after profile06; the fisheye source and pool are unchanged. The source matrix is partial D capability, not all34 adapter support.

Profile06 is DIAGNOSTIC ONLY:1000cut cold finalization2584.6ms,total2874.2; repeat finalization235.4ms,total510.3.27proofs/26973reuse,27records/98907reuse,1array/2997reuse;599406serialized bytes. Completed payload6.02MB. Cold planning is still slow. Prior formal fisheye01/02 FAIL and previous diagnostic failures are retained under tasks/evidence/AVOID-009/performance and profile02..05. No formal warm3/sample6 pass is claimed.

Next: obtain parent exclusive CPU window after all media/core/native/child processes are reaped; rerun unchanged dev/avoidance/layouts-d-perf.cjs with PERF_REPORT=freshpath PERF_WARMUP=3 PERF_SAMPLES=6 JIZURA_BROWSER=/usr/bin/chromium and explicit normal local-network tool grant. Keep immutable6e before root,100/1000cuts+regions, full cold timings,80frames and100/1000region stress. No source edits during run.

Repro commands: JIZURA_D_PROOF_REPORT=freshpath node dev/avoidance/layouts-d-proof-memo-test.cjs; JIZURA_D_CACHE_REPORT=freshpath node dev/avoidance/layouts-d-cache-test.cjs; JIZURA_D_PROFILE_REPORT=freshpath node dev/avoidance/layouts-d-profile.cjs. Prelaunch source/HTML/font/test snapshots are in/tmp/avoid009-<run>-snapshot; CPU profile/tmp/avoid009-profile06.json.cpuprofile.gz. Exact small raw reports/logs are included. Heavy snapshots remain/tmp due>250MB root reserve, with receipts in repo.

No commit/push by implementation owner. No public result checks, images/video viewed, cybersecurity/proxy/fuzz work. Baseline and all existing WIP/artifacts preserved.
