from pathlib import Path
import json,hashlib,gzip,shutil,tarfile,subprocess,os
b=Path('/tmp/avoid009-pile01');r=b/'physical05';d=b/'thin-physical05';d.mkdir(exist_ok=False);old=b/'thin-diagnostic04';commit='bc39ce2b7893a514e6ddd7e053312dde469f8640'
def put(src,dst):
 dst=d/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,v):
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['git-build-references.json','html-reconstruction.json'] :put(old/n,n)
for p in (old/'source').glob('*'):put(p,'source/'+p.name)
put(r/'source.patch','source/physical05.patch')
for p in (r/'run01').glob('*'):put(p,'evidence/'+p.name)
put(r/'command-run01.log','evidence/command-run01.log')
for n in ['parent-pile-physical05.py','parent-pile-physical05.json']:put(Path('/tmp')/n,'parent/'+n)
for p in r.iterdir():
 if p.is_file():put(p,('history/' if '.review' in p.name or 'v01' in p.name else 'inputs/physical05/')+p.name)
for p in r.glob('source-review-pins*.json*'):
 try:q=json.loads(p.read_text())
 except:continue
 for x in q.get('files',[]):
  snap=Path(x['snapshot']);put(snap,'history/cas/'+snap.name)
expected=json.loads((d/'html-reconstruction.json').read_text())
for rel in ['index.html','en/index.html']:
 p=r/'version'/rel;expected['physical05:'+rel]={'bytes':p.stat().st_size,'sha256':sha(p)}
write('html-reconstruction.json',expected)
s=(old/'reconstruct-html.py').read_text().replace("['native02','diagnostic04']","['native02','diagnostic04','physical05']").replace("(['diagnostic04.patch'] if variant=='diagnostic04' else [])","(['diagnostic04.patch'] if variant in ['diagnostic04','physical05'] else [])+(['physical05.patch'] if variant=='physical05' else [])")
(d/'reconstruct-html.py').write_text(s)
oldmap={x['path']:x['portableReference']for x in json.loads((old/'portable-reference-map.json').read_text())['files']};gitbysha={x['sha256']:x['portableReference']for x in json.loads((old/'portable-reference-map.json').read_text())['files']if x['portableReference']['kind']=='verified-Git-reference'};files=[]
for x in json.loads((r/'pre-run.json').read_text())['files']:
 p=Path(x['path']);ref=oldmap.get(str(p));
 if ref:
  if ref['kind']=='embedded':put(p,ref['path'])
 elif x['sha256']in gitbysha:ref=gitbysha[x['sha256']]
 elif str(p).startswith(str(r/'version')+'/'):
  rel=str(p.relative_to(r/'version'));ref={'kind':'exact-HTML-reconstruction' if rel.endswith('index.html')else'exact-source-reconstruction','variant':'physical05','path':rel}
 elif p.is_relative_to(r):
  rel='inputs/physical05/'+str(p.relative_to(r));ref={'kind':'embedded','path':rel};put(p,rel)
 else:raise Exception(str(p))
 files.append({**x,'portableReference':ref})
write('portable-reference-map.json',{'scope':'822actual inputs; exactsource/HTML reconstruction and verifiedGitrefs;567runtime binary CAS explicitly EXTERNAL, not standalone runtime','files':files})
(d/'README.md').write_text('''Physical05 isolated native-font geometry trial checkpoint. NO adapter, SAFE/outcome, stage/circle fit, visual/readability acceptance, or font reduction.

Parent actually executed run01 exit0:2ordinarycases96observations3936polygons0fail/errors. Source JSON/nested freeze state unchanged,822actualpostpins unchanged. Raw2cdd0a6aa4612b2f45ff35fc76ede323cc090a5822f492ba25ecbffb72c08158; parent independent source/math/convex-camera-hull checks embedded. Native/noRecipe+native-equivalent pixels compare04; OFF checks directdrawCut counts/pixels ONLY, not wholeframe. Physical B0 may paint offcanvas: physicalRGBA parity is clipped-raster scope, complete measured geometry retained numerically. Pending vertical prior-layer budget comparison explicitly not accepted. Broad AA/all-angle/L1/proof-union support blocking is inconclusive, not impossibility or fontshrink justification.

Includes fullactual raw/summary/runner/cases/log/prepins/endpins, source/math/history and independent parent checks. Earlier unexecutedv01/review history preserved with its exact source CAS where referenced. Native02/diagnostic04/physical05source and consumed JA/EN HTML all reconstructed from exactGitbc39ce2 plus patches. Canonicalfonts/fixture/build inputs are individually verifiedGit references. All567runtime binary CAS explicitly EXTERNAL at original frozen-input paths: this is NOTa standalone runtime. Earlier fullnative01FAIL/native02PASS/diagnosis raw history remains in sealed native02capsule6de061... and diagnostic04capsule32c6f...; no old failures erased.

Read-only reconstruction, no browser/network:
python reconstruct-html.py --repo /path/to/repo --out /tmp/pile-physical05-reconstruction-fresh
''')
