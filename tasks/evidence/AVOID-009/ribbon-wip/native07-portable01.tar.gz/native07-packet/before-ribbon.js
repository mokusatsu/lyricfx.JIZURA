/* ================================================================== 6 ribbon — リボン */
reg('ribbon', {
  name: 'リボン', tags: ['pop', 'emotional', 'graphic'], w: 0.9, treat: 'safe', portrait: 0.7, ae: 'wave', fits: n => n >= 2 && n <= 16,
  enterBias: { cut: 1.8, blur: 1.2, pop: 0.8, slice: 0.3, stretch: 0.4 },
  plan(rng, cut, st) {
    return {
      font: rng.pick(fontsOf(st, ['display', 'serif'])), amp: rng.range(0.05, 0.1), freq: rng.range(0.55, 0.9), ph: rng.range(0, 6), col: rng.pick(['accent', 'accent', 'ink']),
      reveal: rng.pick(['center', 'left']), tilt: rng.range(-6, 6),
    };
  },
  render(env) {
    const { W, H, sc, ctx } = env, cut = env.cut, Pm = cut.params, u = U(env), lt = env.lt;
    const port = isPort(env);
    const t0 = flat(cut.text), n = J.glyphCount(t0);
    const rowsT = n > (port ? 6 : 10) ? chunksK(t0, n > 12 && port ? 3 : 2) : [t0];
    const nR = rowsT.length;
    const out = tout(env);
    const pc = plateCol(sc, Pm.col === 'ink' ? [sc.ink, sc.accent] : [sc.accent, sc.ink]);
    const back = shade(sc, pc, -0.42), tc = onCol(sc, pc);
    const mot = env.fx.motion ?? 0.7;
    let bb = null;
    const x0 = W * 0.09, x1 = W * 0.91, L = x1 - x0;
    // common text size so the rows match
    let size = u * 0.16;
    for (const r of rowsT) { let a = 0; for (const ch of r) a += adv(Pm.font, ch) * 1.05; size = Math.min(size, L * 0.58 / Math.max(1, a)); }
    size = Math.min(size, H * 0.62 / (nR * 2.3));
    const bw = size * 0.72;
    rowsT.forEach((row, ri) => {
      const cy = H / 2 + (ri - (nR - 1) / 2) * size * 2.35;
      const A = H * Pm.amp * (nR > 1 ? 0.55 : 1) * (1 + 0.12 * Math.sin(env.ltb * 1.1 + ri));
      const ph = Pm.ph + ri * 2.1 + env.ltb * 0.9 * mot * 0.6;
      const tl = Math.tan(Pm.tilt * J.DEG) * (ri % 2 ? -1 : 1);
      const path = x => [x, cy + A * Math.sin(J.TAU * Pm.freq * (x - x0) / L + ph) + (x - W / 2) * tl];
      // arc-length table
      const NS = 90, pts = [], acc = [0];
      for (let i = 0; i <= NS; i++) pts.push(path(x0 + L * i / NS));
      for (let i = 1; i <= NS; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
      const TL = acc[NS];
      const atS = s => { s = J.clamp(s, 0, TL); let lo = 0, hi = NS; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (acc[m] <= s) lo = m; else hi = m; } const f = (s - acc[lo]) / Math.max(1e-6, acc[hi] - acc[lo]); const p = [J.lerp(pts[lo][0], pts[hi][0], f), J.lerp(pts[lo][1], pts[hi][1], f)]; const ang = Math.atan2(pts[hi][1] - pts[lo][1], pts[hi][0] - pts[lo][0]); return { p, ang }; };
      // twist: flat front in the middle, ends folded to show the back
      const tau = f => { const d = Math.abs(f - 0.5); return d < 0.33 ? 1 : Math.cos(Math.PI * (d - 0.33) / 0.17); };
      const e = E.inOutCubic(J.clamp((lt - ri * 0.12) / 0.75)) * (1 - E.inCubic(env.pOut));
      const vis = f => (Pm.reveal === 'left' ? f <= e : Math.abs(f - 0.5) <= e / 2);
      // shadow + band
      const NB = 64, seg = [];
      for (let i = 0; i <= NB; i++) {
        const f = i / NB, q = atS(f * TL), t = tau(f), nx = -Math.sin(q.ang), ny = Math.cos(q.ang);
        seg.push({ f, t, a: [q.p[0] + nx * bw * t, q.p[1] + ny * bw * t], b: [q.p[0] - nx * bw * t, q.p[1] - ny * bw * t], p: q.p, ang: q.ang });
      }
      const sh = size * 0.1, vs = seg.filter(q => vis(q.f));
      if (vs.length > 1) env.poly(vs.map(q => [q.a[0] + sh, q.a[1] + sh * 1.4]).concat(vs.slice().reverse().map(q => [q.b[0] + sh, q.b[1] + sh * 1.4])), darkOf(sc), 0.22, false);
      // runs of segments facing the same way → one polygon each; the twist shading is laid over it
      let run = [];
      const flush = () => {
        if (run.length > 1) {
          const t = run[Math.floor(run.length / 2)].t;
          env.poly(run.map(q => q.a).concat(run.slice().reverse().map(q => q.b)), t >= 0 ? pc : back, 1, gIn(env) && t >= 0);
          if (t >= 0) env.line(run.filter(q => q.t > 0.6).map(q => q.a), shade(sc, pc, 0.3), Math.max(1, size * 0.02), 0.8, false);
        }
        run = [];
      };
      for (let i = 0; i <= NB; i++) {
        const q = seg[i];
        if (!vis(q.f)) { flush(); continue; }
        if (run.length && Math.sign(run[run.length - 1].t || 1) !== Math.sign(q.t || 1)) { const last = run[run.length - 1]; flush(); run.push(last); }
        run.push(q);
      }
      flush();
      for (let i = 0; i < NB; i++) {
        const A0 = seg[i], B0 = seg[i + 1];
        if (!vis(A0.f) || !vis(B0.f)) continue;
        const t = (A0.t + B0.t) / 2;
        if (Math.abs(t) > 0.97) continue;
        env.poly([A0.a, B0.a, B0.b, A0.b], darkOf(sc), (1 - Math.abs(t)) * 0.4, false);
      }
      // notched tails
      for (const end of [0, NB]) {
        const S0 = seg[end];
        if (!vis(S0.f)) continue;
        const dirn = end === 0 ? 1 : -1;
        const ext = [-Math.cos(S0.ang) * bw * 1.3 * dirn, -Math.sin(S0.ang) * bw * 1.3 * dirn];
        const c = shade(sc, back, -0.12);
        env.poly([S0.a, [S0.a[0] + ext[0], S0.a[1] + ext[1]], [S0.p[0] + ext[0] * 0.45, S0.p[1] + ext[1] * 0.45], [S0.b[0] + ext[0], S0.b[1] + ext[1]], S0.b], c, 1, false);
      }
      // lyric along the flat middle
      const chars = [...row], ads = chars.map(ch => adv(Pm.font, ch) * size * 1.05), tot = ads.reduce((a, b) => a + b, 0);
      let s0 = TL / 2 - tot / 2;
      chars.forEach((ch, i) => {
        const sc0 = s0 + ads[i] / 2; s0 += ads[i];
        if (ch === ' ') return;
        const f = sc0 / TL;
        if (!vis(f)) return;
        const q = atS(sc0);
        bb = UB(bb, J.mainDraw(env, { text: ch, font: Pm.font, size, x: q.p[0], y: q.p[1], rot: q.ang / J.DEG, sy: tau(f), color: tc, noHold: plateHold(env), mi: miAt(env, ri * 0.12 + (Pm.reveal === 'left' ? f : Math.abs(f - 0.5) * 2) * 0.6) }));
      });
    });
    return bb;
  },
});

