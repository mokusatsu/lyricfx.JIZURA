# Ribbon native checkpoint01 — NOT an accepted bounded adapter

Baseline parent snapshot23a62ee, isolated `/tmp/avoid009-ribbon01`; parent owns Git. Product source changed only `src/11p_layoutsD.js` ribbon block. Generated JA/EN HTML changes are local builds. No main workspace, public URL, media or broad matrix work performed. No09s registration/proof/recipes yet. Every lyric glyph, band side, highlight, twist, tail and shadow remains primary. Native within-row spaces have stable row:slot IDs and advances; original chunksK boundary spaces remain governed by unchanged source.

## Source

D-only metadata exposes native size, band width, original rows, actual91 path points/91 cumulative lengths, TL, exact e, actual65 band vertices and each original slot's advance/sc0/delta/f/visibility/rawMi. Visible mainDraw items carry row:slot identity and exact nativeF/nativeSc0/nativeTL. All painter calls have explicit primary ownership, preserving original order/arguments/ghost flags/alphas. OFF has no extra metrics, trigonometry, hypot or clock calculation; its nonspace item construction is unchanged. A paint dispatch wrapper and D boolean branches exist, so this is not a formal zero-CPU-overhead claim.

## Ordinary native evidence

`native06.json.gz` is the corrected comparison run.198 original temporal input records, repeated Japanese/Latin glyphs, internal Latin spaces, landscape/portrait and native1/3rows, reveal center/left; gate roots±1e-10 and stagger ratios near rawmi integer7±1e-15. Exact structural equality:91point table/acc/TL/e/65band/slots, mainDraw inputs, recorder events including matrices and polygons (source ownership fields intentionally excluded only for original comparison). Every emitted event has one declared primary owner.16 OFF direct frames compare exact RGBA SHA plus adv/sin/cos/hypot/atan2/tan call counts against the unmodified baseline.

`search01.json.gz` and `search01.log`: unchanged atS source line, independent linear scan vs native binary search at1662 cumulative-length ties±1e-10 and clamps.336 tables satisfy90chords/65bandvertices, TL>=L and T<=.58L. minChord3.2800006682608682>1e-6; min/max native glyph/space centre f .24056645188315814/.7571104052039047. This proves the tested numeric baseline; it is not a continuous-time guarded-ink attachment certificate.

## Transport blocker requiring parent decision

24 direct/replay cases cover push/dutch, scale.1/4, main/A/B, zero and independently inverse-root-shifted nonzero translation. One fails: dutch/scale4/main/offset[0,0], direct78d6248a… vs replaya75fa1b2….23 match. Runner exits1 and does not relabel this failure as success.

Proposed09a change, NOT implemented: add a private dRibbonCut matching placementLayoutsD=true, no A/B/C, exact registered ribbon source, cut/cut/still/none, no drawing/effectsOnly/decor; include only that predicate at main/A/B in nativeDOriginalRoot selection alongside accordion/flag. Preserve actual live root (before measurement Canvas rounding). No general affine/inverse/clip/projected-text change, no geometry guard change, no unrelated source admission. Parent must authorize this narrow shared-source edit before implementation.

## Preserved failures

native01: localhost listenEPERM before network grant. native02: default Playwright executable absent. native03/04: initial OFF harness incorrectly attempted to record unadapted source, diagnosed unsupported fill; test corrected to direct OFF rendering. native05: catalog comparator incorrectly used JSON key insertion order; Python independent structural equality198/198, fixed to isDeepStrictEqual for native06. All input snapshots/logs remain; native05 retains its raw failure. native06 fails only known transport case. No safety matrix or formal performance claim.

## Commands

From isolated root:

```
python3 build.py
JIZURA_BROWSER=/usr/bin/chromium JIZURA_D_RIBBON_REPORT=/tmp/avoid009-ribbon01/evidence/ribbon01/native06.json.gz node dev/avoidance/layouts-d-ribbon-native-test.cjs
node evidence/ribbon01/native-search-check.cjs evidence/ribbon01/native05.json.gz
```

Outputs refuse overwrite; use a fresh report name for browser reruns. Search checker now refuses the existing search01 output; use a copied runner with an explicit fresh name for rerun. Browser requires normal additional network permission for localhost; inherited proxy/CA/TLS unchanged. Browser routes external requests to abort. Each browser run stores source, runner, baseline, built HTML and fixture snapshots before starting. No test expectation was weakened to accept the transport mismatch.

The tree is97MB; avoid multiplying full input snapshots. Source/raw parent review is the next gate before spatial candidate implementation or larger tests.
