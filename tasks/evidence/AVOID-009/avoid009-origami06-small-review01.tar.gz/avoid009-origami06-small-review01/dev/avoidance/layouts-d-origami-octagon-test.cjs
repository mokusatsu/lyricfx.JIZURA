'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),crypto=require('node:crypto'),zlib=require('node:zlib');
const root=path.resolve(__dirname,'../..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const target=process.env.JIZURA_D_ORIGAMI_REPORT||'/tmp/avoid009-origami01.json.gz';assert(!fs.existsSync(target));
 const files=['src/09a_placement.js','src/09g_layoutsC_placement.js','src/09k_layoutsD_placement.js','src/09n_layoutsD_origami.js','src/11p_layoutsD.js','src/11za_layoutsD_transport.js','index.html','en/index.html','dev/avoidance/layouts-a-fixture.js',path.relative(root,__filename)],pins=files.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(root,p)))}));
 const snap=target+'.inputs';fs.mkdirSync(snap);for(const file of files)fs.writeFileSync(path.join(snap,file.replaceAll('/','__')+'.gz'),zlib.gzipSync(fs.readFileSync(path.join(root,file)),{mtime:0}));
 const font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',server=http.createServer((q,r)=>{try{r.end(fs.readFileSync(q.url==='/font.otf'?font:path.join(root,q.url==='/'?'index.html':q.url)));}catch{r.writeHead(404).end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;let browser;
 try{
 browser=await require('../browser.cjs').launch();const page=await browser.newPage(),warnings=[];page.on('console',m=>{if(m.type()==='warning')warnings.push(m.text());});await page.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());await page.goto(base);await page.waitForFunction(()=>window.J?.ui?.plan);await page.addScriptTag({content:fs.readFileSync(path.join(__dirname,'layouts-a-fixture.js'),'utf8')});
 const result=await page.evaluate(async()=>{
  const rows=[];
  for(const [W,H]of [[960,540],[540,960],[640,640]])for(const text of ['風','風の先へ','ひらく紙に言葉を残して','Paper folds'])for(const mode of ['gate','blintz'])for(const radius of [.02,.2,.35,.45])for(const [cx,cy]of [[.5,.5],[.5,.42],[.1,.1],[.9,.9]]){
   if(mode==='gate'&&H<=W*1.08)continue;
   const spec={layout:'origami',W,H,cx,cy,radius,text,params:{mode,order:2}},r=await runLayoutsAFixture(J,spec,{newPath:false,fontURL:location.origin+'/font.otf'}),fps=(r.plan.fps=60),source=JSON.stringify(r.plan),final=J.finalizePlacementPlan(r.plan,{layoutsD:true}),cut=final.cuts[0],tr=cut.placementTrajectory,observations=[],errors=[];
   for(const time of [.01,.12,.45,.5,1,1.5,2.5,3.5,3.99])try{r.renderer.frame(r.canvas.getContext('2d'),final,time,{noHud:true,noPost:true,placementObservation:o=>observations.push(o)});}catch(e){errors.push({time,code:e.code,message:e.message});}
   const fromOther=J.finalizePlacementPlan(J.finalizePlacementPlan(r.plan,{layoutsA:true}),{layoutsD:true}),legacy=J.finalizePlacementPlan(final,{}),freshLegacy=J.finalizePlacementPlan(r.plan,{});
   rows.push({spec,sourceUnchanged:source===JSON.stringify(r.plan),diagnostics:final.placementFinalization.diagnostics,tr,observations,errors,idempotent:J.finalizePlacementPlan(final,{layoutsD:true})===final,fromOtherEqual:JSON.stringify(final)===JSON.stringify(fromOther),legacyEqual:JSON.stringify(legacy)===JSON.stringify(freshLegacy),internalClean:!legacy.cuts[0].placementLayoutsD&&!legacy.cuts[0].layoutDRecipe});
  }
  return {rows,scope:'Continuous source algebra + live event containment/circle/stage guards, sampled8native clocks each; no visual claim. Raster alpha and visual review are separate pending checks.'};
 });
 for(const pin of pins)assert.equal(sha(fs.readFileSync(path.join(root,pin.path))),pin.sha256);const receipt={...result,pins,browser:browser.version(),warnings,font:{path:font,sha256:sha(fs.readFileSync(font)),scope:'Pinned single-face functional render only; full font repertoire/cmap not certified'}};fs.writeFileSync(target,zlib.gzipSync(JSON.stringify(receipt),{mtime:0}));const failures=result.rows.filter(r=>!r.sourceUnchanged||r.errors.length||!r.tr||!r.idempotent||!r.fromOtherEqual||!r.legacyEqual||!r.internalClean);console.log(JSON.stringify({rows:result.rows.length,failures:failures.map(r=>({spec:r.spec,diagnostics:r.diagnostics,errors:r.errors})),states:result.rows.reduce((a,r)=>(a[r.tr?.safety||'unsupported']=(a[r.tr?.safety||'unsupported']||0)+1,a),{}),warnings,report:target}));assert.equal(failures.length,0);
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{const target=process.env.JIZURA_D_ORIGAMI_REPORT||'/tmp/avoid009-origami01.json.gz';fs.writeFileSync(target+'.failure.json',JSON.stringify({name:e.name,message:e.message,stack:e.stack},null,2)+'\n');console.error(e);process.exitCode=1;});
