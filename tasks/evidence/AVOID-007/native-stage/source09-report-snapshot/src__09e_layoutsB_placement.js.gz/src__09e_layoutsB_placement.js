/* AVOID-007 B25: explicit opt-in source-native adapters. Product default stays off. */
(() => {
'use strict';
const A=J.placement;
A.layoutsB25=['rain','hanging','tunnel','wordCloud','bounceLine','elastic','crossBands','stickerBomb','neon','keycaps','bubbles','slotMachine','flipBoard','credits','zoomRepeat','splitHalves','columnsBig','dotMatrix','depthStack','typeSpecimen','kanjiFocus','halfVertical','curtain','equalizer','tape'];
const fail=(code,message)=>{const e=new Error(message);e.code=code;throw e;},rect=(x0,y0,x1,y1)=>[[x0,y0],[x1,y0],[x1,y1],[x0,y1]],flat=t=>[...String(t||'').replace(/\s/g,'')];
function record(renderer,plan,cut,time,extra={}){
 const ctx=A.measurementContext();ctx.reset();const env=renderer.makeEnv(ctx,plan,cut,cut.palette||plan.style.schemes[cut.scheme%plan.style.schemes.length],{pass:'main',t:time,realTime:time,lt:time-cut.start,ltb:time-cut.start,step:Math.floor(time*24),scale:1,allowFilter:false,...extra});
 const program=A.record(renderer,env);if(!program.measurementSupported)fail('UNSUPPORTED_MEASUREMENT',JSON.stringify(program.diagnostics));return program;
}
function envelope(program,plan,cut){
 const id=cut.layout,events=program.events.filter(e=>e.role==='primary'),polygons=events.flatMap(e=>e.polygons);if(!polygons.length)fail('UNSUPPORTED_MEASUREMENT','Empty B primary program');
 if(!['tunnel','wordCloud','crossBands','neon','zoomRepeat','curtain'].includes(id))fail('B_INTERVAL_ADAPTER_PENDING','Source interval adapter not yet implemented: '+id);
 return events.flatMap(e=>e.polygons.map(p=>{
  // The native central sign/outline/main item is static under cut/still.
  // Cross plate outBack(1.6) has its unique extremum <1.1; both exit
  // multipliers are <=1. This dilation includes its owned shadow/border.
  if(id==='crossBands'&&e.kind!=='item')p=A.layoutsASweep(p,{pivot:[plan.W/2,plan.H/2],scale:[1,1.1]});
  // Theatre slate is drawn only after open>.9. Native yt then lies
  // between rest and rest+.1*(H/2-rest); y=yt/2. Main lyric is static.
  if(id==='curtain'&&e.kind==='item'&&!e.args[0].placementMain){const b=A.bounds([p]);p=rect(b.x0,b.y0-plan.H*.025,b.x1,b.y1+plan.H*.025);}
  return A.cameraEnvelope([p],plan,cut,e.kind==='item'?20:10);
 }));
}
A.layoutsBNativeEnvelopes=envelope;
A.finalizeLayoutsB=(plan,cut,original,diagnostics,{revision,stepDur,reachTail,explicitSize=false})=>{
 const evaluationRange=[Math.min(cut.start,cut.renderStart??cut.start)-stepDur,Math.max(cut.end,cut.displayEnd??cut.end)+reachTail];
 try{
  if(cut.treat!=='none')fail('UNSUPPORTED_ADAPTER','B treatment needs an owned interval adapter');
  const finite=v=>typeof v==='number'?Number.isFinite(v):!v||typeof v!=='object'||Object.values(v).every(finite);if(!finite(cut.params))fail('UNSUPPORTED_PARAMETER_RANGE','Nonfinite B native parameter');
  cut.placementUnits=true;cut.placementLayoutsB=true;const renderer=Object.create(J.Renderer.prototype),program=record(renderer,plan,cut,cut.start+Math.min(1.5,cut.dur*.5));
  const envelopes=envelope(program,plan,cut),segments=[],owner=cut.layout+'.composition';
  for(let i=0;i<plan.lyricAvoidanceIndex.regions.length;i++){
   const r=plan.lyricAvoidanceIndex.regions[i],end=Math.min(r.end??plan.lyricAvoidanceIndex.regions[i+1]?.start??plan.duration,plan.duration);if(r.start>=evaluationRange[1])break;if(end<=evaluationRange[0]||end<=r.start)continue;
   const circle={cx:r.center.x*plan.W,cy:r.center.y*plan.H,r:r.radius*Math.min(plan.W,plan.H)},solution=A.solveBasic(envelopes,circle,plan.W,plan.H,J.h(cut.seed,581),{supportHull:true});
   segments.push({start:r.start,end,region:r.id,from:solution.offset,to:solution.offset,status:solution.status,decision:solution.status==='safe'?'certified':'excluded-during-avoidance',failure:solution.status==='safe'?null:'no-certified-composition',attempts:[{strategy:'native-joint-translation',status:solution.status}],proof:{kind:'source-static-sign-with-declared-owned-motion-envelope',clock:'native clocks, complete interval; camera and AA included'}});
  }
  cut.placementTrajectory={version:1,kind:'layouts-b-source-native',revision,evaluationRange,units:[{owner,envelopes,segments}],measurementSupported:true,safety:segments.every(s=>s.status==='safe')?'certified-bounded-adapter':'insufficient-space',explicitSizePreserved:explicitSize};
  diagnostics.push({cut:cut.index,code:'STAGED_ADAPTER',measurement:'supported',safety:cut.placementTrajectory.safety});
 }catch(e){plan.cuts[plan.cuts.indexOf(cut)]=original;diagnostics.push({cut:cut.index,code:e.code||'DRAW_PROGRAM_ERROR',details:e.message,safety:'unsupported'});}
};
A.renderLayoutsB=(renderer,env)=>{
 A.validateFinal(env.plan);const scale=env.scale||1;if(scale<.1||scale>4)fail('UNSUPPORTED_RENDER_SCALE','B certified scale range .1..4');const tr=env.cut.placementTrajectory,unit=tr.units[0],active=unit.segments.find(s=>s.start<=env.realTime&&env.realTime<s.end),offset=A.offsetAt(unit,env.realTime),program=A.record(renderer,env);if(!program.measurementSupported)fail('UNSUPPORTED_DRAW_PROGRAM',JSON.stringify(program.diagnostics));
 const inside=(p,poly)=>{let pos=false,neg=false;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],v=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);if(v>1e-5)pos=true;if(v< -1e-5)neg=true;}return !(pos&&neg);},local=program.events.filter(e=>e.role==='primary').flatMap(e=>e.polygons).map(p=>p.map(v=>v.map(n=>n/scale))),covered=local.every(p=>unit.envelopes.some(q=>p.every(v=>inside(v,q))));if(!covered)fail('ENVELOPE_VIOLATION','B native primary escaped complete interval envelope');
 const polygons=local.map(p=>p.map(v=>[v[0]+offset[0],v[1]+offset[1]])),region=J.resolveAvoidanceAt(env.plan,env.realTime),circle=region?J.avoidanceCirclePixels(region,env.plan.W,env.plan.H):null,clear=!polygons.length||A.clear(polygons,circle,Math.max(2,.005*Math.min(env.plan.W,env.plan.H)));
 env.placementObservation?.({cut:env.cut.index,realTime:env.realTime,motionTime:env.t,pass:env.pass,offset:{[unit.owner]:offset},measurementSupported:true,envelopeCovered:covered,safety:(!active||active.status==='safe')&&clear?'safe':'conflict',polygons,events:program.events.map(e=>({kind:e.kind,role:e.role,owner:e.owner,order:e.order,polygons:e.polygons}))});A.replay(env,program,offset);
};
})();
