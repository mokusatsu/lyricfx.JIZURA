/* Synthetic metadata only. No real Sites URL, publication or MP4 capture. */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const cp = require('node:child_process');
const T = require('./layouts-b-pages-bridge.cjs');
const auditPath = path.join(__dirname, 'pages-output-audit.py');
const startup = [__filename, require.resolve('./layouts-b-pages-bridge.cjs'), auditPath]
  .map(file => ({file, sha256: T.sha(fs.readFileSync(file))}));
process.stdout.write('# bridge startup pins ' + T.json(startup.map(p => ({name: path.basename(p.file), sha256: p.sha256}))));
const h = character => character.repeat(64);

function inputs() {
  const cases = T.LAYOUTS.map(layout => ({id: 'synthetic-' + layout, layout,
    stage: {W: 1920, H: 1080}, circle: {cx: .5, cy: .42, radius: .2}, aspect: '16:9',
    hids: layout === 'rain' ? T.HIDS.slice() : [T.HIDS[0]]}));
  const native = {schema: 'avoid007-native-v1', taskID: 'AVOID-007', baseline: T.BASE,
    assets: {'sources/before/index.html': h('a'), 'sources/after/index.html': h('b'),
      'sources/after/en/index.html': h('c')},
    cases: cases.map(c => ({id: c.id, hids: c.hids,
      conditions: {layout: c.layout, W: c.stage.W, H: c.stage.H, cx: c.circle.cx,
        cy: c.circle.cy, radius: c.circle.radius}}))};
  const nativeManifestBytes = Buffer.from(T.json(native));
  const config = {buildID: 'synthetic-bridge',
    sites: {comparisonURL: 'https://example.test/review/AVOID-007/synthetic-native/index.html',
      englishComparisonURL: 'https://example.test/review/AVOID-007/synthetic-native/en.html',
      manifestURL: 'https://example.test/review/AVOID-007/synthetic-native/manifest.json',
      manifestSHA256: T.sha(nativeManifestBytes), audience: 'owner-private'},
    implementations: {before: {commit: T.BASE, htmlSHA256: h('a')}, after: {htmlSHA256: h('b')}},
    product: {jaSHA256: h('b'), enSHA256: h('c')}, cases};
  return {config, nativeManifestBytes};
}
function temp(fn) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'avoid007-bridge-unit-'));
  try { return fn(root); } finally { fs.rmSync(root, {recursive: true, force: true}); }
}

test('bridge metadata fixes all 25 IDs, conditions, H anchors and source hashes', () => {
  const {config, nativeManifestBytes} = inputs();
  assert.equal(T.verifyNativeReference(config, nativeManifestBytes).cases.length, 25);
  for (const mutate of [
    c => { c.cases.pop(); },
    c => { c.cases[0].layout = 'orbit'; },
    c => { c.cases[1].id = c.cases[0].id; },
    c => { c.cases[0].hids = [T.HIDS[0]]; },
    c => { c.cases[0].aspect = '4:3'; },
    c => { c.cases[0].circle.radius = .5; },
    c => { c.product.jaSHA256 = h('d'); },
    c => { c.sites.audience = 'public'; },
    c => { c.token = 'secret-sentinel'; },
  ]) {
    const changed = structuredClone(config);
    mutate(changed);
    assert.throws(() => T.normalizeConfig(changed));
  }
  const changed = structuredClone(config);
  changed.cases[0].circle.cy = .5;
  assert.throws(() => T.verifyNativeReference(changed, nativeManifestBytes), /conditions match/);
  changed.cases[0].circle.cy = .42;
  changed.product.enSHA256 = h('d');
  assert.throws(() => T.verifyNativeReference(changed, nativeManifestBytes));
  assert.throws(() => T.verifyNativeReference(config, Buffer.concat([nativeManifestBytes, Buffer.from(' ')])), /raw hash/);
});

test('canonical HTTPS input rejects secrets, query, traversal and external English destination', () => {
  for (const value of ['http://example.test/x', 'https://u:p@example.test/x',
    'https://example.test/x?token=secret', 'https://example.test/x#token',
    'https://example.test/a/../x', 'https://example.test/%2e%2e/x', 'https://example.test/a//x',
    'https://example.test/x\r\n', 'https://example.test\\x']) assert.throws(() => T.url(value));
  const {config} = inputs();
  config.sites.englishComparisonURL = 'https://other.test/en.html';
  assert.throws(() => T.normalizeConfig(config));
  assert.equal(T.esc('<a href="x&y">\''), '&lt;a href=&quot;x&amp;y&quot;&gt;&#39;');
});

test('four-file immutable bridge has local audit closure, bilingual anchors and direct case links', () => temp(root => {
  const {config, nativeManifestBytes} = inputs();
  const dir = path.join(root, 'bridge');
  const receipt = T.generate(config, dir, {nativeManifestBytes});
  assert.ok(receipt.bytes < 128 * 1024);
  assert.deepEqual(fs.readdirSync(dir).sort(), ['en.html', 'index.html', 'manifest.json', 'sites-pointer.json']);
  const checked = T.validate(dir, {expectedConfig: config, nativeManifestBytes});
  assert.equal(checked.manifestSHA256, receipt.manifestSHA256);
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json')));
  assert.deepEqual(Object.keys(manifest.assets).sort(), T.ASSETS.slice().sort());
  assert.equal(manifest.remoteReference.manifestSHA256, T.sha(nativeManifestBytes));
  assert.equal(manifest.assets['manifest.json'], undefined);
  for (const [filename, english] of [['index.html', false], ['en.html', true]]) {
    const html = fs.readFileSync(path.join(dir, filename), 'utf8');
    assert.ok(html.includes(english ? 'Open before / after MP4s' : '変更前後のMP4を開く'));
    assert.ok(html.includes(english ? 'href="index.html"' : 'href="en.html"'));
    assert.ok(html.includes(T.PRODUCT));
    for (const hid of T.HIDS) {
      assert.ok(html.includes(`id="${hid}"`));
      assert.ok(html.includes(`#${hid}`));
    }
    for (const c of config.cases) assert.ok(html.includes((english ? config.sites.englishComparisonURL : config.sites.comparisonURL) + '#' + c.id));
    assert.ok(!/<(?:script|iframe|video|meta[^>]+http-equiv)/i.test(html), 'small link page, no media, JS or redirect');
    assert.ok(!html.includes('htmlSHA256'), 'technical implementation details stay in manifest');
  }
  assert.throws(() => T.generate(config, dir, {nativeManifestBytes}), /fresh immutable/);
}));

test('missing, tampered, rehashed, extra and symlink assets and changed conditions are rejected', () => temp(root => {
  const {config, nativeManifestBytes} = inputs();
  const dir = path.join(root, 'bridge');
  T.generate(config, dir, {nativeManifestBytes});
  const asset = path.join(dir, 'sites-pointer.json');
  const original = fs.readFileSync(asset);
  const manifestFile = path.join(dir, 'manifest.json');
  const manifest = fs.readFileSync(manifestFile);
  fs.unlinkSync(asset);
  assert.throws(() => T.validate(dir));
  fs.writeFileSync(asset, Buffer.concat([original, Buffer.from(' ')]));
  assert.throws(() => T.validate(dir), /raw bridge asset hash/);
  const rehashed = JSON.parse(manifest);
  rehashed.assets['sites-pointer.json'] = T.sha(fs.readFileSync(asset));
  fs.writeFileSync(manifestFile, T.json(rehashed));
  assert.throws(() => T.validate(dir), /generated bridge bytes/);
  fs.writeFileSync(manifestFile, manifest);
  fs.writeFileSync(asset, original);
  const extra = path.join(dir, 'unexpected.mp4');
  fs.writeFileSync(extra, 'not a real movie');
  assert.throws(() => T.validate(dir), /closure/);
  fs.unlinkSync(extra);
  const target = path.join(root, 'outside.json');
  fs.writeFileSync(target, original);
  fs.unlinkSync(asset);
  fs.symlinkSync(target, asset);
  assert.throws(() => T.validate(dir), /symlink/);
  fs.unlinkSync(asset);
  fs.writeFileSync(asset, original);
  const changed = structuredClone(config);
  changed.cases[0].circle.cy = .5;
  assert.throws(() => T.validate(dir, {expectedConfig: changed}), /external input/);
}));

test('Sites hub is relative, leaves old deep URLs intact and never overwrites a root', () => temp(root => {
  const old = path.join(root, 'review/AVOID-007/old/index.html');
  fs.mkdirSync(path.dirname(old), {recursive: true});
  fs.writeFileSync(old, 'immutable old bytes');
  const before = T.sha(fs.readFileSync(old));
  const receipt = T.generateSitesHub('review/AVOID-007/synthetic-native', root);
  const hub = fs.readFileSync(receipt.path, 'utf8');
  assert.ok(hub.includes('href="review/AVOID-007/synthetic-native/index.html"'));
  assert.ok(hub.includes('href="review/AVOID-007/synthetic-native/en.html"'));
  assert.ok(!hub.includes('http') && !hub.includes('manifest.json'));
  assert.equal(T.sha(fs.readFileSync(old)), before);
  assert.throws(() => T.generateSitesHub('review/AVOID-007/another', root), /not be overwritten/);
  for (const bad of ['../native', '/review/AVOID-007/x', 'https://example.test/x',
    'review/AVOID-007/x?token=a', 'review/AVOID-007/x/index.html']) assert.throws(() => T.sitesHubHTML(bad));
}));

test('unchanged Pages audit accepts bridge schema and still rejects changed old public bytes', () => temp(root => {
  const {config, nativeManifestBytes} = inputs();
  const candidate = 'review/AVOID-007/synthetic-bridge';
  const source = path.join(root, 'source');
  const output = path.join(root, 'output');
  const dir = path.join(source, candidate);
  T.generate(config, dir, {nativeManifestBytes});
  const script = `
import importlib.util,json,hashlib,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('audit',sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=Path(sys.argv[2]);src=root/'source';out=root/'output';candidate='review/AVOID-007/synthetic-bridge'
def put(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
put(src/'_config.yml',b'synthetic: true\\n')
for name in m.MUTABLE|m.DOWNLOADS:put(src/name,('synthetic '+name).encode())
old='review/AVOID-006/synthetic-old/asset.bin';put(src/old,b'old immutable asset')
oldmanifest='review/AVOID-006/synthetic-old/manifest.json';put(src/oldmanifest,json.dumps({'assets':{'asset.bin':hashlib.sha256((src/old).read_bytes()).hexdigest()}}).encode())
legacy={p.relative_to(src).as_posix():m.fingerprint(p)['gitBlob'] for p in src.rglob('*') if p.is_file() and not p.relative_to(src).as_posix().startswith(candidate) and p.name!='_config.yml'}
def projection():return {'inventory':[{'url':p.relative_to(src).as_posix(),**{k:v for k,v in m.fingerprint(p).items() if k in ('bytes','sha256')}} for p in src.rglob('*') if p.is_file() and p.name!='_config.yml']}
def copy():
 for p in src.rglob('*'):
  if p.is_file() and p.name!='_config.yml':put(out/p.relative_to(src),p.read_bytes())
copy();result=m.audit(src,out,projection(),legacy,candidate)
assert result['passed'] and result['manifestCount']==2 and result['siteBytes']<131072
put(src/old,b'changed immutable asset');copy()
try:m.audit(src,out,projection(),legacy,candidate)
except ValueError as e:assert 'Old public bytes changed' in str(e)
else:raise AssertionError('legacy byte mutation accepted')
print(json.dumps({'syntheticAudit':True,'manifestCount':result['manifestCount'],'siteBytes':result['siteBytes'],'legacyMutationRejected':True}))
`;
  const result = cp.spawnSync('python3', ['-c', script, auditPath, root], {
    encoding: 'utf8', env: {...process.env, PYTHONDONTWRITEBYTECODE: '1'}, maxBuffer: 1024 * 1024,
  });
  assert.equal(result.status, 0, result.stderr);
  const receipt = JSON.parse(result.stdout);
  assert.equal(receipt.legacyMutationRejected, true);
  process.stdout.write('# synthetic unchanged Pages audit ' + T.json(receipt));
}));

test('CLI rejected credentials are not echoed; startup source and audit bytes stay unchanged', () => temp(root => {
  const {config} = inputs();
  config.sites.comparisonURL = 'https://credential-sentinel:token-sentinel@example.test/index.html';
  const file = path.join(root, 'bad-config.json');
  fs.writeFileSync(file, T.json(config));
  const result = cp.spawnSync(process.execPath,
    [require.resolve('./layouts-b-pages-bridge.cjs'), 'generate', file, path.join(root, 'out'), file], {encoding: 'utf8'});
  assert.notEqual(result.status, 0);
  assert.ok(!result.stderr.includes('sentinel') && !result.stdout.includes('sentinel'));
  for (const pin of startup) assert.equal(T.sha(fs.readFileSync(pin.file)), pin.sha256);
  process.stdout.write('# bridge tool receipt ' + T.json({scope: 'synthetic metadata/local audit only; no real Sites generation or publication',
    inputs: startup.map(p => ({name: path.basename(p.file), sha256: p.sha256})), endInputsUnchanged: true}));
}));
