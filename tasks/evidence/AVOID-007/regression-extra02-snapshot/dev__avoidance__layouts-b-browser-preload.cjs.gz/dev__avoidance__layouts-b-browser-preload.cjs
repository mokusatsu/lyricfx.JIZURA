/* Adapt existing Windows-only launch location; keep suite assertions unchanged. */
const {chromium}=require('../node_modules/playwright');
const launch=chromium.launch.bind(chromium);
chromium.launch=options=>launch({...options,executablePath:process.env.JIZURA_BROWSER||'/usr/bin/chromium'});
