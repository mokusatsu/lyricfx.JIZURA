/* Adapt existing Windows-only launch location; keep suite assertions unchanged. */
const {chromium}=require('playwright');
const launch=chromium.launch.bind(chromium);
chromium.launch=options=>launch({...options,executablePath:process.env.JIZURA_BROWSER||'/usr/bin/chromium'});
// Optional immutable e96 control: substitute only the two compiled product reads.
if(process.env.JIZURA_REGRESSION_ROOT){const fs=require('node:fs'),path=require('node:path'),root=path.resolve(__dirname,'../..'),read=fs.readFileSync;fs.readFileSync=function(file,...args){const name=typeof file==='string'?path.resolve(file):null;if(name===path.join(root,'index.html')||name===path.join(root,'en/index.html'))file=path.join(process.env.JIZURA_REGRESSION_ROOT,path.relative(root,name));return read.call(this,file,...args);};}
