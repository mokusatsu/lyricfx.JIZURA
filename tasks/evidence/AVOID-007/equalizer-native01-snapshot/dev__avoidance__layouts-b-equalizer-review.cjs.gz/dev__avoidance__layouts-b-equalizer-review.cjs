/* Equalizer-only local native capture. No public URL or public verification API. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),H=require('./layouts-b-test-harness.cjs'),T=require('./layouts-b-review.cjs');
(async()=>{
 const buildID='equalizer-row-20261022-01',dir=path.join(H.root,'work/avoid007-equalizer',buildID),receipt=path.join(H.root,'tasks/evidence/AVOID-007/equalizer-native01.json'),old=path.join(H.root,'work/avoid007-native/local-20261022-02'),oldRaw=fs.readFileSync(path.join(old,'manifest.json')),oldManifest=JSON.parse(oldRaw),oldCase=oldManifest.cases.find(c=>c.conditions.layout==='equalizer'),options=JSON.parse(fs.readFileSync(path.join(old,'config.json'))).fixtureOptions;
 assert.ok(!fs.existsSync(dir),'fresh immutable local output');
 const extras=['AGENTS.md','dev/avoidance/layouts-b-review.cjs','tasks/evidence/AVOID-007/equalizer-row02.json',...['manifest.json','config.json','fixtures/before-engine.html','fixtures/fixture.js',oldCase.before.frames,...options.fonts.faces.map(f=>f.url)].map(p=>path.relative(H.root,path.join(old,p)))],startup=H.pin(receipt,__filename,extras);
 const manifest={schema:'AVOID-007-equalizer-native-review-v1',buildID,scope:'Equalizer only: preserve native row count and a coherent meter. Local numeric success is not independent visual acceptance. No public verification.',capture:{fps:24,frames:96,duration:4,stage:[1920,1080],keys:T.KEYS,method:'Canvas native PNG frames directly piped to ffmpeg H264; animation only'},originalManifestSHA256:H.sha(oldRaw),baseline:'Exact e96 native full-stage engine; circle avoidance absent. After uses the new equalizer adapter, otherwise identical text/seed/fonts/clock/stage.',conditions:oldCase.conditions,fixtureOptions:options,source:{pins:startup.pins.filter(p=>p.file.startsWith('src/')||['index.html','en/index.html'].includes(p.file))},assets:{},sides:{},status:'local capture pending independent review'};
 const add=(p,b)=>{fs.mkdirSync(path.dirname(path.join(dir,p)),{recursive:true});fs.writeFileSync(path.join(dir,p),b);manifest.assets[p]={sha256:H.sha(b),bytes:b.length};};
 add('fixtures/before-engine.html',fs.readFileSync(path.join(old,'fixtures/before-engine.html')));add('fixtures/after-engine.html',T.normalize(fs.readFileSync(path.join(H.root,'index.html'))));add('fixtures/fixture.js',fs.readFileSync(path.join(old,'fixtures/fixture.js')));
 for(const f of options.fonts.faces)add(f.url,fs.readFileSync(path.join(old,f.url)));
 add('provenance/original-manifest.json',oldRaw);add('provenance/numeric-row02.json',fs.readFileSync(path.join(H.root,'tasks/evidence/AVOID-007/equalizer-row02.json')));add('provenance/startup.json',Buffer.from(JSON.stringify(startup)));
 const local=await T.serve(dir),browser=await require('../browser.cjs').launch();let failure;
 try{
 manifest.browser=browser.version();
 for(const side of ['before','after']){
 const {page,init}=await T.fixturePage(browser,local.baseURL,oldCase,side,options);try{
 if(side==='after')T.safeInitial(init);
 const recipe=init.plan.cuts[0].placementTrajectory?.units[0]?.segments[0]?.composition;
 if(side==='after'){assert.equal(recipe.equalizerRows,1);assert.equal(recipe.equalizerPer,4);assert.match(recipe.strategy,/equalizer-native-row-meter/);}
 add(`observations/${side}-initial.json`,Buffer.from(JSON.stringify(init)));
 fs.mkdirSync(path.join(dir,'videos'),{recursive:true});
 const video=`videos/equalizer-${side}.mp4`,encoded=await T.encodeFrames(path.join(dir,video),1920,1080,async n=>{const f=await T.render(page,n);if(side==='after')T.safeObservations(f.observations);return f;},(n,png)=>add(`images/equalizer-${side}-${n}.png`,png));
 manifest.assets[video]={sha256:H.sha(fs.readFileSync(path.join(dir,video))),bytes:fs.statSync(path.join(dir,video)).size};
 if(side==='before'){const expected=JSON.parse(fs.readFileSync(path.join(old,oldCase.before.frames)));assert.equal(encoded.frames.length,expected.length);encoded.frames.forEach((f,i)=>{assert.equal(f.sha256,expected[i].sha256,'e96 original native PNG '+i);assert.equal(f.rgbaSHA256,expected[i].rgbaSHA256,'e96 original RGBA '+i);});manifest.beforeOriginal96Exact=true;}
 add(`observations/${side}-frames.json`,Buffer.from(JSON.stringify(encoded.frames)));
 manifest.sides[side]={video,initial:`observations/${side}-initial.json`,frames:`observations/${side}-frames.json`,probe:encoded.probe,encoderArgs:encoded.encoderArgs,recipe,codecQuality:T.codecQuality(path.join(dir,video),T.KEYS.map(frame=>({frame,file:path.join(dir,`images/equalizer-${side}-${frame}.png`)}))),keys:T.KEYS.map(n=>`images/equalizer-${side}-${n}.png`)};
 console.log(JSON.stringify({side,frames:encoded.frames.length,video,recipe}));
 }finally{await page.close();}}
 H.verify(startup);manifest.endInputsUnchanged=true;
 for(const en of [false,true]){
 const label=en?['Equalizer: one coherent level meter','Before: original full-stage effect','After: avoidance with native row count','Both videos use the same 1920×1080 stage, text, seed, eight font assets and 0–4s clock. The original one-row example remains one row. The meter height is bounded and font size is 80% of native; signal timing and frequency order are retained.','Independent visual review pending.']:['イコライザー：単一のレベルメーターを維持','変更前：元の全画面演出','変更後：元の行数を保って回避','両動画は同じ1920×1080、歌詞、seed、8字体、0〜4秒です。元の1行例は1行のまま、棒の高さを調整し、文字サイズは元の80%です。信号の時計と周波数順を保ちます。','独立した視覚レビュー待ちです。'];
 add(en?'en.html':'index.html',Buffer.from(`<!doctype html><html lang="${en?'en':'ja'}"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${label[0]}</title><style>body{background:#171923;color:#eee;font:16px system-ui;margin:24px}main{max-width:1500px;margin:auto}.pair{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:20px}video,img{width:100%;height:auto}figure{margin:0}p{line-height:1.6}.keys{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}</style><main><nav><a href="${en?'index.html':'en.html'}">${en?'日本語':'English'}</a> · <a href="manifest.json">manifest</a></nav><h1>${label[0]}</h1><p>${label[3]}</p><p>${label[4]}</p><div class="pair">${['before','after'].map((s,i)=>`<section><h2>${label[i+1]}</h2><video controls playsinline preload="metadata" src="${manifest.sides[s].video}"></video><div class="keys">${manifest.sides[s].keys.map(p=>`<a href="${p}"><img loading="lazy" src="${p}"></a>`).join('')}</div></section>`).join('')}</div></main></html>`));}
 manifest.status='native capture and local file/codec qualification passed; independent visual review pending';
 fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(manifest,null,2));
 // Local-only closure/raw-byte and codec checks. No browser playback or network/public APIs.
 for(const [p,a] of Object.entries(manifest.assets)){const b=fs.readFileSync(path.join(dir,p));assert.equal(H.sha(b),a.sha256);assert.equal(b.length,a.bytes);}
 }catch(e){failure=e;throw e;}finally{await browser.close();await local.close();H.verify(startup);const files=Object.entries(manifest.assets).map(([file,a])=>({file,...a}));fs.writeFileSync(receipt,JSON.stringify({startup,dir:path.relative(H.root,dir),manifestSHA256:fs.existsSync(path.join(dir,'manifest.json'))?H.sha(fs.readFileSync(path.join(dir,'manifest.json'))):null,status:failure?'failed':manifest.status,error:failure?.stack,files,bytes:files.reduce((n,f)=>n+f.bytes,0),endInputsUnchanged:true},null,2));}
 console.log(JSON.stringify({dir,manifestSHA256:H.sha(fs.readFileSync(path.join(dir,'manifest.json'))),assets:Object.keys(manifest.assets).length,bytes:Object.values(manifest.assets).reduce((n,a)=>n+a.bytes,0)}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
