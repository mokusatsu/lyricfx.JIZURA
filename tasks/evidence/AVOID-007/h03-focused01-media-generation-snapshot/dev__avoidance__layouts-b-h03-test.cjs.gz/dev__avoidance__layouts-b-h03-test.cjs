/* H03 focused diagnostic, actual retained scene + two decoded video layers. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict'),{once}=require('node:events'),H=require('./layouts-b-test-harness.cjs'),T=require('./layouts-b-review.cjs');
const bundle=path.join(H.root,'work/avoid007-native/local-20261022-01'),output=path.join(H.root,process.env.JIZURA_H03_WORK||'work/avoid007-h03/diagnostic01'),receipt=path.join(H.root,process.env.JIZURA_H03_REPORT||'tasks/evidence/AVOID-007/h03-focused01.json'),fixture=path.join(__dirname,'layouts-b-h03-fixture.js'),relative=p=>path.relative(H.root,p);
const digest=p=>H.sha(fs.readFileSync(p));
async function generateMedia(){
 assert.ok(!fs.existsSync(output),'fresh media directory');fs.mkdirSync(output,{recursive:true});
 const start=H.pin(receipt.replace('.json','-media-generation.json'),__filename,[relative(fixture),'dev/avoidance/layouts-b-review.cjs']);
 const browser=await require('../browser.cjs').launch(),records=[];
 try{const page=await browser.newPage();await page.goto('about:blank');
  for(let side=0;side<2;side++){
   const file=path.join(output,side?'foreground.mp4':'background.mp4'),args=['-v','error','-y','-threads','1','-f','image2pipe','-framerate','24','-i','pipe:0','-an','-c:v','libx264','-threads','1','-preset','veryfast','-crf','12','-pix_fmt','yuv420p','-movflags','+faststart',file],proc=cp.spawn('ffmpeg',args,{stdio:['pipe','ignore','pipe']});let stderr='';proc.stderr.on('data',b=>stderr+=b);const frames=[];
   for(let n=0;n<288;n++){const data=await page.evaluate(({side,n})=>{const c=document.createElement('canvas');c.width=640;c.height=360;const x=c.getContext('2d');x.fillStyle=side?'#10466b':'#48321c';x.fillRect(0,0,640,360);x.fillStyle=side?'#ef649c':'#52cca2';x.fillRect(20+(n*3)%500,55,100,90);x.fillStyle='#f6f2da';x.fillRect(25,260,30+n%240,32);x.strokeStyle='#ffffff';x.lineWidth=8;x.strokeRect(4,4,632,352);x.font='28px monospace';x.fillText((side?'FOREGROUND ':'BACKGROUND ')+(n/24).toFixed(3),20,40);return c.toDataURL('image/png');},{side,n}),b=Buffer.from(data.split(',')[1],'base64');frames.push({frame:n,time:n/24,sha256:H.sha(b)});if(!proc.stdin.write(b))await once(proc.stdin,'drain');}
   proc.stdin.end();const [code]=await once(proc,'close');assert.equal(code,0,stderr);records.push({layer:side?'foreground':'media',file:relative(file),bytes:fs.statSync(file).size,sha256:digest(file),frames,encoderArgs:args});
  }
 }finally{await browser.close();}
 H.verify(start);fs.writeFileSync(receipt.replace('.json','-media-generation.json'),JSON.stringify({startup:start,records}));return records;
}
(async()=>{
 const media=await generateMedia(),m=JSON.parse(fs.readFileSync(path.join(bundle,'manifest.json'))),config=JSON.parse(fs.readFileSync(path.join(bundle,'config.json')));
 assert.equal(digest(path.join(bundle,'manifest.json')),'c0c64e78bbbfc33761e378acd21fd7899cd59353e3a1ac1dcb02e6c9c2a77274');
 const extra=[relative(fixture),'dev/avoidance/layouts-b-review.cjs',...Object.keys(m.assets).filter(p=>p.startsWith('sources/')||p.startsWith('fonts/')||p.startsWith('fixtures/')).map(p=>relative(path.join(bundle,p))),relative(path.join(bundle,'manifest.json')),relative(path.join(bundle,'config.json')),...media.map(x=>x.file)];
 const startup=H.pin(receipt,__filename,extra),server=await T.serve(H.root),browser=await require('../browser.cjs').launch(),result={scope:'H03 supplemental actual retained scene, full-stage native e96 versus B; no claim of all group collisions',mainBundle:{manifestSHA256:digest(path.join(bundle,'manifest.json'))},media,rows:[],negative:[],warnings:[]};
 try{
  for(const spec of [{layout:'rain',camera:'panL'},{layout:'bubbles',camera:'push'},{layout:'credits',camera:'dutch'}]){
   const row={spec,engines:{}};
   for(const side of ['before','after']){
    const page=await browser.newPage();page.on('pageerror',e=>result.warnings.push(e.message));
    try{await T.isolate(page,server.baseURL);await page.goto(new URL(relative(path.join(bundle,'fixtures',side+'-engine.html')),server.baseURL).href);await page.addScriptTag({path:path.join(bundle,'fixtures/fixture.js')});await page.addScriptTag({path:fixture});await page.addScriptTag({content:'window.seekDecodedFrame='+T.seekDecodedFrame.toString()});
     const initial=await page.evaluate(async({spec,fonts,urls,newPath})=>{window.h03=await runLayoutsBH03(J,{...spec,fonts,mediaURLs:urls,newPath});return {rawLifetime:h03.rawLifetime,sourceParams:h03.sourceParams,geometryLifetimeUnchanged:h03.geometryLifetimeUnchanged,retainedCutIndices:h03.retainedCutIndices,fontCoverage:h03.fontCoverage,fontAudit:h03.fonts,cuts:h03.plan.cuts.map(c=>({index:c.index,line:c.line,text:c.text,sourceStart:c.start,end:c.end,dur:c.dur,slotEnd:c.slotEnd,displayEnd:c.displayEnd,params:c.params,sourceParamsUnchanged:JSON.stringify(c.params)===JSON.stringify(h03.sourceParams.find(p=>p.index===c.index).params),safety:c.placementTrajectory?.safety||'unsupported',segments:c.placementTrajectory?.units[0].segments||[]})),diagnostics:h03.plan.placementFinalization?.diagnostics||[],newAPI:!!J.placement?.layoutsB25};},{spec,fonts:T.resolveOptions(config.fixtureOptions,new URL(relative(bundle)+'/',server.baseURL).href).fonts,urls:media.map(x=>new URL(x.file,server.baseURL).href),newPath:side==='after'});
     assert.equal(initial.newAPI,side==='after');const frames=[];for(const time of [.5,3.5,6.5,9.5,6.5,3.5,9.5,.5])frames.push(await page.evaluate(t=>h03.frame(t),time));
     const byTime=new Map();for(const f of frames){if(byTime.has(f.time))assert.equal(f.rgbaSHA256,byTime.get(f.time).rgbaSHA256,'same engine composite seek revisit');else byTime.set(f.time,f);for(const layer of ['media','foreground'])assert.ok(f.layers[layer].pixels>0);for(const v of f.decoded){assert.ok(v.readyState>=2&&!v.seeking);assert.ok(Math.abs(v.currentTime-f.time)<1/24+.001);}}
     for(const layer of ['media','foreground'])assert.ok(new Set(frames.map(f=>f.layers[layer].rgbaSHA256)).size>=4,'actual media time changes');
     const afterSafety=initial.cuts.every(c=>c.safety==='certified-bounded-adapter'&&c.segments.every(s=>s.status==='safe'))?'safe':initial.cuts.some(c=>c.safety==='unsupported')?'unsupported':'insufficient';
     if(side==='after'&&afterSafety==='safe'){assert.ok(frames.every(f=>f.observations.length>0));for(const f of frames)for(const o of f.observations){assert.equal(o.measurementSupported,true);assert.equal(o.envelopeCovered,true);assert.equal(o.safety,'safe');}}
     const negative=await page.evaluate(async()=>{const base=await h03.frame(6.5),changed=await h03.frame(7),cut=J.mediaAt(h03.plan,6.5,'foreground'),cv=document.createElement('canvas');cv.width=3200;cv.height=1080;await h03.frame(6.5);J.drawMediaCut(cv.getContext('2d'),{...cut,placement:{...cut.placement,cx:cut.placement.cx+.05}},6.5);const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',cv.getContext('2d').getImageData(0,0,3200,1080).data))).map(x=>x.toString(16).padStart(2,'0')).join('');return {positionDetected:digest!==base.layers.foreground.rgbaSHA256,timeDetected:['media','foreground'].every(l=>base.layers[l].rgbaSHA256!==changed.layers[l].rgbaSHA256)};});assert.ok(negative.positionDetected&&negative.timeDetected);result.negative.push({spec,side,...negative});row.engines[side]={initial,frames,status:side==='after'?afterSafety:'native-fullstage'};
    }finally{await page.close();}
   }
   assert.deepEqual(row.engines.before.initial.rawLifetime,row.engines.after.initial.rawLifetime,'exact native group lifetimes between engines');assert.deepEqual(row.engines.before.initial.retainedCutIndices,row.engines.after.initial.retainedCutIndices);assert.deepEqual(row.engines.before.initial.sourceParams,row.engines.after.initial.sourceParams,'same actual J.plan params in both engines');
   for(let i=0;i<8;i++)for(const layer of ['media','foreground'])assert.equal(row.engines.before.frames[i].layers[layer].rgbaSHA256,row.engines.after.frames[i].layers[layer].rgbaSHA256,'B avoidance does not move or retime media');result.rows.push(row);
  }
  H.verify(startup);result.endInputsUnchanged=true;
 }finally{await browser.close();await new Promise(r=>server.server.close(r));fs.writeFileSync(receipt,JSON.stringify({startup,...result}));}
 assert.deepEqual(result.warnings,[]);assert.equal(result.rows.length,3);console.log(JSON.stringify({rows:result.rows.map(r=>({spec:r.spec,status:r.engines.after.status})),negative:result.negative.length,warnings:result.warnings}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
