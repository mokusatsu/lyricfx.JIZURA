import pathlib, json, gzip, hashlib, subprocess, collections, datetime, math

root=pathlib.Path('/workspace/avoid008-final-c34')
main=pathlib.Path('/workspace/lyricfx.JIZURA')
p=root/'tasks/evidence/AVOID-008/performance/immutable-edge-profile01'
fixed='5007c71bfdf099f122a577c4c14578628672ca0e'
sha=lambda b:hashlib.sha256(b).hexdigest()
readgz=lambda f:gzip.decompress(f.read_bytes())
git=lambda f:subprocess.check_output(['git','show',fixed+':'+f],cwd=root,stderr=subprocess.PIPE)
raw=readgz(p/'results.raw.json.gz')
assert sha(raw)=='42cb0bca9692cb6994af525e5afef9f5d0af5436aa20d79c7a77b0f31bd9d8f9'
r=json.loads(raw); agg=json.loads((p/'cpu-aggregate.json').read_bytes())
assert not r['errors'] and not r['changedInputs'] and not r['changedPackages'] and not r['contaminated']
assert not r['formalExecuted'] and not r['performanceQualified'] and r['ownedBrowserServerClosed']
assert r['samplingIntervalUs']==100 and r['runnerPID']==364120
assert all(not x['foreign'] for x in r['concurrency'])
assert not pathlib.Path('/proc/364120').exists()
rt=r['runtime']['environment']
assert rt['observations_current'] and rt['spec_revision']==rt['observed_spec_revision']=='215'
assert rt['network_policy']=={'mode':'unrestricted','state':'enforced'}
assert r['config']['renderFrames']==80 and r['config']['renderWarmup']==16
archives=json.loads((p/'archive-check.json').read_bytes()); archived={};git_archives=[];untracked_inputs=[]
for a in archives:
    b=readgz(p/a['archive']); archived[a['path']]=b
    assert len(b)==a['rawBytes'] and sha(b)==a['rawSHA256']
    assert sha((p/a['archive']).read_bytes())==a['gzipSHA256']
    try:
        fixed_bytes=git(a['path']); assert fixed_bytes==b,a['path'];git_archives.append(a['path'])
    except subprocess.CalledProcessError:
        assert a['path'].startswith('tasks/evidence/'),a['path']
        assert (root/a['path']).read_bytes()==b,a['path'];untracked_inputs.append(a['path'])
assert len(archives)==117
assert all(sha(archived[f])==s for f,s in r['pins'].items())
packages=json.loads((p/'package-pins.json').read_bytes())
assert len(packages)==173 and r['packageFiles']==173
for a in packages:
    b=pathlib.Path(a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256']
html=archived['index.html'].decode(); modules={}
for f,b in sorted(archived.items()):
    if not(f.startswith('src/') and f.endswith('.js')):continue
    src=b.decode()
    if '__EFFECT_PREVIEW_IMAGE__' in src:
        import base64
        src=src.replace('__EFFECT_PREVIEW_IMAGE__','data:image/png;base64,'+base64.b64encode(git('assets/effect-preview.png')).decode())
    assert html.count(src)==1,f
    start=html[:html.index(src)].count('\n');modules[f]={'start':start,'end':start+src.count('\n')}
assert len(modules)==84 and modules==agg['sourceModules']
oldroot=root/'tasks/evidence/AVOID-008/performance/final-c34-profile02'
old=json.loads(readgz(oldroot/'results.raw.json.gz'))
refraw=readgz(root/'tasks/evidence/AVOID-008/performance/immutable-edge-diagnose01/results.raw.json.gz')
assert sha(refraw)==r['referenceRawSHA256'];ref=json.loads(refraw)
phases=[]; guards=[]
for side, aside in zip(r['sides'],agg['sides']):
    on=side['on'];v=side['result'];assert on==aside['on']
    previous=next(s for s in old['sides'] if s['on']==on)
    for name in ['normalizedJSON','fullValueJSON','fullAliasGraph']:
        a=side['output'][name];b=readgz(p/a['path'])
        assert len(b)==a['rawBytes'] and sha(b)==a['rawSHA256']
        assert b==readgz(oldroot/previous['output'][name]['path'])
    assert side['output']['sourceRevision']==6 and side['output']['rootFrozen']
    original=next(s for s in ref['sides'] if s['on']==on and s['side']=='candidate')
    checked=['cuts','states','observations','fontQualification','projectSHA256','normalizedInputSHA256','allIterationInputSHA256','regionAudit','idCounts','renderIDs','renderCalls','planningCalls','counts']
    for k in checked:assert v[k]==original[k],(on,k)
    assert len(v['warmFinalizations'])==6
    for w in v['warmFinalizations']:
        assert w['delta']['hits']==1 and w['actualRecordCalls']==0
        assert all(w['delta'][k]==0 for k in ['misses','stores','bypasses','identityDrifts'])
    assert len(v['frames'])==80 and sum(f['warmup'] for f in v['frames'])==16
    assert len(v['renderIDs'])==34 and not v['renderErrors']
    assert v['renderCalls']=={'record':80 if on else 0,'replay':80 if on else 0}
    assert len(v['observations'])==(80 if on else 0)
    assert v['counts']=={'requestedCuts':100,'actualCuts':100,'regions':100,'staged':100 if on else 0,'unstaged':0 if on else 100,'budgetViolations':0}
    if on:assert v['fontQualification']['complete'] and v['fontQualification']['unknown']==[]
    guards.append({'on':on,'fullValueAliasNormalizedByteEqual':True,'functionalFieldsEqualToUnprofiled':checked,'wholeHits':6,'warmActualRecord':0,'actualRender':v['renderCalls'],'observations':len(v['observations'])})
    for profile, ap in zip(side['profiles'],aside['phases']):
        cpu_raw=readgz(p/profile['cpu']['path']); assert len(cpu_raw)==profile['cpu']['rawBytes'] and sha(cpu_raw)==profile['cpu']['rawSHA256']
        cpu=json.loads(cpu_raw); nodes={n['id']:n for n in cpu['nodes']};parents={c:n['id'] for n in nodes.values() for c in n.get('children',[])}
        assert len(cpu['samples'])==len(cpu['timeDeltas'])==profile['cpu']['samples']==ap['sampleCount']
        mainid=next(n['callFrame']['scriptId'] for n in nodes.values() if n['callFrame']['url'].endswith('/') and n['callFrame']['functionName'] in ['J.finalizePlacementPlan','frame'])
        def module(n):
            f=n['callFrame'];return next((k for k,b in modules.items() if b['start']<=f['lineNumber']<=b['end']),None) if f['scriptId']==mainid else None
        counters=collections.Counter();self_names=collections.Counter();inclusive_names=collections.Counter();interiors=0
        metric={m['name']:m['value'] for m in profile['anchorMetrics']['metrics']};nav=metric['NavigationStart']*1000
        gap=metric['Timestamp']*1000-nav-profile['anchorPage']['now'];margin=max(2,abs(gap)+.2);time=cpu['startTime']/1000
        for sample,delta in zip(cpu['samples'],cpu['timeDeltas']):
            ms=delta/1000;time+=ms;counters['total']+=ms
            chain=[];n=sample
            while True:
                chain.append(nodes[n])
                if n not in parents:break
                n=parents[n]
            if chain[0]['callFrame']['functionName']=='(garbage collector)':counters['gc']+=ms;continue
            names={x['callFrame']['functionName'] for x in chain if x['callFrame']['scriptId']==mainid}
            iswarm=profile['phase']=='warm-finalization'
            rooted='J.finalizePlacementPlan' in names if iswarm else any(x['callFrame']['functionName']=='frame' and module(x)=='src/09_render.js' for x in chain)
            if not rooted:counters['unrooted']+=ms;continue
            counters['rooted']+=ms
            self_names[chain[0]['callFrame']['functionName']]+=ms
            for name in names:inclusive_names[name]+=ms
            def has09g(name):return any(x['callFrame']['functionName']==name and module(x)=='src/09g_layoutsC_placement.js' for x in chain)
            if iswarm:
                if has09g('payloadDecode'):key='payload decode / native parse and repairs'
                elif has09g('edgeRegisterFinal'):key='immutable edges / registration'
                elif 'cacheDecode' in names:key='decode'
                elif {'cacheEncode','cacheDependencies'}<=names:key='dependency fonts old graph encode'
                elif 'cacheDependencyEncode' in names:key='dependency typed metadata encode/eligibility'
                elif 'cacheDependencies' in names:key='dependency complete collection walk'
                elif 'cacheEncode' in names:key='whole input/options/lineage old graph encode'
                elif 'freeze' in names:key='freeze'
                elif 'signature' in names:key='signature'
                elif 'beginFinalCache' in names:key='begin other (UTF8/charges/context)'
                elif 'verifyCacheContext' in names:key='verify other'
                elif 'readFinalCache' in names:key='read other'
                else:key='finalize other'
            elif 'A.record' in names:
                key='record / convex hull' if 'A.convexHull' in names else 'record / text metrics' if names & {'measureText','textBounds','glyphMeasurement'} else 'record / other native measurement'
            elif 'A.replay' in names:key='replay / drawing'
            elif names & {'A.validateFinal','signature'}:key='validateFinal / signature'
            elif any(module(x) in ['src/09g_layoutsC_placement.js','src/09h_layoutsC_editorial.js','src/09i_layoutsC_objects.js','src/09j_layoutsC_japanese.js'] for x in chain):key='adapter checks / geometry / dispatch'
            else:key='render other'
            counters['bucket:'+key]+=ms
            if not iswarm:
                t=time-nav
                if any(f['profileStartMS']+margin<=t<=f['profileStartMS']+f['ms']-margin for f in v['frames']):interiors+=1
        expected={'total':ap['totalSampleMs'],'rooted':ap['phaseRootedSampleMs'],'gc':ap['globalGC']['ms'],'unrooted':ap['globalUnattributedToPhaseStack']['ms'],**{'bucket:'+k:t for k,t in ap['exclusiveMs'].items()}}
        assert set(counters)==set(expected),(on,profile['phase'],set(counters)^set(expected))
        assert max(abs(counters[k]-expected[k]) for k in counters)<1e-7
        assert abs(counters['rooted']+counters['gc']+counters['unrooted']-counters['total'])<1e-7
        assert abs(gap-ap['clock']['sequentialAnchorDiscrepancyMS'])<1e-7
        if not iswarm:assert interiors==sum(f['interiorSamples'] for f in ap['perFrameApprox'])
        phases.append({'on':on,'phase':profile['phase'],'samples':len(cpu['samples']),'recomputed':dict(counters),'selfEdgeAppendMs':self_names['edgeAppend'],'selfRegisteredReadMs':self_names['read'],'clockGapMs':gap,'marginMs':margin,'interiorSamples':None if iswarm else interiors})
out={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedEvidenceCommit':fixed,'productSource':'8ff3dd8487a4fb4193d00ef9caa296372c751b4f','rawSHA256':sha(raw),'inputArchivesSHAExact':117,'inputArchiveFixedGitExact':git_archives,'untrackedEvidenceInputLiveBytesExact':untracked_inputs,'actualPackageFilesSHAExact':173,'compiledModuleLocationsIndependentlyRebuilt':84,'guardResults':guards,'independentCPUPartitions':phases,'decision':'Accept CPU diagnostic and targeted lazy-edge implementation motivation only. Not performance acceptance, not cross-runtime improvement. ON render has zero interior samples; no per-layout CPU attribution. Named labels read-only feasibility retained, no additional profile authorized.','priorUnprofiledGate':'ON 3.170833x planning and +5.1ms render FAIL; OFF 1.495127x and +2.1ms. Runtime214 separate from215 profile.','parentHarnessCorrection':'An initial all-inputs Git assumption rejected the untracked parent gate, correctly identified as separate archived evidence bytes rather than source. Inspection-only shape probes also failed on list/numeric fields, without running product/tests. Expectations and product unchanged.','formal1000Executed':False,'publicRequests':0,'parentImageViews':0}
target=main/'tasks/evidence/AVOID-008/parent-immutable-edge-profile01-review.json'
assert not target.exists();target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'receipt':str(target),'sha256':sha(target.read_bytes()),'archives':117,'packages':173,'phases':len(phases)},ensure_ascii=False))
