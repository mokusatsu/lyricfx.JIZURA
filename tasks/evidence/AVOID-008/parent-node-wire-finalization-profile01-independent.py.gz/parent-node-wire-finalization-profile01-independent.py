import pathlib,json,gzip,hashlib,subprocess,collections,base64,datetime
r=pathlib.Path('/workspace/avoid008-final-c34');m=pathlib.Path('/workspace/lyricfx.JIZURA');c='708ee7017206d7ed50f0fe239def111e7a17f372';prefix='tasks/evidence/AVOID-008/performance/node-wire-finalization-profile01';p=r/prefix;sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda f:subprocess.check_output(['git','show',c+':'+f],cwd=r)
packed=(p/'results.json.gz').read_bytes();assert sha(packed)=='d23925d85bb77472aacb40ad997ea57079e8f3f1eda49eb7f9b6c47f992e0eb4';d=json.loads(gzip.decompress(packed));assert not d['errors'] and not d['changedInputs'] and not d['changedPackages'];assert d['formalExecuted'] is False and d['performanceQualified'] is False
assert not d['concurrency']['before']['jobs'] and not d['concurrency']['after']['jobs'];assert d['ownedCleanup']['browserCloseAwaited'] and d['ownedCleanup']['serverCloseAwaited']
for pin in d['inputArchives']:
 b=(r/pin['archive']).read_bytes();assert sha(b)==pin['archiveSHA256'];b=gzip.decompress(b);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'];assert b==git(pin['path'])
for pin in d['gate']['productPins']:assert sha(git(pin['path']))==pin['sha256']
for pin in d['gate']['packagePins']:assert sha(pathlib.Path(pin['path']).read_bytes())==pin['sha256']
html=git('index.html').decode();encoded=html.encode('utf-16-le');preview='data:image/png;base64,'+base64.b64encode(git('assets/effect-preview.png')).decode();lineMap=json.loads((p/'source84-line-map.json').read_text());assert len(lineMap['modules'])==84
for row in lineMap['modules']:
 b=git(row['path']);assert sha(b)==row['sha256'];text=b.decode().replace('__EFFECT_PREVIEW_IMAGE__',preview);start=row['startUTF16Offset'];end=row['endUTF16Offset'];assert encoded[start*2:end*2].decode('utf-16-le')==text;assert encoded[:start*2].decode('utf-16-le').count('\n')==row['startLineZeroBased'];assert row['endLineZeroBased']==row['startLineZeroBased']+text.count('\n')
analysis=[]
for side in d['sides']:
 v=side['verification'];assert v['hitDelta']==v['fastDelta']==8 and v['actualRecordCalls']==0
 for key in ['sourceUnchanged','latestOutputExact','latestAliasDescriptorsExact','latestFullyFrozen','stableFunctionIdentities','nativeIDsUnchanged']:assert v[key]
 cpu=side['cpu'];b=(p/cpu['path']).read_bytes();assert sha(b)==cpu['gzipSHA256'];raw=gzip.decompress(b);assert sha(raw)==cpu['rawSHA256'];profile=json.loads(raw);nodes={n['id']:n for n in profile['nodes']};parents={child:n['id'] for n in profile['nodes'] for child in n.get('children',[])};inside=outside=0;totals=collections.Counter();selfs=collections.Counter()
 for leaf,weight in zip(profile['samples'],profile['timeDeltas']):
  chain=[];i=leaf
  while i is not None:chain.append(nodes[i]['callFrame']['functionName']);i=parents.get(i)
  if 'J.finalizePlacementPlan' not in chain:outside+=weight;continue
  inside+=weight;selfs[nodes[leaf]['callFrame']['functionName']]+=weight;category=next((name for name in ['freeze','readCompletedPayload','edgeRegisterFinal','signature','cacheDependencies','cacheEncode'] if name in chain),'other finalization');totals[category]+=weight
 assert sum(totals.values())==inside;analysis.append({'on':side['on'],'profiledCalls':8,'finalizerAncestorSampleUs':inside,'excludedOutsideAncestorSampleUs':outside,'mutuallyExclusiveCategoriesUs':dict(totals),'selfTop':selfs.most_common(18)})
e=json.loads(gzip.decompress((p/'execution.json.gz').read_bytes()));assert e['runnerPID']==388354 and e['kernelExitCode']==0 and e['reaped'] and e['runnerGone'] and e['diskAvailableBytes']>=250*1024*1024
files=subprocess.check_output(['git','ls-tree','-r','--name-only',c,prefix],cwd=r,text=True).splitlines()
for f in files:assert (r/f).read_bytes()==git(f)
receipt={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedSource':c,'rawSHA256':sha(packed),'inputArchives':len(d['inputArchives']),'actualPackages':len(d['gate']['packagePins']),'fixedProductPins':len(d['gate']['productPins']),'source84LineMapIndependentlyVerified':True,'actualExecution':e,'analysis':analysis,'method':'Only sample stacks with exact J.finalizePlacementPlan ancestor. Category priority freeze/readCompletedPayload/edgeRegisterFinal/signature/cacheDependencies/cacheEncode/other, mutually exclusive. Outside program/idle/control/background samples excluded. CPU diagnostics are never formal speed qualification.','decision':'Normal diagnostic evidence accepted. ON freeze and restored payload dominate about half the finalizer samples. Next: private decoded-root dense-array freeze at the original freeze point; ordinary/global fallback retained. No prefreeze or geometry change.','formalQualified':False,'additionalSecurityAudit':False,'publicRequests':0,'parentImageViews':0}
out=m/'tasks/evidence/AVOID-008/parent-node-wire-finalization-profile01-review.json';out.write_text(json.dumps(receipt,indent=2)+'\n');out.with_name('parent-node-wire-finalization-profile01-independent.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print(json.dumps({'accepted':True,'inputs':len(d['inputArchives']),'fixedFiles':len(files),'analysis':analysis}))
