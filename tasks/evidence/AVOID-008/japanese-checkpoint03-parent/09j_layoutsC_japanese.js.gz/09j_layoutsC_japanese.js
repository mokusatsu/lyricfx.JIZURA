/* AVOID-008 Japanese source adapters. All measurements use registered native
 * renders. Unsupported source domains stay explicit; they are never certified. */
(() => {
'use strict';
const A=J.placement,ID='c-japanese',ids=['chochin','routeMap','stationSign','noren','tanzaku','omikuji','kakejiku','shoji','warningLabel','priceTag','karuta'];
const fail=(code,message)=>{const e=new Error(message);e.code=code;throw e;};
const norm=t=>String(t||'').replace(/\s/g,'');
const rect=b=>[[b.x0,b.y0],[b.x1,b.y0],[b.x1,b.y1],[b.x0,b.y1]];
const contains=(p,poly)=>{let pos=false,neg=false;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],v=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);if(v>1e-6)pos=true;if(v< -1e-6)neg=true;}return !(pos&&neg);};
function record(renderer,plan,cut,time){
 const ctx=A.measurementContext();ctx.reset();
 const env=renderer.makeEnv(ctx,plan,cut,cut.palette||plan.style.schemes[cut.scheme%plan.style.schemes.length],{pass:'main',t:time,realTime:time,lt:time-cut.start,ltb:time-cut.start,step:Math.floor(time*(plan.fps||24)),scale:1,allowFilter:false});
 const program=A.record(renderer,env);if(!program.measurementSupported)fail('UNSUPPORTED_MEASUREMENT',JSON.stringify(program.diagnostics));return program;
}
function nativeFont(css){const match=/(?:^|\s)(\d+(?:\.\d+)?|\.\d+)px(?=\s|\/|$)/.exec(String(css||'')),size=match?Number(match[1]):NaN;if(!Number.isFinite(size)||size<=0)fail('UNMEASURED_NATIVE_FONT','Native CSS font requires a finite positive px size');return {size,font:String(css).slice(0,match.index)+match[0].replace(match[1]+'px','<size>px')+String(css).slice(match.index+match[0].length)};}
function mapping(program,cut){
 const main=program.events.filter(e=>e.kind==='item'&&e.args[0].placementMain).map(e=>e.args[0]);
 if(!main.length||norm(main.map(e=>e.text).join(''))!==norm(cut.text))fail('SOURCE_COVERAGE','Every native ordered lyric occurrence is required');
 return {complete:true,source:norm(cut.text),main:main.map(e=>({text:e.text,font:e.font,size:e.size,mi:e.mi??0})),metadata:program.events.filter(e=>e.kind==='nativeText'||e.kind==='item'&&!e.args[0].placementMain).map(e=>({kind:e.kind,text:e.kind==='item'?e.args[0].text:e.args[0],...(e.kind==='item'?{font:e.args[0].font,size:e.args[0].size}:nativeFont(e.args[3].font))})),owned:program.events.map(e=>({kind:e.kind,owner:e.owner,order:e.order,role:e.role})),rule:'Retain native glyph occurrences, real replica/metadata, every paper, line, roller, clip and painter order'};
}
function quality(source,native,plan,cut,explicitSize){
 const floor=Math.max(18,.035*Math.min(plan.W,plan.H)),secondaryFloor=Math.max(12,.02*Math.min(plan.W,plan.H)),scale=cut.contentScale??1;
 if(source.main.length!==native.main.length||source.metadata.length!==native.metadata.length||JSON.stringify(source.owned)!==JSON.stringify(native.owned))fail('NATIVE_SEMANTIC_MAPPING','Source event identity and order changed');
 const ratios=[];
 for(const [index,item] of source.main.entries()){
  const n=native.main[index],ratio=item.size/n.size;ratios.push(ratio);
  if(norm(item.text)!==norm(n.text)||item.font!==n.font||item.mi!==n.mi||ratio<.7-1e-8||item.size*scale<floor-1e-8||explicitSize&&Math.abs(ratio-1)>1e-8)fail('NATIVE_SIZE_MAPPING','Source font, main clock, .7 native ratio, actual readable floor and explicit size must hold');
 }
 for(const [index,item] of source.metadata.entries()){
  const n=native.metadata[index];if(item.kind!==n.kind||item.text!==n.text||item.font!==n.font||item.size<n.size*.7-1e-8||item.size*scale<Math.min(n.size*scale,secondaryFloor)-1e-8)fail('METADATA_SIZE_FLOOR','Native metadata identity and readable size required');
 }
 return {minNativeFontRatio:Math.min(...ratios),minPrimaryPx:Math.min(...source.main.map(e=>e.size*scale)),floor,secondaryFloor,nativeFontSizePreserved:ratios.every(r=>Math.abs(r-1)<1e-8)};
}
function sourceDomain(cut){
 if(cut.treat!=='none'||cut.enter!=='cut'||cut.exit!=='cut'||cut.hold!=='still')fail('UNSUPPORTED_JAPANESE_MOTION','Current Japanese proof requires native cut entrance/exit, still text hold and no treatment; source paper motion remains unchanged');
 if(cut.layout==='chochin'){if(!['single','row'].includes(cut.params.variant)||!Number.isFinite(cut.params.ph))fail('UNSUPPORTED_PARAMETER_RANGE','Native chochin variant and finite sway phase required');const k=(cut.params.units||[]).filter(Boolean).length;return {entry:cut.params.variant==='single'?.5:.08+Math.max(0,k-1)*.07+.35,proof:'Lantern body/ribs/caps/verse share source pivot. Persistent hold sway is +/-2.2 single or +/-3 row. Full motion is bounded by +/-8.2 or +/-13 degrees, single top displacement [-.3H,0], and row outBack scale [0,1.2]. Light glow and stage wire/cord are explicitly background decoration, jointly replayed without changing attachment; they are not lyric/paper ink.'};}
 if(cut.layout==='noren'){if(![-1,1].includes(cut.params.wind)||!Number.isFinite(cut.params.ph))fail('UNSUPPORTED_PARAMETER_RANGE','Native noren wind domain is +/-1');const k=(cut.params.units||[]).filter(Boolean).length;return {entry:.04+Math.max(0,(k===1?3:k)-1)*.06+.45,proof:'Every cloth panel and attached glyph/crest shares its native pivot. Hold angle is bounded by +/-1.1 degrees; full exit by +/-[1.1+26*(.4+1.4abs(side))]. Drop only changes the owned reveal clip. Interval trigonometric extrema bound every raw source event, including blank panels and rod.'};}
 if(cut.layout==='omikuji')return {entry:.58,proof:'op in [0,1]; visible paper/shadow are nested rectangles. Every border, verse, category and Greek line is fixed under the same monotone native clip. Crease segments are subsets of the fully opened sheet.'};
 if(cut.layout==='kakejiku')return {entry:1.0,proof:'open in [0,1]; mount, paper, seal, hook and cord are fixed. Native clips only reveal subsets. Moving roller centers lie between the native full-open endpoints; the full event rectangle covers all roller/knob extremes.'};
 if(cut.layout==='shoji')fail(cut.params.variant==='shadow'?'UNSUPPORTED_SHOJI_FILTER_SUPPORT':'UNSUPPORTED_SHOJI_APERTURE','Shadow requires true allowFilter blur support; open requires a foreground aperture visibility proof');
 const reasons={chochin:'Persistent sine sway and owned glow/wire attachment require continuous source sweeps',routeMap:'Train and current-station states require ordered path/state proof and station field reflow',stationSign:'Native floor posts require reconnecting endpoints after board translation',noren:'Persistent panel sway and foreground panel visibility require continuous source sweeps',tanzaku:'Persistent strip/leaf sway, branch attachments and blank-strip occlusion require continuous source sweeps',warningLabel:'Source outBack body transform and moving clipped stripes require continuous support bounds',priceTag:'Hanging pendulum has persistent sine; shelf requires full outBack stage sweep',karuta:'Exponential sine bump remains nonzero after .28; first glyph replica and impact need continuous source sweeps'};
 fail('UNSUPPORTED_JAPANESE_SOURCE_SWEEP',reasons[cut.layout]);
}
function sweep(program,full){
 const trig=(a,b,cos)=>{const f=cos?Math.cos:Math.sin,out=[f(a),f(b)],base=cos?0:Math.PI/2;for(let k=Math.ceil((a-base)/Math.PI);base+k*Math.PI<b;k++)out.push(f(base+k*Math.PI));return [Math.min(...out),Math.max(...out)];};
 const interval=(v,r)=>v>=0?[v*r[0],v*r[1]]:[v*r[1],v*r[0]],result=[];
 for(const e of program.events.filter(e=>e.role==='primary')){const m=e.nativeCBody;if(!m){result.push(...e.polygons);continue;}if(!['noren-panel','chochin'].includes(m.kind))fail('UNSUPPORTED_NATIVE_BODY','Unexpected Japanese sweep group');
  const [px,py]=m.pivot,theta=m.angle*J.DEG,c=Math.cos(theta),sn=Math.sin(theta),angle=(full?m.fullAngle:m.holdAngle)*J.DEG,cs=trig(-angle,angle,true),ss=trig(-angle,angle,false),points=[];
  for(const [x,y]of e.polygons.flat())for(const factor of full&&m.fullScale?[0,m.fullScale]:[1]){const dx=(c*(x-px)+sn*(y-py))*factor,dy=(-sn*(x-px)+c*(y-py))*factor,xc=interval(dx,cs),ys=interval(dy,ss),xs=interval(dx,ss),yc=interval(dy,cs),shift=full?(m.dy||[0,0]):[0,0];points.push([px+xc[0]-ys[1],py+xs[0]+yc[0]+shift[0]],[px+xc[1]-ys[0],py+xs[1]+yc[1]+shift[1]]);}
  if(points.length)result.push(rect(A.bounds([points])));
 }return result;
}
function candidate(renderer,plan,cut,time,recipe,native,explicitSize,nativeProgram=null){
 const trial={...cut,...(recipe?{layoutCRecipe:recipe}:{})},program=nativeProgram||record(renderer,plan,trial,time),source=mapping(program,trial),q=quality(source,native,plan,cut,explicitSize);
 for(const e of program.events.filter(e=>e.kind==='item'&&e.args[0].placementMain)){const z=e.args[0].placementCOwnedZone;if(!z||!(z.x0<z.x1&&z.y0<z.y1))fail('OWNED_ZONE_REQUIRED','A nonempty source verse field is required');const zone=rect(z).map(p=>A.point(e.matrix,p));if(!e.inkPolygons?.length||e.inkPolygons.some(p=>p.some(v=>!contains(v,zone))))fail('OWNED_TEXT_OUTSIDE_FIELD','Complete pre-clip glyph ink must stay inside its source verse field');}
 const ps=['noren','chochin'].includes(cut.layout)?sweep(program,false):program.events.filter(e=>e.role==='primary').flatMap(e=>e.polygons);if(!ps.length)fail('EMPTY_SOURCE_SUPPORT','Native source must draw owned ink');
 // This rectangle is an analytic enclosure of all native clip/roller states,
 // not a union of sampled animation frames. The sourceDomain proof establishes
 // monotone reveal or roller translation between these extrema.
 const bound=A.bounds(ps),envelope=A.cameraEnvelope([rect(bound)],{...plan,fx:cut.effectFx||plan.fx,style:cut.effectStyle||plan.style},cut,20);
 const stageEnvelope=['noren','chochin'].includes(cut.layout)?A.cameraEnvelope([rect(A.bounds(sweep(program,true)))],{...plan,fx:cut.effectFx||plan.fx,style:cut.effectStyle||plan.style},cut,20):envelope;
 return {source,quality:q,envelopes:[envelope],stageEnvelopes:[stageEnvelope],bound};
}
function finalize({plan,cut,revision,stepDur,reachTail,explicitSize}){
 const domain=sourceDomain(cut),holdWindow=[cut.start+domain.entry,cut.end-cut.outDur];
 if(holdWindow[1]-holdWindow[0]<.04)fail('INSUFFICIENT_HOLD_WINDOW','Native full-open paper hold needs .04s before exit');
 cut.placementUnits=true;cut.placementLayoutsC=true;
 const renderer=Object.create(J.Renderer.prototype),time=holdWindow[0]+.0001,nativeProgram=record(renderer,plan,cut,time),native=mapping(nativeProgram,cut),cache=new Map();
 let reconstructed=1,cacheHits=0,rejected=0;const limit=54;
 const get=recipe=>{const key=JSON.stringify(recipe);if(cache.has(key)){cacheHits++;const c=cache.get(key);if(c.error)fail(c.error.code,c.error.message);return c;}if(recipe){if(reconstructed>=limit)fail('CUT_CANDIDATE_BUDGET','Japanese per-cut source reconstruction budget exhausted');reconstructed++;}try{const c=candidate(renderer,plan,cut,time,recipe,native,explicitSize,recipe?null:nativeProgram);cache.set(key,c);return c;}catch(e){rejected++;cache.set(key,{error:{code:e.code||'DRAW_PROGRAM_ERROR',message:e.message}});throw e;}};
 const base=get(null),segments=[],evaluationRange=[Math.min(cut.start,cut.renderStart??cut.start)-stepDur,Math.max(cut.end,cut.displayEnd??cut.end)+reachTail];
 for(let i=0;i<plan.lyricAvoidanceIndex.regions.length;i++){
  const r=plan.lyricAvoidanceIndex.regions[i],end=Math.min(r.end??plan.lyricAvoidanceIndex.regions[i+1]?.start??plan.duration,plan.duration);if(r.start>=evaluationRange[1])break;if(end<=evaluationRange[0]||end<=r.start)continue;
  const circle={cx:r.center.x*plan.W,cy:r.center.y*plan.H,r:r.radius*Math.min(plan.W,plan.H)},attempts=[];let selected=base,composition=null,solution;
  for(const recipe of (['noren','chochin'].includes(cut.layout)?[null,...(explicitSize?[]:[.95,.9,.85,.8,.75,.7].map(objectScale=>({objectScale,strategy:cut.layout==='chochin'?'source-lantern-proportional-size':'source-cloth-proportional-size'})))]:[null,...[.85,.7,.6,.5,.4].map(paperMeasure=>({paperMeasure,objectScale:1,strategy:'source-paper-column-measure'})),...(explicitSize?[]:[.95,.9,.85,.8,.75,.7].flatMap(objectScale=>[1,.85,.7,.6,.5,.4].map(paperMeasure=>({objectScale,paperMeasure,strategy:'source-paper-size-and-column-measure'})))),...(cut.layout==='omikuji'&&!explicitSize?[1.2,1.35,1.5].flatMap(paperHeightMeasure=>[.55,.5,.45,.4].map(paperMeasure=>({objectScale:.8,paperMeasure,paperHeightMeasure,strategy:'source-fortune-column-aspect'}))):[])])){
   try{const c=get(recipe),s=A.solveBasic(c.envelopes,circle,plan.W,plan.H,cut.seed,{fitBounds:A.bounds(c.stageEnvelopes)});attempts.push({...recipe,strategy:recipe?.strategy||'native-owned-joint-translation',objectScale:recipe?.objectScale??1,status:s.status,reason:s.reason||null,quality:c.quality});if(!solution){solution=s;}if(s.status==='safe'){selected=c;composition=recipe;solution=s;break;}}catch(e){attempts.push({...recipe,strategy:recipe?.strategy,status:'rejected',reason:e.code||'DRAW_PROGRAM_ERROR',details:e.message});}
  }
  const safe=solution?.status==='safe',offset=safe?solution.offset:[0,0];segments.push({start:r.start,end,region:r.id,circle,from:offset,to:offset,status:safe?'safe-hold':'insufficient-space',decision:safe?'certified-hold-adapter':'excluded-during-avoidance',safetyScope:'source-owned-object-entry-exit-relaxed',failure:safe?null:'no-certified-native-paper-composition',holdWindow,composition,quality:selected.quality,envelopes:selected.envelopes,stageEnvelopes:selected.stageEnvelopes,attempts});
 }
 return {version:1,kind:'layouts-c-source-native',revision,evaluationRange,holdWindow,units:[{owner:cut.layout+'.composition',envelopes:base.envelopes,stageEnvelopes:base.stageEnvelopes,segments}],measurementSupported:true,safety:segments.every(s=>s.status==='safe-hold')?'certified-hold-adapter':'insufficient-space',explicitSizePreserved:true,sourceProof:{sourceMapping:base.source,recipe:'native-owned-joint-translation-then-source-dimensions',interval:domain.proof,stageProof:['noren','chochin'].includes(cut.layout)?'Per-source pivot/trigonometric/drop/scale intervals enclose every primary owned event. Every blank panel, crest, body, cap, rib and lyric stays classified; camera interval and joint replay preserve clips and connections.':'All source ink enclosed by the full-open event rectangle plus camera interval; the identical matrix translates paper, clips, glyphs, metadata, rollers and cords',nativeFontSizePreserved:segments.every(s=>s.quality.nativeFontSizePreserved),ownedShapesPreserved:true,...(cut.layout==='chochin'?{backgroundDecoration:{owners:['chochin.glow','chochin.wire','chochin.cord'],glowReason:'Source radial body-colour lighting fading to transparency contains no glyph silhouette or letter shadow; physical body/ribs/caps/verse remain primary. This source-based role is fixed for every radius.',attachment:'All decoration uses the same joint replay offset. Ceiling cord extends beyond stage; left/right wire continuations reconnect to stage edges while original reveal path remains unchanged.'}}:{}),candidateBudget:{reconstructed,cacheHits,rejected,uniqueRecipes:cache.size,perCutLimit:limit,nativeProgramReusedForBase:true},limitations:'Cut/still text motion only; unsupported source domains fail explicitly'}};
}
function render({renderer,env,trajectory:tr}){
 const unit=tr.units[0],active=unit.segments.find(s=>s.start<=env.realTime&&env.realTime<s.end),offset=A.offsetAt(unit,env.realTime),scale=env.scale||1;
 if(active?.composition||env.cut.layout==='chochin'){const cut={...env.cut,layoutCRecipe:{...active?.composition,...(env.cut.layout==='chochin'?{jointOffset:offset}:{})}};env=renderer.makeEnv(env.ctx,env.plan,cut,env.sc,{...env,cut});}
 const program=A.record(renderer,env);if(!program.measurementSupported)fail('UNSUPPORTED_DRAW_PROGRAM',JSON.stringify(program.diagnostics));
 const polygons=program.events.filter(e=>e.role==='primary').flatMap(e=>e.polygons).map(p=>p.map(q=>[q[0]/scale,q[1]/scale])),envelopes=active?.stageEnvelopes||unit.stageEnvelopes,covered=polygons.every(p=>envelopes.some(q=>p.every(v=>contains(v,q))));
 const inHold=env.t>=tr.holdWindow[0]&&env.t<=tr.holdWindow[1],holdCovered=!inHold||polygons.every(p=>(active?.envelopes||unit.envelopes).some(q=>p.every(v=>contains(v,q))));
 if(!covered||!holdCovered)fail('ENVELOPE_VIOLATION','Japanese source escaped its continuous paper/roller enclosure');
 const moved=polygons.map(p=>p.map(v=>[v[0]+offset[0],v[1]+offset[1]])),stageContained=moved.every(p=>p.every(v=>v[0]>=0&&v[0]<=env.plan.W&&v[1]>=0&&v[1]<=env.plan.H));
 if(active?.status==='safe-hold'&&!stageContained)fail('STAGE_CONTAINMENT_VIOLATION','Native paper translation would introduce stage crop');
 const region=J.resolveAvoidanceAt(env.plan,env.realTime),circle=region?J.avoidanceCirclePixels(region,env.plan.W,env.plan.H):null,clear=!moved.length||A.clear(moved,circle,Math.max(2,.005*Math.min(env.plan.W,env.plan.H)));
 env.placementObservation?.({cut:env.cut.index,realTime:env.realTime,motionTime:env.t,pass:env.pass,offset,measurementSupported:true,envelopeCovered:covered,stageEnvelopeCovered:covered,stageContained,safety:active?.status==='insufficient-space'?'conflict':clear?'safe':!inHold?'source-entry-exit-relaxed':'conflict',safetyScope:active?.safetyScope||'no-active-region',polygons:moved,events:program.events.map(e=>({kind:e.kind,role:e.role,owner:e.owner,order:e.order,polygons:e.polygons}))});A.replay(env,program,offset,env.cut.layout==='chochin'?{'chochin.glow':offset,'chochin.wire':offset,'chochin.cord':offset}:{});
}
for(const layout of ids)A.registerLayoutsCAdapter(layout,{id:ID,finalize,render});
})();
