import pathlib,json,subprocess,hashlib,gzip,datetime,base64
r=pathlib.Path('/workspace/avoid008-final-c34');m=pathlib.Path('/workspace/lyricfx.JIZURA');p=r/'tasks/evidence/AVOID-008/performance/immutable-edge-lazy01'
old='5007c71bfdf099f122a577c4c14578628672ca0e';new='3b0c995a2c912cf3edf6583f372c215c310e11f0'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda c,f:subprocess.check_output(['git','show',c+':'+f],cwd=r)
files=subprocess.check_output(['git','ls-tree','-r','--name-only',new,'src'],cwd=r).decode().splitlines();files=[f for f in files if f.endswith('.js')];assert len(files)==84
f='src/09g_layoutsC_placement.js';a=git(old,f);b=git(new,f);assert (r/f).read_bytes()==b and sha(b)=='9b060c2af5de11e7350e6eb0e809d29daccac7211fbb8aa33862168a4388ac72'
mark=b'// Only decoded completed-plan';end=b'function cacheDependencies(){';assert a[:a.index(mark)]==b[:b.index(mark)] and a[a.index(end):]==b[b.index(end):]
sources={x:git(new,x) for x in files};assert all(git(old,x)==sources[x]==(r/x).read_bytes() for x in files if x!=f)
assert git(old,'app/english.py')==git(new,'app/english.py');ns={};exec(compile(git(new,'app/english.py'),'fixed-app-english.py','exec'),ns)
image='data:image/png;base64,'+base64.b64encode(git(new,'assets/effect-preview.png')).decode();compiled=[]
for html in ['index.html','en/index.html']:
    h=git(new,html);assert h==(r/html).read_bytes() and h.count(b)==1 and h.replace(b,a)==git(old,html)
    script='\n'.join(ns['localize_js'](sources[x].decode(),x) if html.startswith('en/') else sources[x].decode() for x in files)
    if html.startswith('en/'):
        marker='/* ============================================================\n   JIZURA — editor UI';assert script.count(marker)==1
        script=script.replace(marker,git(new,'app/english.js').decode()+'\n'+marker,1)
    script=script.replace('__EFFECT_PREVIEW_IMAGE__',image)
    assert h.count(script.encode())==1,html
    compiled.append({'path':html,'sha256':sha(h),'all84TransformedModulesJoinedExact':True,'fullReverseExact':True})
report=json.loads(gzip.decompress((p/'pure02-results.json.gz').read_bytes()));assert report['passed'] and report['comparisons']==55677 and len(report['controls'])==64 and report['inputStart']==report['inputEnd'] and len(report['inputStart'])==94
for x in report['inputStart']:assert sha((r/x['path']).read_bytes())==x['sha256']
for file in ['pure02-results.json.gz','pure02-fixtures.json.gz','pure02-old-target.json.gz','pure02-candidate-target.json.gz','lazy-current-value-targets.json.gz']:
    assert gzip.decompress((p/file).read_bytes())==gzip.decompress((pathlib.Path('/tmp/avoid008-lazy-parent-pure01')/file).read_bytes()),file
current=json.loads(gzip.decompress((p/'pure02-candidate-target.json.gz').read_bytes()));previous=json.loads(gzip.decompress((r/'tasks/evidence/AVOID-008/performance/immutable-edge01/pure02-old-target.json.gz').read_bytes()));assert current['bits']==previous['bits'] and len(current['bits'])==55673
receipt={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':old,'source':new,'sourceSHA256':sha(b),'allOther83SourceGitAndLiveExact':True,'privateRegistryPrefixSuffixReverseExact':True,'compiled':compiled,'pureRerun':'node dev/avoidance/layouts-c-immutable-edge-lazy-pure.cjs /tmp/avoid008-lazy-parent-pure01','pureRerunExit':0,'pureRerunArtifactsExact':5,'originalNormalBitsExact':55673,'observableComparisons':4,'controls':64,'inputPinsUnchanged':94,'review':'Native parse-born references only; separate slice/map constructor/species/global/prototype guard, native captured direct calls; frozen reference proof before inspecting replacement, current own finite coords; native slice/map output CreateDataProperty avoids numeric setters/private leak; all-edge p read/convert/throw order and old4eps unchanged. Latest generation/caps remain. slots reservation and actual reads separately named.','decision':'Source/pure accepted for browser derivative preparation only, no speed acceptance. Primitive/-0 prefreeze admission changes internal accelerator only; final legacy boolean retained.','parentHarnessCorrection':'Initial source-embedding probe used untranslated source for EN and stopped at08d_media. Corrected to fixed existing localize_js and English UI insertion, without product/expectation changes. Whole84-module bundle and full HTML inverse then checked.','publicRequests':0,'parentImageViews':0}
target=m/'tasks/evidence/AVOID-008/parent-immutable-edge-lazy01-source-review.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':new,'source83':True,'compiled84JAEN':True,'pure':55677,'controls':64,'rerunExact':5}))
