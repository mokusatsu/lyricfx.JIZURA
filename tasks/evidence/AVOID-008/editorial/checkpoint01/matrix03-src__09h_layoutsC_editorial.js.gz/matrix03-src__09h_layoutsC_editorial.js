/* AVOID-008 editorial source recipes. Stage coordinates and native clocks stay
   intact; no viewport substitution, text mask or implicit auxiliary exclusion. */
(() => {
'use strict';
const A=J.placement,IDS=['magazine','headlineDeck','contents','footnote','proofread','numbered','poster','swissGrid','dictionary','newspaper'];
const fail=(code,message)=>{const e=new Error(message);e.code=code;throw e;},norm=t=>String(t||'').replace(/\s/g,''),rect=(x0,y0,x1,y1)=>[[x0,y0],[x1,y0],[x1,y1],[x0,y1]],short=p=>Math.min(p.W,p.H);
const contains=(p,q)=>{let pos=false,neg=false;for(let i=0;i<q.length;i++){const a=q[i],b=q[(i+1)%q.length],c=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);if(c>1e-4)pos=true;if(c< -1e-4)neg=true;}return !(pos&&neg);};
const box=ps=>{const b=A.bounds(ps);return rect(b.x0,b.y0,b.x1,b.y1);};
const camera=(ps,plan,cut)=>A.cameraEnvelope(ps,{...plan,style:cut.effectStyle||plan.style,fx:cut.effectFx||plan.fx},cut,20);
function record(renderer,plan,cut,T,extra={}){
 const ctx=A.measurementContext();ctx.reset();const time=cut.start+T,env=renderer.makeEnv(ctx,plan,cut,cut.palette||plan.style.schemes[cut.scheme%plan.style.schemes.length],{pass:'main',t:time,realTime:time,lt:T,ltb:T,step:Math.floor(time*(plan.fps||24)),scale:1,allowFilter:false,...extra}),program=A.record(renderer,env);
 if(!program.measurementSupported)fail('UNSUPPORTED_MEASUREMENT',JSON.stringify(program.diagnostics));if(program.events.some(e=>e.role!=='primary'))fail('EDITORIAL_OWNERSHIP','Every editorial source draw belongs to the protected composition');return program;
}
function mapping(program,cut){
 const items=program.events.filter(e=>e.kind==='item'),main=items.filter(e=>e.args[0].placementMain).map(e=>e.args[0]);if(!main.length||norm(main.map(i=>i.text).join(''))!==norm(cut.text))fail('SOURCE_COVERAGE','Every ordered editorial main occurrence must be retained exactly once');
 const nativeFontSize=font=>{const m=String(font).match(/(?:^|\s)([0-9]+(?:\.[0-9]+)?)px(?:\s|\/|$)/),size=m?Number(m[1]):NaN;if(!Number.isFinite(size)||size<=0)fail('EDITORIAL_NATIVE_FONT_SIZE','Finite positive CSS px size required for every fastRow copy');return size;};
 const metadata=program.events.filter(e=>e.kind==='nativeText'||e.kind==='item'&&!e.args[0].placementMain).map(e=>e.kind==='nativeText'?{kind:e.kind,text:e.args[0],font:e.args[3].font.replace(/[\d.]+px/,'SIZEpx'),size:nativeFontSize(e.args[3].font)}:{kind:e.kind,text:e.args[0].text,font:e.args[0].font,size:e.args[0].size});
 return {main:main.map(i=>({text:i.text,font:i.font,size:i.size,mi:i.mi??0,lead:i.lead??1.3,track:i.track??0})),metadata,shapes:program.events.filter(e=>!['item','nativeText'].includes(e.kind)).map(e=>e.kind),complete:true};
}
function quality(program,cut,expected,explicitSize,plan){
 const actual=mapping(program,cut),semantic=m=>m.map(({size,...v})=>v),U=short(plan),floor=Math.max(18,.035*U),secondaryFloor=Math.max(12,.02*U),contentScale=cut.contentScale??1;
 // Role-level fastRow floors are checked before a remeasure can change row cardinality.
 for(const it of actual.metadata.filter(i=>i.kind==='nativeText')){const peers=expected.metadata.filter(n=>n.kind===it.kind&&n.font===it.font);if(!peers.length)fail('EDITORIAL_NATIVE_FONT_IDENTITY','Native fastRow weight/style/family changed');const nativeMin=Math.min(...peers.map(n=>n.size));if(it.size<nativeMin*.7-1e-8||it.size*contentScale<Math.min(nativeMin*contentScale,secondaryFloor)-1e-8)fail('EDITORIAL_COPY_QUALITY','FastRow CSS px size fell below its role readable floor');}
 if(actual.main.length!==expected.main.length||JSON.stringify(semantic(actual.metadata))!==JSON.stringify(semantic(expected.metadata))||JSON.stringify(actual.shapes)!==JSON.stringify(expected.shapes))fail('EDITORIAL_SEMANTIC_MAPPING','Recipe changed native copy/metadata/owned operation topology');
 let minRatio=Infinity;actual.main.forEach((it,i)=>{const n=expected.main[i],ratio=it.size/n.size;minRatio=Math.min(minRatio,ratio);if(norm(it.text)!==norm(n.text)||it.font!==n.font||it.mi!==n.mi||it.lead!==n.lead||it.track!==n.track||ratio<.7-1e-8||it.size*contentScale<floor-1e-8||explicitSize&&Math.abs(ratio-1)>1e-8||cut.layout==='proofread'&&it.text!==n.text)fail('EDITORIAL_TYPE_QUALITY','Native font/clock/order, actual floor, annotation run or explicit type size changed');});
 actual.metadata.forEach((it,i)=>{const n=expected.metadata[i];if(!Number.isFinite(it.size)||it.size<n.size*.7-1e-8||it.size*contentScale<Math.min(n.size*contentScale,secondaryFloor)-1e-8||explicitSize&&Math.abs(it.size-n.size)>1e-8)fail('EDITORIAL_COPY_QUALITY','Real editorial copy fell below native ratio/readable floor or explicit size');});
 let fields=0;for(const e of program.events.filter(e=>e.kind==='item'&&e.args[0].placementMain)){const z=e.args[0].placementCOwnedZone;if(!z||![z.x0,z.y0,z.x1,z.y1].every(Number.isFinite)||z.x0>=z.x1||z.y0>=z.y1)fail('OWNED_ZONE_REQUIRED','Source editorial field required');const field=rect(z.x0,z.y0,z.x1,z.y1).map(p=>A.point(e.matrix,p));if(!e.inkPolygons?.length||e.inkPolygons.some(p=>p.some(v=>!contains(v,field))))fail('OWNED_TEXT_OUTSIDE_FIELD','Complete pre-clip main ink escaped its source editorial field');fields++;}
 return {source:actual,minNativeFontRatio:minRatio,minPrimaryPx:Math.min(...actual.main.map(i=>i.size*contentScale)),floor,secondaryFloor,completePreClipFields:fields,explicitSizePreserved:explicitSize};
}
// Every native clip used by these sources is a rectangle (number rise masks
// and halftone photo windows). Keep it owned and transport it with the source.
function clipped(event){let ps=event.polygons;for(const c of event.clips||[]){const a=c.args||c.commands?.find(([k])=>k==='rect')?.[1];if(!a||c.commands?.some(([k])=>k!=='rect'))fail('UNSUPPORTED_EDITORIAL_CLIP','Only the source rectangular mask is certified');const q=rect(a[0],a[1],a[0]+a[2],a[1]+a[3]).map(p=>A.point(c.matrix,p)),b=A.bounds([q]),out=[];for(const p of ps){const z=A.bounds([p]),x0=Math.max(z.x0,b.x0-1),x1=Math.min(z.x1,b.x1+1),y0=Math.max(z.y0,b.y0-1),y1=Math.min(z.y1,b.y1+1);if(x1>x0&&y1>y0)out.push(rect(x0,y0,x1,y1));}ps=out;}return ps;}
function sourceClock(cut,plan){
 const p=cut.params,D=cut.inDur,k=(p.chunks||p.lines||[cut.text]).filter(Boolean).length,port=plan.H>plan.W*1.08;let finish;
 switch(cut.layout){
 case 'magazine':finish=p.variant==='headline'?.75:.56;break;
 case 'headlineDeck':finish=Math.max(.8,.8*D+.45,D+.55,.6*D+.64);break;
 case 'contents':finish=Math.max(.65,.65+.1*(k-1),p.ctx?.5+.1*k:0);break;
 case 'footnote':finish=Math.max(.7*D+.37+.14*(k-1),.6*D+.5,.7*D+.6+.12*(k-1),.6);break;
 case 'proofread':{const marks=J.glyphCount(cut.text)<=4?1:p.marks.length;finish=Math.max(.5,.8*D+.1+.35*(marks-1)+.45,p.stamp?D+.55+marks*.25+.18:0);break;}
 case 'numbered':finish=Math.max(.59+.1*(k-1),.7+.08*(k-1),.5+.1*(k-1));break;
 case 'poster':finish=.76;break;
 case 'swissGrid':finish=Math.max(.55+.035*(port?4:6),.6+.035*(port?8:6),.62+.1*(k-1),.7);break;
 case 'dictionary':finish=Math.max(.65,.7*D+.35,.8*D+.62,p.variant==='page'?.6*D+.5:0);break;
 case 'newspaper':finish=1.1;break;
 default:fail('UNSUPPORTED_EDITORIAL_ID',cut.layout);
 }
 // Source mi is retained verbatim, including mainDraw's integer truncation.
 const maxDelay=cut.layout==='newspaper'?(Math.max(0,p.spin?.45:.3)/Math.max(.005,cut.stagger||.04)|0)*(cut.stagger||0):['contents','numbered','poster','swissGrid'].includes(cut.layout)?3*Math.max(k-1,J.glyphCount(cut.text)/5)*(cut.stagger||0):0;
 return Math.max(finish,Math.max(.01,D)+maxDelay)+.0001;
}
const fields={magazine:'pageScale',headlineDeck:'headlineMeasure',contents:'contentsMeasure',footnote:'footnoteMeasure',proofread:'proofMeasure',numbered:'numberMeasure',poster:'posterMeasure',swissGrid:'gridMeasure',dictionary:'dictionaryMeasure',newspaper:'sheetScale'};
function recipes(cut,explicitSize){const spacing=cut.layout==='footnote'?[14,28,42].map(noteMargin=>({noteMargin,strategy:'footnote-native-running-margin'})):cut.layout==='dictionary'?[14,28,42].map(dictionaryInset=>({dictionaryInset,strategy:'dictionary-native-page-edge-inset'})):[];if(explicitSize)return spacing;const field=fields[cut.layout];return [...spacing,...[.95,.9,.85,.8,.75,.7].map(value=>({[field]:value,...(cut.layout==='footnote'?{noteMargin:42}:{}),strategy:cut.layout+'-native-'+field})),...(cut.layout==='dictionary'?[.95,.85,.7].map(dictionaryTypeScale=>({dictionaryTypeScale,strategy:'dictionary-body-point-size'})):[])];}
function domain(cut){
 if(cut.hold!=='still'||cut.enter!=='cut'||cut.exit!=='cut'||cut.treat!=='none')fail('UNSUPPORTED_EDITORIAL_EFFECT','Dedicated editorial proof requires unchanged still/cut/cut and no treatment');
 const finite=v=>typeof v==='number'?Number.isFinite(v):!v||typeof v!=='object'||Object.values(v).every(finite);if(!finite(cut.params))fail('UNSUPPORTED_PARAMETER_RANGE','Finite editorial parameters required');
 const p=cut.params,variants={magazine:['headline','vertical','plate'],headlineDeck:['top','bottom','split'],contents:['rows','tate'],numbered:['cols','rows','behind'],poster:['stack','block','tate'],swissGrid:['a','b'],dictionary:['entry','page'],newspaper:['yoko','tate']};if(variants[cut.layout]&&!variants[cut.layout].includes(p.variant))fail('UNSUPPORTED_PARAMETER_RANGE','Unknown editorial source variant');
 if(['contents','footnote','numbered','swissGrid'].includes(cut.layout)&&(!Array.isArray(p.chunks)||p.chunks.length<1||p.chunks.length>4||norm(p.chunks.join(''))!==norm(cut.text)))fail('SOURCE_COVERAGE','Native ordered source chunks required');
 if(cut.layout==='footnote'&&(!['num','kome','star'].includes(p.marks)||!['left','center'].includes(p.align)))fail('UNSUPPORTED_PARAMETER_RANGE','Native footnote mark/alignment domain required');
 if(cut.layout==='proofread'&&(!Array.isArray(p.marks)||p.marks.length!==2||p.marks.some(k=>!['circle','wave','box','dots'].includes(k))||Math.abs(p.rot)>8))fail('UNSUPPORTED_PARAMETER_RANGE','Native proof mark/stamp domain required');
 if(cut.layout==='dictionary'&&(!(p.tabY>=.2&&p.tabY<=.75)||!['名','連語','感','形動','副'].includes(p.pos)))fail('UNSUPPORTED_PARAMETER_RANGE','Native dictionary tab/POS domain required');
}
function scaled(poly,pivot,lo,hi){return A.convexHull(poly.flatMap(p=>[lo,hi].map(s=>[pivot[0]+(p[0]-pivot[0])*s,pivot[1]+(p[1]-pivot[1])*s])));}
function eventStage(e,plan,cut){
 let ps=clipped(e),it=e.kind==='item'?e.args[0]:null,body=e.nativeCBody,U=short(plan),ls=J.clamp(U*.024,14,34);
 if(!ps.length)return [];
 if(body?.kind==='editorial-proof-stamp'||body?.kind==='editorial-superscript')ps=ps.map(p=>scaled(p,A.point(e.matrix,body.kind==='editorial-proof-stamp'?[0,0]:body.pivot),0,body.maxScale));
 // All partial source paths are subsets of their completed path. Native dots
 // may overshoot; outBack(s<=2.2) has max <1.2 for p in [0,1].
 if(e.kind==='circle'&&['headlineDeck','poster','swissGrid'].includes(cut.layout))ps=ps.map(p=>scaled(p,A.point(e.matrix,[e.args[0],e.args[1]]),0,1.2));
 if(cut.layout==='swissGrid'&&e.kind==='rect')ps=ps.map(p=>{const b=A.bounds([p]);return scaled(p,[(b.x0+b.x1)/2,(b.y0+b.y1)/2],0,1.2);});
 if(cut.layout==='dictionary'&&e.kind==='rect')ps=ps.map(p=>A.convexHull(p.flatMap(v=>[[v[0],v[1]],[v[0]+U*.075,v[1]]])));
 if(it&&!it.placementMain){let dx=0,dy=0;if(cut.layout==='headlineDeck')dy=J.clamp(U*.032,16,44)*.5;
 if(cut.layout==='footnote'&&!body&&!String(it.text).startsWith('—')&&!String(it.text).startsWith('NOTES'))dx=ls;
 if(cut.layout==='dictionary')dx=Math.max(J.clamp(U*.028,14,36),U*.075);
 if(dx||dy)ps=ps.map(p=>A.convexHull(p.flatMap(v=>[[v[0],v[1]],[v[0]+dx,v[1]+dy]])));
 }
 if(cut.layout==='numbered'&&e.clips?.length){const clip=e.clips[0],a=clip.args||clip.commands?.find(([k])=>k==='rect')?.[1];if(a)ps=[rect(a[0]-2,a[1]-2,a[0]+a[2]+2,a[1]+a[3]+2).map(p=>A.point(clip.matrix,p))];}
 return ps;
}
const mul=(a,b)=>{const v=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]];return [Math.min(...v),Math.max(...v)];};
function trig(a,b,cos){const f=cos?Math.cos:Math.sin,out=[f(a),f(b)],start=cos?0:Math.PI/2;for(let k=Math.ceil((a-start)/Math.PI);start+k*Math.PI<b;k++)out.push(f(start+k*Math.PI));return [Math.min(...out),Math.max(...out)];}
function newsStage(ps,plan,cut){
 const cx=plan.W/2,cy=plan.H/2,out=[];
 for(const p of ps)for(const [x,y]of p){const dx=x-cx,dy=y-cy;if(!cut.params.spin){out.push([x,y],[x,y+plan.H*.98]);continue;}
  for(let i=0;i<64;i++){const e0=i/64,e1=(i+1)/64,q0=1-(1-e0)**3,q1=1-(1-e1)**3,s=[Math.max(.001,q0),Math.max(.001,q1)],angles=[(1-q1)*4*Math.PI,(1-q0)*4*Math.PI],cs=trig(...angles,true),sn=trig(...angles,false);
   // Signed dx/dy require interval multiplication, not endpoint ordering.
   const xc=mul([dx,dx],cs),ysn=mul([dy,dy],sn),xs2=mul(s,[xc[0]-ysn[1],xc[1]-ysn[0]]),xsn=mul([dx,dx],sn),yc=mul([dy,dy],cs),ys2=mul(s,[xsn[0]+yc[0],xsn[1]+yc[1]]);out.push([cx+xs2[0],cy+ys2[0]],[cx+xs2[1],cy+ys2[1]]);
  }out.push([x,y+plan.H*.08]);
 }return [A.convexHull(out)];
}
function prepare(renderer,plan,cut,T,expected,explicitSize,nativeProgram=null,budget=null){
 const take=extra=>{if(budget&&++budget.recordCalls>128)fail("CUT_CANDIDATE_BUDGET","Editorial native record budget exhausted before reconstruction");return record(renderer,plan,cut,T,extra);};
 const programs=[nativeProgram||take({})],qualityResult=quality(programs[0],cut,expected,explicitSize,plan);
 if(cut.layout==='contents'){const k=cut.params.chunks.length,active=Math.min(k-1,Math.floor(J.clamp(T/Math.max(.3,cut.dur*.92))*k));for(let i=0;i<k;i++)if(i!==active)programs.push(take({placementCEditorialActive:i}));}
 const events=programs.flatMap(p=>p.events),hold=events.flatMap(e=>clipped(e).map(p=>camera([p],plan,cut))),rawStage=events.flatMap(e=>eventStage(e,plan,cut));
 let stage=rawStage;if(cut.layout==='magazine')stage=[box(rawStage)];if(cut.layout==='newspaper')stage=newsStage(rawStage,plan,cut);stage=stage.map(p=>camera([p],plan,cut));
 if(!hold.length||!stage.length)fail('EMPTY_EDITORIAL_GEOMETRY','Full source drawing required');
 return {envelopes:hold,stageEnvelopes:stage,quality:qualityResult,sourceMapping:qualityResult.source};
}
function finalize({plan,cut,revision,stepDur,reachTail,explicitSize}){
 domain(cut);cut.placementUnits=true;cut.placementLayoutsC=true;
 const renderer=Object.create(J.Renderer.prototype),T=sourceClock(cut,plan),holdWindow=[cut.start+T,cut.end-cut.outDur];if(holdWindow[1]-holdWindow[0]<.04)fail('INSUFFICIENT_HOLD_WINDOW','Editorial source has not completed all required reveals before exit');
 const budget={recordCalls:1,reconstructed:0,cacheHits:0,rejected:0},native=record(renderer,plan,cut,T),expected=mapping(native,cut),base=prepare(renderer,plan,cut,T,expected,explicitSize,native,budget),evaluationRange=[Math.min(cut.start,cut.renderStart??cut.start)-stepDur,Math.max(cut.end,cut.displayEnd??cut.end)+reachTail],segments=[],cache=new Map();
 for(let i=0;i<plan.lyricAvoidanceIndex.regions.length;i++){
  const r=plan.lyricAvoidanceIndex.regions[i],end=Math.min(r.end??plan.lyricAvoidanceIndex.regions[i+1]?.start??plan.duration,plan.duration);if(r.start>=evaluationRange[1])break;if(end<=evaluationRange[0]||end<=r.start)continue;
  const circle={cx:r.center.x*plan.W,cy:r.center.y*plan.H,r:r.radius*short(plan)},attempts=[];let chosen=base,composition=null,solution,stageScope="new-crop-forbidden";
  for(const recipe of [null,...recipes(cut,explicitSize)]){let p=base;try{if(recipe){const key=JSON.stringify(recipe);if(!cache.has(key)){if(++budget.reconstructed>12)fail("CUT_CANDIDATE_BUDGET","Editorial source recipe reconstruction budget exhausted");try{cache.set(key,prepare(renderer,plan,{...cut,layoutCRecipe:recipe},T,expected,explicitSize,null,budget));}catch(e){budget.rejected++;cache.set(key,{error:{code:e.code,message:e.message}});}}else budget.cacheHits++;p=cache.get(key);if(p.error)fail(p.error.code,p.error.message);}
    const identity=!recipe&&A.clear(p.envelopes,circle,Math.max(2,.005*short(plan))),solved=identity?{status:"safe",offset:[0,0],reason:"native-identity-preserves-original-stage-crop"}:A.solveBasic(p.envelopes,circle,plan.W,plan.H,cut.seed,{fitBounds:A.bounds(p.stageEnvelopes)});attempts.push({strategy:recipe?.strategy||'native-joint-translation',recipe,status:solved.status,reason:solved.reason||null,quality:p.quality});if(!solution)solution=solved;if(solved.status==='safe'){solution=solved;chosen=p;composition=recipe;stageScope=identity?"native-identity":"new-crop-forbidden";break;}
   }catch(e){attempts.push({strategy:recipe?.strategy||'native-joint-translation',recipe,status:'rejected',reason:e.code||'DRAW_PROGRAM_ERROR',details:e.message});}}
  const safe=solution?.status==='safe';segments.push({start:r.start,end,region:r.id,circle,from:safe?solution.offset:[0,0],to:safe?solution.offset:[0,0],status:safe?'safe-hold':'insufficient-space',decision:safe?'certified-hold-adapter':'excluded-during-avoidance',failure:safe?null:'editorial-owned-source-candidate-family-exhausted',safetyScope:'editorial-source-entry-exit-relaxed',holdWindow,composition,stageScope,quality:chosen.quality,envelopes:chosen.envelopes,stageEnvelopes:chosen.stageEnvelopes,attempts});
 }
 return {version:1,kind:'layouts-c-source-native',revision,evaluationRange,holdWindow,units:[{owner:cut.layout+'.editorial-composition',envelopes:base.envelopes,segments}],measurementSupported:true,safety:segments.every(s=>s.status==='safe-hold')?'certified-hold-adapter':'insufficient-space',explicitSizePreserved:explicitSize,sourceProof:{sourceMapping:base.sourceMapping,stage:'Source-native all-event rectangle masks; completed partial paths; analytic outBack<=1.2, superscript/stamp scale hulls; newspaper signed-trig interval arithmetic over all entry scale/angles and exit displacement; camera/contentScale/ghost reserve. Stage containment includes relaxed entry/exit.',time:{entryFinish:T,exitStart:cut.dur-cut.outDur,hold:cut.hold,contentsActiveSchedule:cut.layout==='contents'?{count:cut.params.chunks.length,period:Math.max(.3,cut.dur*.92),envelope:'all active states enumerated from unchanged source'}:null},candidateBudget:{...budget,unique:cache.size,perCutRecipeLimit:12,perCutRecordLimit:128},ownership:'All real main, bodyRows/vbody fastRow copies, notes, metadata and plates primary; no auxiliary exemption'}};
}
function render({renderer,env,trajectory:tr}){
 const unit=tr.units[0],active=unit.segments.find(s=>s.start<=env.realTime&&env.realTime<s.end),safe=active?.status==='safe-hold',offset=safe?active.from:[0,0];
 if(safe&&active.composition){const cut={...env.cut,layoutCRecipe:active.composition};env=renderer.makeEnv(env.ctx,env.plan,cut,env.sc,{...env,cut});}
 const program=A.record(renderer,env);if(!program.measurementSupported)fail('UNSUPPORTED_DRAW_PROGRAM',JSON.stringify(program.diagnostics));const scale=env.scale||1,polygons=program.events.flatMap(e=>clipped(e)).map(p=>p.map(v=>[v[0]/scale,v[1]/scale])),inHold=env.t>=tr.holdWindow[0]&&env.t<=tr.holdWindow[1],covered=!safe||!inHold||polygons.every(p=>active.envelopes.some(q=>p.every(v=>contains(v,q)))),stageCovered=!safe||polygons.every(p=>active.stageEnvelopes.some(q=>p.every(v=>contains(v,q))));
 if(!covered)fail('ENVELOPE_VIOLATION','Editorial hold source ink escaped its certified interval envelope');if(!stageCovered)fail('STAGE_ENVELOPE_VIOLATION','Editorial source motion escaped its full entry/exit stage envelope');
 const moved=polygons.map(p=>p.map(v=>[v[0]+offset[0],v[1]+offset[1]])),contained=moved.every(p=>p.every(v=>v[0]>=0&&v[0]<=env.plan.W&&v[1]>=0&&v[1]<=env.plan.H));if(safe&&active.stageScope!=='native-identity'&&!contained)fail('STAGE_CONTAINMENT_VIOLATION','Certified editorial source introduced stage crop');const r=J.resolveAvoidanceAt(env.plan,env.realTime),circle=r?J.avoidanceCirclePixels(r,env.plan.W,env.plan.H):null,clear=!circle||!moved.length||A.clear(moved,circle,Math.max(2,.005*short(env.plan)));
 env.placementObservation?.({cut:env.cut.index,realTime:env.realTime,motionTime:env.t,pass:env.pass,offset,safety:!active?'safe':!safe?'conflict':clear?'safe':!inHold?'source-entry-exit-relaxed':'conflict',measurementSupported:true,envelopeCovered:covered,stageEnvelopeCovered:stageCovered,stageContained:contained,stageCropPreserved:!safe||contained||active.stageScope==="native-identity",stageScope:active?.stageScope,safetyScope:active?.safetyScope,polygons:moved,events:program.events.map(e=>({kind:e.kind,role:e.role,owner:e.owner,order:e.order,polygons:e.polygons}))});A.replay(env,program,offset);
}
for(const id of IDS)A.registerLayoutsCAdapter(id,{id:'c-editorial',finalize,render});
})();
