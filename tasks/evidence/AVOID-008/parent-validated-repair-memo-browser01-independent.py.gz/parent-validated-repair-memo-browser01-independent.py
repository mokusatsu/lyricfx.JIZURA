import pathlib,json,gzip,hashlib,subprocess,datetime,os
r=pathlib.Path('/workspace/avoid008-final-c34');m=pathlib.Path('/workspace/lyricfx.JIZURA');p=r/'tasks/evidence/AVOID-008/performance/validated-repair-memo-browser01';fixed='25da7a72b894ff823e596684814fa7481ce541cf';sha=lambda b:hashlib.sha256(b).hexdigest();raw=(p/'results.json.gz').read_bytes();assert sha(raw)=='9bd565af246d9a43116b12f19a8ee88b766368874359eb1d43f830542012b1a5';d=json.loads(gzip.decompress(raw));old=json.loads(gzip.decompress((r/'tasks/evidence/AVOID-008/performance/lazy-browser02/results.json.gz').read_bytes()));assert d['errors']==d['changedInputs']==d['changedPackageInputs']==[] and len(d['results']['rows'])==40 and len(d['results']['negatives'])==0
leaves=0;diff=[]
def cmp(a,b,path,row):
 global leaves
 if isinstance(a,dict):
  for k,v in a.items():cmp(v,b[k],path+'/'+k,row)
 elif isinstance(a,list):
  assert len(a)==len(b)
  for i,v in enumerate(a):cmp(v,b[i],path+'/'+str(i),row)
 else:
  leaves+=1
  if a!=b:diff.append((row,path,a,b))
for i,row in enumerate(d['results']['rows']):
 cmp(old['results']['rows'][i],row,'row',i)
 assert len(row['fast']['reads'])==2
 for j,read in enumerate(row['fast']['reads'],1):
  s=read['cache'];assert read['planningRecordCalls']==0 and s['hits']==j+1 and s['repairMemoFullReads']==s['repairMemoCompiles']==1 and s['repairMemoFastReads']==j and s['repairMemoFallbacks']==s['repairMemoCapped']==0
  assert all(read[k] for k in ['fullOutputIdentical','fullGraphAliasIdentical','allDescriptorsIdentical','fullyFrozen','freshFromAllEarlierReads'])
 assert row['coldSerializedPlan']==row['warmSerializedPlan']==row['fast']['serializedPlan']
 assert row['coldObjectGraph']==row['warmObjectGraph']==row['fast']['objectGraph']
 if 'coldFrames'in row:assert row['coldFrames']==row['warmFrames']==row['fast']['frames']
assert len(diff)==51 and all(path.endswith('/generation') and b==a+2*i for i,path,a,b in diff)
for pin in d['inputArchives']:
 packed=(r/pin['archive']).read_bytes();data=gzip.decompress(packed);assert sha(packed)==pin['archiveSHA256'] and sha(data)==pin['sha256'] and len(data)==pin['bytes'];assert data==(r/pin['path']).read_bytes();assert subprocess.check_output(['git','show',fixed+':'+pin['archive']],cwd=r)==packed
for pin in d['packagePins']+d['sourceGate']['productPins']:
 b=pathlib.Path(pin['path']);b=b if b.is_absolute() else r/b;data=b.read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256']
manifest=json.loads((p/'manifest01.json').read_bytes());assert sha((p/'manifest01.json').read_bytes())=='60027f413b3018917e39539191752d284c083bf847103274b8fd003b2886be67'
for pin in manifest['files']:
 data=(r/pin['path']).read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'];assert subprocess.check_output(['git','show',fixed+':'+pin['path']],cwd=r)==data
cleanup=json.loads((p/'cleanup-receipt01.json').read_bytes());w=cleanup['processWait'];assert w['pid']==w['waitpid']==d['runnerPID'] and w['kernelWaitStatus']==w['exitCode']==0 and w['WIFEXITED'] and w['reapedByWaitpid'] and w['afterProcStat'] is None and not pathlib.Path('/proc/'+str(w['pid'])).exists();assert not d['concurrency']['before']['jobs'] and not d['concurrency']['after']['jobs'];assert d['ownedCleanup']['browserCloseAwaited'] and d['ownedCleanup']['serverCloseAwaited']
frames=sum(len(x.get('coldFrames',[])) for x in d['results']['rows']);assert frames==18
receipt={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedEvidence':fixed,'rawSHA256':sha(raw),'normalPairs':40,'fastReads':80,'planningRecordCallsOnFast':0,'nativeFrames':{'cold':18,'warm':18,'fast':18},'oldRowLeaves':leaves,'oldCounterDifferences':diff,'counterDifferenceExplanation':'Each prior pair adds two real completed reads, hence edge generations increase by exactly2*rowIndex. All51 differing values retained; all other old fields exact.','inputArchivesExact':len(d['inputArchives']),'priorArchiveReferences':sum(x['action']=='reference-fixed-identical' for x in d['inputArchives']),'actualPackagePins':len(d['packagePins']),'productPins':len(d['sourceGate']['productPins']),'allFastJSONAliasDescriptorFreshFrozenChecks':True,'realExitReap':w,'browserServerAwaited':True,'decision':'Normal40 functional/native check accepted. No new visual change or separate human review for this internal memo. Original four compositions still pending human confirmation. Prepare original100 diagnostic next; no performance pass yet.','additionalSecurityAudit':'omitted per user','publicRequests':0,'parentImageViews':0}
out=m/'tasks/evidence/AVOID-008/parent-validated-repair-memo-browser01-review.json';out.write_text(json.dumps(receipt,indent=2)+'\n');(out.parent/'parent-validated-repair-memo-browser01-independent.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print(json.dumps({'normal40':True,'fast80':True,'native54':True,'oldLeaves':leaves,'onlyCounterDifferences':len(diff),'archives':len(d['inputArchives']),'manifestFiles':len(manifest['files']),'realExit0Reaped':True}))
