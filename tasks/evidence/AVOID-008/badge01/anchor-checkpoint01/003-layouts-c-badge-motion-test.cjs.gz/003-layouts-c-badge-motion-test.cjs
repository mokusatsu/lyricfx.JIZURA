'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'../..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const output=process.env.JIZURA_C_BADGE_MOTION_REPORT||'tasks/evidence/AVOID-008/badge01/motion01.json';assert(!fs.existsSync(root+'/'+output));
 const start=new Date().toISOString(),pins=['index.html','en/index.html','src/09a_placement.js','src/09b_basic_placement.js','src/09g_layoutsC_placement.js','src/11p_layoutsC.js','src/11z_layoutsC_transport.js','dev/avoidance/layouts-a-fixture.js','dev/avoidance/layouts-c-fixture.js',path.relative(root,__filename)].map(p=>({path:p,sha256:sha(fs.readFileSync(root+'/'+p))}));
 const server=http.createServer((req,res)=>{try{res.end(fs.readFileSync(req.url==='/font.otf'?'/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc':root+(req.url==='/'?'/index.html':req.url)));}catch{res.writeHead(404).end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;let browser;
 try{
  browser=await require('../browser.cjs').launch();const page=await browser.newPage();await page.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());await page.goto(base);await page.waitForFunction(()=>J?.ui?.plan);for(const f of ['layouts-a-fixture.js','layouts-c-fixture.js'])await page.addScriptTag({content:fs.readFileSync(__dirname+'/'+f,'utf8')});
  const result=await page.evaluate(async()=>{
   const A=J.placement,rows=[],negatives=[];
   for(const variant of ['hello','school']){
    const r=await runLayoutsCFixture(J,{layout:'nameTag',W:1080,H:1920,cy:.42,radius:.2,params:{variant}},{fontURL:location.origin+'/font.otf'}),cut=r.plan.cuts[0],tr=cut.placementTrajectory,seg=tr.units[0].segments[0],offset=seg.from,frames=[];
    for(let f=0;f<96;f++){const observations=[];r.renderer.frame(r.canvas.getContext('2d'),r.plan,f/24,{noHud:true,noPost:true,placementObservation:o=>observations.push({time:o.motionTime,entryCovered:o.badgeEntryEnvelopeCovered,entryContained:o.badgeEntryStageContained,exitCovered:o.exitEnvelopeCovered,exitContained:o.exitStageContained,stationary:o.stationaryEvents,moving:o.movingEvents})});frames.push({frame:f,observations});}
    const trialCut={...cut,layoutCRecipe:seg.composition},ctx=r.canvas.getContext('2d'),env=r.renderer.makeEnv(ctx,r.plan,trialCut,cut.palette,{pass:'main',t:1.5,realTime:1.5,lt:1.5,ltb:1.5,step:36,scale:1,allowFilter:false}),program=A.record(r.renderer,env),events=program.events.filter(e=>e.role==='primary'),models=events.map(e=>{const s=e.nativeCBody;return {kind:e.kind,entry:[s.pivot[0]-s.entryDX+offset[0],s.pivot[1]-s.entryDY+offset[1]],exit:[s.pivot[0]+s.dx+offset[0],s.pivot[1]+s.dy+offset[1]],entryTravel:[s.entryDX,s.entryDY],exitTravel:[s.dx,s.dy],entryAngle:s.angle-(s.angle+25),holdAngle:s.angle,exitAngle:s.angle+s.turn};});
    const rasters=[.125,.25,.5,1.5,3.75,3.875].map(t=>({stage:window.auditLayoutsCStage(r,t),circle:window.auditLayoutsCPrimary(r,t)}));
    rows.push({variant,safety:tr.safety,composition:seg.composition,offset,quality:seg.quality,entryProof:seg.badgeEntryProof,exitProof:seg.exitProof,frames,models,rasters});
   }
   for(const spec of [{label:'entry',offset:[0,-1200],time:.45,expected:'BADGE_LATE_ENTRY_CROP'},{label:'exit',offset:[0,1200],time:3.6,expected:'BADGE_EARLY_EXIT_CROP'}]){
    const r=await runLayoutsAFixture(J,{layout:'nameTag',W:1080,H:1920,cy:.42,radius:.2,params:{variant:'school'}},{newPath:false,fontURL:location.origin+'/font.otf'}),solver=A.solveBasic;let calls=0;try{A.solveBasic=()=>{calls++;return {status:'safe',offset:spec.offset,direction:'forged-test-only'};};r.plan=J.finalizePlacementPlan(r.plan,{layoutsC:true});}finally{A.solveBasic=solver;}
    let code=null;try{r.renderer.frame(r.canvas.getContext('2d'),r.plan,spec.time,{noHud:true,noPost:true});}catch(e){code=e.code;}negatives.push({...spec,calls,code,knownSource:A.layoutsCSourceKnown('nameTag'),knownRenderer:A.layoutsCTransportKnown(r.renderer)});
   }
   return {rows,negatives};
  });
  for(const p of pins)assert.equal(sha(fs.readFileSync(root+'/'+p.path)),p.sha256);
  fs.writeFileSync(root+'/'+output,JSON.stringify({start,end:new Date().toISOString(),pins,...result,scope:'Two portrait normal r=.2 explicit source-specific screen-anchor candidates. 96 native-clock runtime frames each; per-event native entry clear suffix/exit clear prefix; source-tag centre endpoints/direction; helper-rebound all-owned sampled raster. Numeric only; visual unaccepted. Forged solver positives must be refused before replay.'},null,2));
  console.log(JSON.stringify({rows:result.rows.map(r=>({variant:r.variant,safety:r.safety,recipe:r.composition,events:r.models.length,frames:r.frames.length,rasters:r.rasters})),negatives:result.negatives}));
  for(const r of result.rows){assert.equal(r.safety,'certified-hold-adapter');assert(r.composition.anchorConnect&&r.composition.badgeMeasure===1&&!r.composition.writingMeasure);assert(r.models.length>0);assert(r.frames.filter(f=>f.frame>=12&&f.frame<=84).every(f=>f.observations.length>0));for(const m of r.models){assert(Math.abs(m.entry[0]-540)<1e-8&&Math.abs(m.entry[1]-(960-1920*.35))<1e-8);assert(Math.abs(m.exit[0]-(540+1080*.1))<1e-8&&Math.abs(m.exit[1]-(960+1920*.5))<1e-8);assert(m.entryTravel[1]>=0&&m.exitTravel[0]>=0&&m.exitTravel[1]>=0);assert.equal(m.entryAngle,-25);assert(Math.abs(m.exitAngle-m.holdAngle-18)<1e-8);}for(const f of r.frames)for(const o of f.observations)assert(o.entryCovered&&o.entryContained&&o.exitCovered&&o.exitContained);assert(r.rasters.every(a=>a.stage.visible>0&&a.stage.outside===0&&a.circle.strict.collision===0&&a.circle.strict.marginCollision===0));}
  assert(result.negatives.every(n=>n.calls>0&&n.code===n.expected&&n.knownSource&&n.knownRenderer));
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
