import pathlib,json,gzip,hashlib,subprocess,sys,base64,datetime
r=pathlib.Path('/workspace/avoid008-final-c34');m=pathlib.Path('/workspace/lyricfx.JIZURA')
new=sys.argv[1];old='d298d6ab5227f0a6d5d984b05297a988580f53ed'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda c,f:subprocess.check_output(['git','show',c+':'+f],cwd=r)
files=subprocess.check_output(['git','ls-tree','-r','--name-only',new,'src'],cwd=r,text=True).splitlines();files=[f for f in files if f.endswith('.js')];assert len(files)==84
changed=['src/09a_placement.js','src/09g_layoutsC_placement.js'];sources={f:git(new,f) for f in files}
assert all(git(old,f)==sources[f]==(r/f).read_bytes() for f in files if f not in changed)
assert all(sources[f]==(r/f).read_bytes() for f in changed)
compiled=[];ns={};exec(compile(git(new,'app/english.py'),'fixed-english.py','exec'),ns)
img='data:image/png;base64,'+base64.b64encode(git(new,'assets/effect-preview.png')).decode()
for html in ['index.html','en/index.html']:
 h=git(new,html);assert h==(r/html).read_bytes();reverse=h
 for f in changed:assert reverse.count(sources[f])==1;reverse=reverse.replace(sources[f],git(old,f))
 assert reverse==git(old,html)
 script='\n'.join(ns['localize_js'](sources[f].decode(),f) if html.startswith('en/') else sources[f].decode() for f in files)
 if html.startswith('en/'):
  mark='/* ============================================================\n   JIZURA — editor UI';assert script.count(mark)==1;script=script.replace(mark,git(new,'app/english.js').decode()+'\n'+mark,1)
 assert h.count(script.replace('__EFFECT_PREVIEW_IMAGE__',img).encode())==1
 compiled.append({'path':html,'sha256':sha(h),'all84ModulesExact':True,'reverseToOldHTMLExact':True})
p=r/'tasks/evidence/AVOID-008/performance/native-local-bounds-memo01'
summary=json.loads((p/'pure06.summary.json').read_bytes());assert summary['passed'] and summary['caseCount']==46
raw=(p/'pure06.raw.json.gz').read_bytes();assert sha(raw)==summary['rawSHA256'];assert raw==pathlib.Path('/tmp/avoid008-local-bounds-parent-pure01/pure05.raw.json.gz').read_bytes()
d=json.loads(gzip.decompress(raw));assert len(d['cases'])==46
for row in d['cases']:assert row['old']==row['candidate'] and row['oldReads']==row['candidateReads']
manifest=json.loads((p/'manifest01.json').read_bytes());count=0
for group in ['inputs','results']:
 for pin in manifest[group]:
  b=(r/pin['path']).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256'];assert git(new,pin['path'])==b;count+=1
receipt={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':'/root','source':new,'basis':old,'sourcePins':{f:sha(sources[f]) for f in changed},'other82SourcesExact':True,'compiled':compiled,'normalPureRerun':{'cases':46,'exitCode':0,'rawByteExact':True,'rawSHA256':sha(raw),'command':'node dev/avoidance/layouts-c-native-local-bounds-memo-pure.cjs /tmp/avoid008-local-bounds-parent-pure01','note':'Actual bridge returned in both runs; final added undefined-return fallback leaves this execution unchanged.'},'manifestPins':count,'review':'Read both source diffs. Fingerprint only selects candidate; all coordinates and pad use Object.is, including signed zero. Miss runs original local hull/bounds; hit returns fresh four-scalar object. World transform, second hull, native program and replay untouched. Retains copied numeric coordinates/scalars only; separate 512-entry/1048576-slot/8192-point caps and LRU accounting. Existing clear/stats bridge captures private closures, no new public callable. Existing old standalone installer stub preserved by private fallback. Ordinary nonstock or cap conditions execute original algorithm. Existing final-cache admission, second context verification, keys, codec, budgets, freeze and signature unchanged.','decision':'Source and normal pure accepted; paired local browser and new performance measurement remain required. No performance pass claimed.','additionalSecurityAudit':'not performed, per user instruction','publicRequests':0,'parentImageViews':0}
out=m/'tasks/evidence/AVOID-008/parent-native-local-bounds-memo01-source-review.json';out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');out.with_name('parent-native-local-bounds-memo01-independent.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'accepted':True,'normalCases':46,'pins':count,'source':new}))
