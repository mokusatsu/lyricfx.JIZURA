import pathlib,json,gzip,hashlib,subprocess,datetime,math
root=pathlib.Path('/workspace/avoid008-final-c34');main=pathlib.Path('/workspace/lyricfx.JIZURA');base=root/'tasks/evidence/AVOID-008/performance';p=base/'immutable-edge-lazy-diagnose01';fixed='d256228e650382e560ce941310490581837c079d'
sha=lambda b:hashlib.sha256(b).hexdigest();unzip=lambda p:gzip.decompress(p.read_bytes());git=lambda f:subprocess.check_output(['git','show',fixed+':'+f],cwd=root)
raw=unzip(p/'results.raw.json.gz');assert sha(raw)=='734d42c172b955518ca618e831829969884ddb583019abff47b50b910a1db0ba' and raw==(p/'results.json').read_bytes()
assert (p/'results.raw.json.gz').read_bytes()==git('tasks/evidence/AVOID-008/performance/immutable-edge-lazy-diagnose01/results.raw.json.gz')
r=json.loads(raw);support=json.loads((p/'support-receipt.json').read_bytes());wait=json.loads((p/'wait-result.json').read_bytes());old=json.loads(unzip(base/'immutable-edge-diagnose01/results.raw.json.gz'))
assert not r['errors'] and not r['changedInputs'] and not r['formalExecuted'] and not r['passed'] and r['diagnosticCompleted']
for k in ['countsValid','candidateFullCoverage','actualPipelineValid','pinnedFontCorpusQualified','inputParity']:assert r[k],k
assert r['candidate']['sha256']=='c99e0d913eb6e99e50f036c1ca8e5a6f1fda4b186396cec7b6908ad241124546'
assert len(r['pins'])==120
for f,h in r['pins'].items():assert sha(unzip(p/('input-'+f.replace('/','__')+'.gz')))==h==sha((root/f).read_bytes()),f
assert unzip(p/'baseline2bb-index.html.gz')==subprocess.check_output(['git','show','2bb3f864b5d40361961d8ad2aabeec24bfb5d1cb:index.html'],cwd=root)
assert support['runnerPID']==wait['pid']==wait['waitedPID']==369130 and wait['kernelWaitStatus']==wait['exitCode']==support['runnerExitCode']==0 and wait['normalExit'] and wait['signal'] is None
assert not pathlib.Path('/proc/369130').exists()
assert len(support['packagePins'])==173 and len(support['productPins'])==86
for x in support['packagePins']+support['productPins']:
    f=pathlib.Path(x['path']);f=f if f.is_absolute() else root/f;assert sha(f.read_bytes())==x['sha256']
for x in support['inputs']:
    b=unzip(p/('support-input-'+x['path'].replace('/','__')+'.gz'));assert sha(b)==x['sha256'] and len(b)==x['bytes'] and b==(root/x['path']).read_bytes()
assert sha(unzip(p/'support-preload.cjs.gz'))==support['preload']['sha256']=='53ad80f91ac5b3a74a6f6e7d617c3006a407aec3ce07840af5427f6e39e20db4'
assert not support['violations'] and not support['changedPackagePins'] and not support['changedProductPins'] and not support['changedGateInputs']
assert not support['before']['jobs'] and not support['after']['jobs'] and all(not x['foreign'] for x in r['concurrency'])
assert support['reserveBytes']==250*1024*1024 and min([support['diskBeforeBytes'],support['diskAfterBytes'],*[x['availableBytes'] for x in support['resourceSamples']]])>=support['reserveBytes']
e=support['runtime']['environment'];assert e['observations_current'] and e['spec_revision']==e['observed_spec_revision']=='215'
checks=['cuts','states','observations','fontQualification','projectSHA256','normalizedInputSHA256','allIterationInputSHA256','regionAudit','idCounts','renderIDs','renderCalls','planningCalls','counts']
p95=lambda xs:sorted(xs)[math.ceil(len(xs)*.95)-1]
sides=[]
for side in r['sides']:
    prev=next(x for x in old['sides'] if x['side']==side['side'] and x['on']==side['on'])
    for k in checks:assert side[k]==prev[k],(side['side'],side['on'],k)
    assert len(side['frames'])==80 and len(side['measuredRender'])==64 and len(side['measuredPlanning'])==1 and len(side['renderIDs'])==34
    assert len(side['parts'])==4 and sum(x['warmup'] for x in side['parts'])==3 and side['counts']['actualCuts']==side['counts']['regions']==100
    assert not side['renderErrors']
    if side['side']=='candidate' and side['on']:
        assert side['counts']['staged']==100 and side['renderCalls']=={'record':80,'replay':80} and len(side['observations'])==80
        assert side['fontQualification']['complete'] and not side['fontQualification']['unknown']
    final=side['parts'][-1];assert abs(final['sourceMs']+final['finalizeMs']-final['totalMs'])<1e-6
    sides.append({'side':side['side'],'on':side['on'],'sourceMs':final['sourceMs'],'finalizeMs':final['finalizeMs'],'planningPointMs':side['measuredPlanning'][0],'renderP95Ms':p95(side['measuredRender']),'actualRenderCalls':side['renderCalls'],'observations':len(side['observations'])})
comparisons=[]
for c in r['comparisons']:
    b=next(s for s in sides if s['side']=='baseline' and s['on']==c['on']);v=next(s for s in sides if s['side']=='candidate' and s['on']==c['on']);ratio=v['planningPointMs']/b['planningPointMs'];delta=v['renderP95Ms']-b['renderP95Ms']
    assert abs(ratio-c['planningRatio'])<1e-9 and abs(delta-c['additionalRenderP95Ms'])<1e-9
    comparisons.append({'on':c['on'],'ratio':ratio,'additionalRenderP95Ms':delta,'diagnosticLimitsMet':ratio<=2 and delta<=3})
out={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedEvidenceCommit':fixed,'candidateProductSource':'3b0c995a2c912cf3edf6583f372c215c310e11f0','exactPrettyRawSHA256':sha(raw),'runnerInputArchivesLiveSHAExact':120,'productPins':86,'actualPackagePins':173,'supportInputsExact':3,'actualFourSides':sides,'independentlyRecomputedComparisons':comparisons,'oldFunctionalFieldsByteValueExact':checks,'actualPID':369130,'actualWaitPID':wait['waitedPID'],'kernelWaitStatus':wait['kernelWaitStatus'],'independentPIDAbsent':True,'browserServerCloseEvidence':'Original runner source finally awaits browser.close/server.close before reached post concurrency; support after0live and process wait/reap.','prePostForeignJobs':[0,0],'duringMechanicalMainThreadGuarantee':False,'resourceScope':'Parent operational exclusive lease, original monitor blind spot retained and disclosed; all reserve samples>=250MiB.','currentSpec':'215','performanceDecision':'ON planning2.181992x/render+5.200000ms unmet; OFF diagnostic points within limits. Diagnostic not qualified planningp95/formal1000. Main adoption remains blocked. New read-only private freeze and nativePath capture designs requested; no repeat/profile authorized.','newTimingEdgeHitCounts':None,'edgeCountLimitation':'Current performance fixture does not capture private edge hits; browser02 actual25008hits/176q is separate.','publicRequests':0,'parentImageViews':0}
target=main/'tasks/evidence/AVOID-008/parent-immutable-edge-lazy-diagnose01-review.json';assert not target.exists();target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'receipt':str(target),'comparison':comparisons,'all120And173Verified':True}))
