from pathlib import Path
import json,gzip,hashlib,collections
r=Path('/workspace/avoid008-final-c34');p=r/'tasks/evidence/AVOID-008/performance/own-slot-original-pipeline-profile01';sha=lambda d:hashlib.sha256(d).hexdigest();raw=(p/'results.json.gz').read_bytes();d=json.loads(gzip.decompress(raw));s=d['sides'][0];result=s['pipeline']['result'];reference=json.loads(gzip.decompress((r/'tasks/evidence/AVOID-008/performance/own-slot-repair-formal01/results.json.gz').read_bytes()));ref=next(x for x in reference['sides']if x['n']==1000 and x['on'] and x['side']=='candidate');assert len(d['errors'])==1 and 'weight>=0' in d['errors'][0]['message'];assert s['partialWrapperCounts']=={'sourceCalls':9,'finalCalls':9,'restored':True};assert s['pipeline']['calls']=={'source':9,'final':9};assert result['counts']==ref['counts'];assert result['observations']==ref['observations'];assert [{k:v for k,v in x.items()if k!='ms'}for x in result['frames']]==[{k:v for k,v in x.items()if k!='ms'}for x in ref['frames']];assert result['projectSHA256']==ref['projectSHA256'] and result['allIterationInputSHA256']==ref['allIterationInputSHA256'];assert result['renderCalls']=={'record':80,'replay':80} and not result['renderErrors'] and result['fontQualification']['complete'];assert len(result['parts'])==9 and len(result['measuredPlanning'])==6 and len(result['measuredRender'])==64
for x in d['inputArchives']:
 z=(r/x['archive']).read_bytes();b=gzip.decompress(z);assert sha(z)==x['archiveSHA256'];assert sha(b)==x['sha256']==d['pins'][x['path']];assert b==(r/x['path']).read_bytes()
for x in d['gate']['packagePins']+d['gate']['productPins']:
 f=Path(x['path']);f=f if f.is_absolute()else r/f;assert sha(f.read_bytes())==x['sha256']
cpuBytes=gzip.decompress((p/s['cpu']['path']).read_bytes());assert sha(cpuBytes)==s['cpu']['rawSHA256'];assert sha((p/s['cpu']['path']).read_bytes())==s['cpu']['gzipSHA256'];cpu=json.loads(cpuBytes);nodes={n['id']:n for n in cpu['nodes']};parents={c:n['id']for n in cpu['nodes']for c in n.get('children',[])};chains={}
for i in nodes:
 v=i;c=[];seen=set()
 while v in nodes:assert v not in seen;seen.add(v);c.append(nodes[v]['callFrame']['functionName']);v=parents.get(v)
 chains[i]=c
negative=[x for x in cpu['timeDeltas']if x<0];assert negative==[-1,-2,-61,-2,-1];assert len(cpu['samples'])==len(cpu['timeDeltas'])==373600
it=-1;last=None;allph=collections.Counter();per=[collections.Counter()for _ in range(9)];tops=collections.Counter();outside=collections.Counter();groups=[]
for idx,dt in zip(cpu['samples'],cpu['timeDeltas']):
 c=chains[idx];f=nodes[idx]['callFrame'];phase='source'if 'profileSource'in c else 'final'if 'profileFinal'in c else 'render'if any(x in c for x in ['frame','J.Renderer.frame']) else 'outside'
 if phase=='source':
  if last!='source':it+=1;groups.append({'iteration':it,'firstNode':idx})
  last='source'
 elif phase=='final':last='final'
 assert it<9
 allph[phase]+=dt
 if phase in ['source','final']:
  assert it>=0;per[it][phase]+=dt
  if it>=3:
   if phase=='source':tops[(f['functionName'],f['url'],f['lineNumber'],f['columnNumber'])]+=dt
   else:
    cat=next((label for name,label in [('readCompletedPayload','restore'),('freezeDecodedPlan','freeze'),('cacheDependencies','dependencies'),('cacheEncode','keyEncode'),('signature','signature'),('edgeRegisterFinal','edges')]if name in c),'other');per[it]['final:'+cat]+=dt
 elif phase=='outside':outside[f['functionName']]+=dt
assert it==8 and len(groups)==9
summary={'rawSHA256':sha(raw),'CPUrawSHA256':sha(cpuBytes),'CPUgzipSHA256':s['cpu']['gzipSHA256'],'inputArchives':len(d['inputArchives']),'packages':len(d['gate']['packagePins']),'products':len(d['gate']['productPins']),'allOriginalPipelineSavedResultChecks':True,'originalKernelFailurePreserved':'aggregate rejects5negative deltas, not a pipeline error; assertions after aggregate independently checked offline','signedNegativeDeltas':negative,'negativeSumUs':sum(negative),'absoluteNegativeMagnitudeUs':-sum(negative),'samples':len(cpu['samples']),'allPhaseSignedUs':dict(allph),'perIterationAncestorSignedUs':[dict(x)for x in per],'measuredFinalCategoriesSignedUs':dict(sum((x for x in per[3:]),collections.Counter())),'measuredSourceTopSelfSignedUs':[{'function':k[0],'url':k[1],'lineZero':k[2],'columnZero':k[3],'signedUs':v}for k,v in tops.most_common(16)],'outsideSignedUs':dict(outside),'limitations':'No negative sample dropped/clamped; signed sample estimates with67us negative magnitude. Named wrapper phase alternation labels9calls; GC/control without wrapper ancestry stays outside, no per-call causal assignment. Profiling is not performance qualification; no cross230/231 causality.'}
Path('/tmp/parent-original-pipeline-profile-summary.json').write_text(json.dumps(summary,indent=2)+'\n');

import subprocess,datetime,base64
fixed='762deb4';w=json.loads(gzip.decompress((p/'execution.json.gz').read_bytes()));assert w['runnerPID']==d['runnerPID']==410259 and w['kernelExitCode']==1 and w['reaped'] and w['runnerGone'] and not Path('/proc/410259').exists();assert not w['before']['jobs'] and not w['after']['jobs'] and not d['concurrency']['before']['jobs'] and not d['concurrency']['after']['jobs'];assert d['ownedCleanup']=={'browserCloseAwaited':True,'serverCloseAwaited':True};assert not d['changedInputs'] and not d['changedPackages'];assert w['diskAvailableBytes']>=262144000
for x in d['inputArchives']:assert gzip.decompress((r/x['archive']).read_bytes())==subprocess.check_output(['git','show',fixed+':'+x['path']],cwd=r)
mp=json.loads((p/'source84-line-map.json').read_text());html=(r/'index.html').read_text();u=html.encode('utf-16-le');preview='data:image/png;base64,'+base64.b64encode((r/'assets/effect-preview.png').read_bytes()).decode();assert len(mp['modules'])==84
for x in mp['modules']:
 raw=(r/x['path']).read_bytes();text=raw.decode().replace('__EFFECT_PREVIEW_IMAGE__',preview);assert sha(raw)==x['sha256'];assert u[x['startUTF16Offset']*2:x['endUTF16Offset']*2].decode('utf-16-le')==text;start=u[:x['startUTF16Offset']*2].decode('utf-16-le').count('\n');assert start==x['startLineZeroBased'];assert start+text.count('\n')==x['endLineZeroBased']
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',fixed,str(p.relative_to(r))],cwd=r,text=True).splitlines():assert (r/name).read_bytes()==subprocess.check_output(['git','show',fixed+':'+name],cwd=r)
summary.update(fixedEvidence=fixed,parent='/root',actualKernel={'pid':410259,'startTicks':w['runnerStartTicks'],'exit':1,'expectedAggregateExceptionPreserved':True,'reaped':True,'gone':True,'awaitedClose':True,'prePostLiveJobs':0,'postSaveBytes':w['diskAvailableBytes']},all84UTF16LineMapsIndependentlyVerified=True,decision='Usable diagnostic raw and independently verified saved workload despite original aggregate failure. Measured source composeLyricArea735141us motivates exact arithmetic array-allocation reduction; no performance qualification or GC causal attribution. Main product unadopted/four human cases pending.',publicRequests=0,parentImageViews=0,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
out=Path('/workspace/lyricfx.JIZURA/tasks/evidence/AVOID-008/parent-own-slot-original-pipeline-profile01-review.json');out.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'reviewed':True,'archives':112,'lineMaps':84,'kernelFailurePreserved':1,'negativeSignedUs':-67,'warmSourceUs':summary['measuredFinalCategoriesSignedUs']['source'],'composeSelfUs':735141}))
