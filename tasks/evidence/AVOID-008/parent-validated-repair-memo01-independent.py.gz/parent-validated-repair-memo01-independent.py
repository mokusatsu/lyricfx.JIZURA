import pathlib,json,subprocess,hashlib,gzip,datetime,base64
r=pathlib.Path('/workspace/avoid008-final-c34');m=pathlib.Path('/workspace/lyricfx.JIZURA');p=r/'tasks/evidence/AVOID-008/performance/validated-repair-memo01'
old='d256228e650382e560ce941310490581837c079d';new='ccfe825b2d9df2f507cf55978be47f5183c9c0c9'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda c,f:subprocess.check_output(['git','show',c+':'+f],cwd=r)
files=subprocess.check_output(['git','ls-tree','-r','--name-only',new,'src'],cwd=r).decode().splitlines();files=[f for f in files if f.endswith('.js')];assert len(files)==84
f='src/09g_layoutsC_placement.js';a=git(old,f);b=git(new,f);assert (r/f).read_bytes()==b and sha(b)=='7bd1bf38c573f1341fbd6a90b63273535405cd79e507ed7063db99d2cfb5642b'
x=b'function payloadDecode(text){';assert a[a.index(x):a.index(b'// Only decoded completed-plan')]==b[b.index(x):b.index(b'// Latest private completed-entry')]
sources={x:git(new,x) for x in files};assert all(git(old,x)==sources[x]==(r/x).read_bytes() for x in files if x!=f)
ns={};exec(compile(git(new,'app/english.py'),'fixed-app-english.py','exec'),ns)
image='data:image/png;base64,'+base64.b64encode(git(new,'assets/effect-preview.png')).decode();compiled=[]
for html in ['index.html','en/index.html']:
 h=git(new,html);assert h==(r/html).read_bytes() and h.count(b)==1 and h.replace(b,a)==git(old,html)
 script='\n'.join(ns['localize_js'](sources[x].decode(),x) if html.startswith('en/') else sources[x].decode() for x in files)
 if html.startswith('en/'):
  marker='/* ============================================================\n   JIZURA — editor UI';assert script.count(marker)==1;script=script.replace(marker,git(new,'app/english.js').decode()+'\n'+marker,1)
 script=script.replace('__EFFECT_PREVIEW_IMAGE__',image);assert h.count(script.encode())==1
 compiled.append({'path':html,'sha256':sha(h),'all84TransformedModulesJoinedExact':True,'fullReverseExact':True})
raw=(p/'pure05.raw.json.gz').read_bytes();report=json.loads(gzip.decompress(raw));assert report['passed'] and len(report['cases'])==165 and len(report['lifecycle'])==5 and report['inputs']==report['endInputs']
for pin in report['inputs']: assert sha((r/pin['path']).read_bytes())==pin['sha256']
for file in ['pure05.raw.json.gz','pure05.summary.json']:
 assert (p/file).read_bytes()==(pathlib.Path('/tmp/avoid008-memo-parent-pure01')/file).read_bytes()
for case in report['cases'][:162]:
 s=case['stats'];assert s['repairMemoFastReads']==s['repairMemoFullReads']*2 and s['repairMemoFallbacks']==0
assert [c['label'] for c in report['cases'][-3:]]==['cap-repairs','cap-slots','cap-chars']
manifest=json.loads((p/'manifest01.json').read_bytes());assert sha((p/'manifest01.json').read_bytes())=='6485cecdb0fa023fa7464f836a44362e8e7bfaf1ad00f3d41cdd1c6ccbdfcd0e'
for pin in manifest['inputs']+manifest['results']:
 data=(r/pin['path']).read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'];assert git(new,pin['path'])==data
receipt={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':old,'source':new,'productCommit':'3166516a48449703c3a4b0f879d5ee418978f785','sourceSHA256':sha(b),'other83SourceGitAndLiveExact':True,'genericPayloadDecodeByteExact':True,'compiled':compiled,'manifestSHA256':sha((p/'manifest01.json').read_bytes()),'manifestInputs':len(manifest['inputs']),'manifestResults':len(manifest['results']),'normalPureRerunExit':0,'normalCases':165,'eachNormalReads':'one full plus two fast; cap cases three full','lifecycle':report['lifecycle'],'rawAndSummaryRerunByteExact':True,'review':'Entry identity and immutable wire bind the latest-only private path/repair memo. First read remains the full old decoder. Each fast read creates an independent fresh parse tree, preserves repair order and uses the old guard; caps and errors use old decoder. No key, verification, normal freeze/signature, geometry, edge, pipeline or performance threshold changes. Normal output/descriptors/alias/freshness and actual replacement/eviction/clear checked. No new cybersecurity matrix performed.','decision':'Source and normal pure accepted. Prepare one normal forty-condition fast-read browser check next; no performance acceptance or AVOID-008 completion. Existing timing failure retained.','browserExecuted':False,'newSecurityAudit':'omitted per user instruction','publicRequests':0,'parentImageViews':0}
out=m/'tasks/evidence/AVOID-008/parent-validated-repair-memo01-source-review.json';assert not out.exists();out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out.parent/'parent-validated-repair-memo01-independent.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));print(json.dumps({'source83Exact':True,'compiled84JAEN':True,'pure165':True,'lifecycle5':True,'manifestPins':len(manifest['inputs'])+len(manifest['results'])}))
