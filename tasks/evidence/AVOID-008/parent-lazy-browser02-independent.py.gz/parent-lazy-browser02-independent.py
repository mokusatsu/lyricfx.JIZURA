import pathlib,json,gzip,hashlib,datetime,collections
root=pathlib.Path('/workspace/avoid008-final-c34');main=pathlib.Path('/workspace/lyricfx.JIZURA');base=root/'tasks/evidence/AVOID-008/performance';p=base/'lazy-browser02'
sha=lambda b:hashlib.sha256(b).hexdigest();raw=gzip.decompress((p/'results.raw.json.gz').read_bytes()) if (p/'results.raw.json.gz').exists() else (p/'results.json').read_bytes();r=json.loads(raw);old=json.loads(gzip.decompress((base/'immutable-edge-browser02/results.raw.json.gz').read_bytes()))
assert not r['errors'] and not r['changedInputs'] and not r['changedPackageInputs']
assert r['ownedCleanup']=={'browserCloseAwaited':True,'serverCloseAwaited':True,'runnerPID':367950}
stat=pathlib.Path('/proc/367950/stat').read_text();tail=stat[stat.rfind(')')+2:].split();assert tail[0]=='Z' and tail[1]=='1' and tail[19]=='9715548' and tail[49]=='0'
runner={'pid':367950,'startTicks':tail[19],'live':False,'gone':False,'state':tail[0],'ppid':1,'linuxStatField52WaitStatus':int(tail[49]),'osExitCode':0,'originalExecSession':'Unknown process id on resumed session33009; not fabricated as tool-returned exit0','rawLinuxStat':stat,'reapedOrKilled':False}
assert not r['concurrency']['before']['jobs'] and not r['concurrency']['after']['jobs']
archives=[]
for f,h in r['pins'].items():
    b=gzip.decompress((p/('input-'+f.replace('/','__')+'.gz')).read_bytes());assert sha(b)==h and b==(root/f).read_bytes(),f;archives.append(f)
assert len(archives)==110
assert len(r['packagePins'])==173 and len({x['path'] for x in r['packagePins']})==173
for x in r['packagePins']:
    b=pathlib.Path(x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
differences=[];added=[];old_leaf=[0]
def walk(a,b,path):
    if isinstance(a,dict):
        assert isinstance(b,dict)
        for k in a:assert k in b;walk(a[k],b[k],path+'/'+k)
        added.extend(path+'/'+k for k in b.keys()-a.keys())
    elif isinstance(a,list):
        assert isinstance(b,list) and len(a)==len(b)
        for i,(x,y) in enumerate(zip(a,b)):walk(x,y,path+'/'+str(i))
    else:
        old_leaf[0]+=1
        if a!=b:differences.append({'path':path,'before':a,'after':b})
walk(old['results'],r['results'],'results');walk(old['registrySchema'],r['registrySchema'],'registrySchema')
assert {x['path'] for x in differences}=={'registrySchema/'+x for x in ['normalHTMLSHA256','schemaHTMLSHA256','normalHTMLBytes','schemaHTMLBytes']}
assert len(added)==468
names=['upfrontReads','snapshotPointRefs','reservedCoordinateSlots','coordinateDescriptorReads','edgeCoordinateReads','preparedPolygons','preparedEdges','registrationBypasses','preparationBypasses']
assert collections.Counter(x.rsplit('/',1)[1] for x in added)==collections.Counter({k:52 for k in names})
normal=(root/'index.html').read_bytes();schema=gzip.decompress((p/'registry-schema.html.gz').read_bytes())
assert sha(normal)==r['registrySchema']['normalHTMLSHA256'] and len(normal)==r['registrySchema']['normalHTMLBytes']
assert sha(schema)==r['registrySchema']['schemaHTMLSHA256'] and len(schema)==r['registrySchema']['schemaHTMLBytes']
rows=r['results']['rows'];assert len(rows)==40 and len(r['results']['negatives'])==28
selected=[];stats_count=0
for row in rows:
    for key,s in row['edgeStats'].items():
        stats_count+=1;assert all(isinstance(s[k],int) and s[k]>=0 for k in names)
        assert s['snapshotPointRefs']==s['edges'] and s['reservedCoordinateSlots']==2*s['edges'] and s['upfrontReads']+s['reservedCoordinateSlots']==s['slots']
        assert s['coordinateDescriptorReads']==2*s['preparedEdges'] and s['edgeCoordinateReads']==6*s['preparedEdges'] and s['preparedPolygons']==s['validations']
        assert 0<=s['preparedEdges']<=s['edges']<=65536 and 0<=s['preparedPolygons']<=s['polygons']<=8192 and s['slots']<=131072
        assert s['rejected']==s['registrationBypasses']==s['preparationBypasses']==0
        if key!='afterWarmRender':assert s['preparedEdges']==s['preparedPolygons']==s['coordinateDescriptorReads']==s['edgeCoordinateReads']==0
    if 'afterWarmRender' in row['edgeStats']:
        a=row['edgeStats']['afterWarm'];b=row['edgeStats']['afterWarmRender']
        selected.append({'layout':row['spec']['layout'],'spec':row['spec'],'registeredPolygons':b['polygons'],'registeredEdges':b['edges'],'preparedPolygons':b['preparedPolygons'],'preparedEdges':b['preparedEdges'],'actualTrackedUpfrontReads':b['upfrontReads'],'actualCoordinateDescriptorReads':b['coordinateDescriptorReads'],'actualEdgeCoordinateReads':b['edgeCoordinateReads'],'warmHitDelta':b['hits']-a['hits']})
assert stats_count==52 and sum(x['warmHitDelta'] for x in selected)==25008 and sum(x['preparedPolygons'] for x in selected)==176
assert sum(x['coldCalls'] for x in rows)==419 and sum(x['warmCalls'] for x in rows)==0
out={'parent':'/root','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'raw reviewed; pending child fixed evidence commit','productSource':'3b0c995a2c912cf3edf6583f372c215c310e11f0','driverSHA256':'30ba3b8d96da98ac7009c691b5125313bfb5aeb00e995c5dfc977926031494a0','originalPrettyRawBytes':len(raw),'originalPrettyRawSHA256':sha(raw),'actualInputArchivesAndLiveExact':archives,'actualPackageFilesAndLiveExact':173,'oldLeafComparisons':old_leaf[0],'expectedSourceMetadataChanges':differences,'allOldFunctionalAndLedgerFieldsExact':True,'additiveStats':{'states':52,'fields':names},'rows':40,'negatives':28,'coldPlanningRecords':419,'warmPlanningRecords':0,'nativeColdAndWarmFramesOldExact':[18,18],'nativeColdAndWarmObservationsOldExact':[15,15],'selectedActualPreparation':selected,'totalActualWarmHits':25008,'totalPreparedPolygons':176,'totalPreparedEdges':sum(x['preparedEdges'] for x in selected),'actualRenderRecordReplayCounters':None,'counterLimitation':'Planning records are actual419/0; independent render record/replay counters are not retained in this browser driver. Saved100 pure forced all-preparation is separate.','runnerCleanup':runner,'parentHarnessCorrection':'Initial runner-gone assumption failed on a non-live PID1 zombie. Exact identity and actual Linux stat field52 wait status0 were independently read instead. No extra run/kill/reap or invented exec-return result.','prePostForeignJobs':[0,0],'zombiesSeparate':[len(r['concurrency'][k]['zombies']) for k in ['before','after']],'browser01':'Unexecuted suite, parent package ordering failure retained separately.02 is first actual lazy suite.','publicRequests':0,'parentImageViews':0}
target=main/'tasks/evidence/AVOID-008/parent-lazy-browser02-raw-review.json';assert not target.exists();target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'oldLeafComparisons':old_leaf[0],'expectedMetaChanges':4,'newStats':468,'rawSHA':sha(raw),'preparedEdges':out['totalPreparedEdges']}))
