from pathlib import Path
import json,hashlib,tarfile,gzip
m=Path('/workspace/lyricfx.JIZURA');e=m/'tasks/evidence/AVOID-008/integration-owned-final01';p=m/'review/AVOID-008/local-20261023-01';site=Path('/workspace/sites/jizura-equalizer-20261022');sha=lambda b:hashlib.sha256(b).hexdigest();man=json.loads((e/'manifest.json').read_text())
for x in man['files']:
 raw=(e/x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
pins=json.loads((e/'final-source-pins.json').read_text());assert len(pins['all86ProductSHA256'])==86
for n,h in pins['all86ProductSHA256'].items():assert sha((m/n).read_bytes())==h
allFrames=0;carry=[]
for name in ['swiss-carry.json','swiss-before-carry.json','proofread-carry.json','letter-carry.json','poster-carry.json']:
 d=json.loads((e/name).read_text());assert d['passed'] and not d.get('changed',d.get('changedInputs',[]))
 for n,h in pins['all86ProductSHA256'].items():assert d['pins'][n]==h
 for row in d['rows']:
  a=row.get('old',row.get('before'));b=row.get('current',row.get('after'));assert a['frames']==b['frames'] and len(a['frames'])==96 and not row['mismatches'];allFrames+=96
  if 'observations'in a:assert a['observations']==b['observations']
  if 'originalMismatch'in row:assert not row['originalMismatch']
  for flag in ['original96EncoderHashesExact','original3NativeKeysExact','originalNativeEncoderHashesExact']:
   if flag in row:assert row[flag] is True
 carry.append({'file':name,'rows':len(d['rows']),'matchedFrames':len(d['rows'])*96,'sha256':sha((e/name).read_bytes())})
assert allFrames==768
bundle=json.loads((p/'manifest.json').read_text());assert sha((p/'manifest.json').read_bytes())=='12d685ef128ea4f669736225f7dc12d664b9b2846d302973be953dcc220a4043';assert sha((p/'index.html').read_bytes())=='e2b4b3adb824055822c1f30965eb03a26230e9da6290a9d9cb0447d1fb3cefb7'
for x in bundle['assets']:assert sha((p/x['file']).read_bytes())==x['sha256']
for case in ['swiss','proofread','letter','poster']:
 d=json.loads((e/(case+'-binding.json')).read_text());assert d['finalSourceCommit']=='fdb7916329232885089119ba5023cca9aafc3d02';assert d['currentAndImmutableEngineFrameClockExact'];assert d['humanConfirmation'].startswith('PENDING');assert sha((m/d['finalProductPins']['path']).read_bytes())==d['finalProductPins']['sha256']
 for f in d['freshLocalCorrespondence']:assert sha((m/f['path']).read_bytes())==f['sha256']
 assert any(x['sha256']==sha((e/(case+'-binding.json')).read_bytes())for x in bundle['assets'])
old=json.loads((m/'tasks/evidence/AVOID-008/parent-curated-final4-local01-review.json').read_text())
for v in old['videos']:assert sha((p/v['path']).read_bytes())==v['sha256']
executions=[x['result']for x in json.loads((e/'carry-execution.json').read_text())]+[json.loads((e/'swiss-before-execution.json').read_text()),json.loads((e/'local-ja-en-corrected-execution.json').read_text())]
for x in executions:assert x['exitCode']==0 and x['runnerError']is None and x['cleanup']['complete'] and not x['cleanup']['remainingOwnedIdentities']and not x['cleanup']['errors']
initial=json.loads((e/'local-ja-en-execution.json').read_text());assert initial['exitCode']==1
with tarfile.open(e/'execution-raw.tar.gz')as t:
 smoke=t.extractfile('local-ja-en-corrected/stdout-stderr.log').read().decode();records=[json.loads(l)for l in smoke.splitlines()if l.startswith('{')];assert len(records)==2 and {r['language']for r in records}=={'ja','en'}
 for r in records:assert r['status']=='passed'and r['url'].startswith('http://127.0.0.1:')and r['hasColorVariation'] and r['cuts']==4 and r['lyricLines']==[0,1];assert r['sha256']==pins['all86ProductSHA256']['en/index.html'if r['language']=='en'else'index.html']
 assert 'ERR_MODULE_NOT_FOUND'in t.extractfile('local-ja-en/stdout-stderr.log').read().decode()
sp=json.loads((e/'sites-preparation.json').read_text());assert sp['allBundleBytesExact']and sp['allPriorSiteFilesUnchanged']and sp['hostingUnchanged']
for n,h in sp['priorSiteFiles'].items():assert sha((site/n).read_bytes())==h
for f in p.rglob('*'):
 if f.is_file():assert f.read_bytes()==(site/'dist/review/AVOID-008/local-20261023-01'/f.relative_to(p)).read_bytes()
report={'acceptedForHumanReview':True,'source':'fdb7916329232885089119ba5023cca9aafc3d02','all86CurrentProductPinsExact':True,'carry':carry,'nativeClockFramePairs':768,'historicalSwissAdaptedEncoderScope':'Fresh96native correspondence to original immutable compiled engine plus3originalnativekeys; no fresh96encoder claim. Existing MP4unchanged. Other7sides link original96encoder/frame records.','manifestSHA256':sha((p/'manifest.json').read_bytes()),'htmlSHA256':sha((p/'index.html').read_bytes()),'all79AssetsVerified':True,'all8MediaHashesUnchangedFromPriorParentFFprobe':True,'all6SuccessfulExecutionCleanupReceiptsVerified':True,'initialLocalLoaderFailurePreserved':True,'localJAENSmokeRecords':records,'priorSitesFilesPreserved':len(sp['priorSiteFiles']),'site80FilesExact':True,'pendingHumanQuestions':['swiss','proofread','letter','poster'],'publicRequests':0,'parentImageViews':0}
(m/'tasks/evidence/AVOID-008/parent-final-four-binding01-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['acceptedForHumanReview','nativeClockFramePairs','manifestSHA256','site80FilesExact','priorSitesFilesPreserved','publicRequests','parentImageViews']}))
